#!/bin/bash
git pull
mvn clean package
sudo cp target/Carre.war /var/lib/tomcat7/webapps/
sudo rm -rf /var/lib/tomcat7/webapps/Carre
sudo /etc/init.d/tomcat7 restart
