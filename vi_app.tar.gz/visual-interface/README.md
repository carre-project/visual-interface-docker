# Dr Inventor
MHA (a.k.a. ccgv-social-java)

To run it locally, you will need to parameter:
ENV_SYSTEM=.dev
which can be passed in to Tomcat as:
-DENV_SYSTEM=.dev

## Guide for Windows
1.	Make sure you have Java 7 installed (source code is tested against Java 7, will not work with Java 8 due to dependencies’ compatibility)
    
    java -version

2. install a git client for windows, (as we use git to do source code control):

    http://msysgit.github.io/
    (I normally will change to "Use Git from the Windows Command Prompt" option)

3. Install Maven 3.x.x for windows, which is our building tool:
    
    http://maven.apache.org/download.cgi
 
4.	Install MySQL database (current development environment depend on MySQL, which might be removed in future commits)

    http://dev.mysql.com/downloads/windows/installer/

5.	Under command line, go to a selected working folder, and get the latest source:

    https://coolcnid@bitbucket.org/coolcnid/ccgv-social-java.git
    (your git url is different, please login bitbucket to find your url)

    for simple JS/HTML edit, simply open the HTML file directly, e.g.
    ccgv-social-java/src/main/webapp/resources/app/templates/layout.html

6.	Create database, users, and relative tables, please refer to next section of this page for details:

7.	Go to the source code folder:

    cd ccgv-social-java

8.	Run maven command to start a embedded Tomcat environment: (this can take several minutes for first run)
    
    mvn clean tomcat7:run -DENV_SYSTEM=.dev

9.	If no exception throw from command line, you are good to go:

    http://127.0.0.1:8080/{path}  <- path can be 'mha' or other things






## Guide 

1. Run MySQL

        sudo service mysql start (Ubuntu Linux)
        mysql.server start (Mac OS X)

2. Connect to the database

        mysql -uroot (if no password set for root)
        mysql -uroot -p

2. Create a new database

        mysql > CREATE DATABASE ccgv_social;
        mysql > USE ccgv_social;

3. import SQL script (assume you current working diretory is project root)

        mysql > source src/main/resources/ccgv_social.sql;
        mysql > source src/main/resources/db.full.20141017.sql;
        please also import other sql in the same folder as appropriate

4. create new user and grant permission

        CREATE USER 'ccgv'@'localhost' IDENTIFIED BY 'your-own-password';
		GRANT ALL PRIVILEGES ON ccgv_social.* TO 'ccgv'@'localhost';
		FLUSH PRIVILEGES;

5. update the properties file with above created username/password/database name.

        vim src/main/resources/spring.properties

6. run the application (you might need to install maven)

        mvn clean tomcat7:run -DENV_SYSTEM=.dev

7. package the application and deploy to production server (or maybe: ccgv1u1)

        mvn package
    find your war here:
        target/{name}.war   <- name could be 'mha'

8. for special need, you might also run:
    
        mvn clean tomcat7:run -Dmaven.tomcat.port=8081
        or
        mvn clean jetty:run


## to import to IDE (take idea for example)
mvn idea:idea

## Mac note
to enable 'subl' in command line:
    sudo ln -s /Applications/Sublime\ Text.app/Contents/SharedSupport/bin/subl /usr/bin/subl

to run maven properly, make sure that JAVA_HOME is set properly:
edit file:
    ~/.profile
add: 
    export JAVA_HOME=$(/usr/libexec/java_home -v 1.7)


## Install and launch Cassandra under MacOS X

brew update
brew install cassandra / brew install cassandra12

To have launchd start cassandra at login:
    ln -sfv /usr/local/opt/cassandra/*.plist ~/Library/LaunchAgents
Then to load cassandra now:
    launchctl load ~/Library/LaunchAgents/homebrew.mxcl.cassandra.plist
Then: 
	launchctl start homebrew.mxcl.cassandra

NTOE: for a default Tomcat7 installation on Ubuntu 12.04, you might want to adjust the heap size to make the war compile/run properly:
    Open catalina.sh from tomcat/bin
then add follows
    JAVA_OPTS="$JAVA_OPTS -Djava.awt.headless=true -Dfile.encoding=UTF-8 -server -Xms1536m -Xmx1536m -XX:NewSize=256m -XX:MaxNewSize=256m -XX:PermSize=256m -XX:MaxPermSize=256m -XX:+DisableExplicitGC"
then restart your tomcat


## Tips
let git remember password in memory for 2 hours:
    git config --global credential.helper "cache --timeout=7200"


