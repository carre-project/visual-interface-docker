function showUserInfo()
{
	if ( (undefined == top.carre.username)
			|| ( "" == top.carre.username) )
	{
		$("#username").html("");
		$("#age").html("");
		$("#weight").html("");
		$("#height").html("");
		$("#sex").html("");
		return;
	}


	$("#username").html(top.carre.username);
	var userData = getUserData();

	if (undefined == userData.profile)
	{
		$("#age").html("");
		$("#weight").html("");
		$("#height").html("");
		$("#sex").html("");
		return;
	}
	
	var profile = userData.profile;
	
	$("#age").html(profile.age);
	$("#weight").html(profile.weight);
	$("#height").html(profile.height);
	$("#sex").html(profile.sex);

}

showUserInfo();

/*
var global_place_list = [];

//Risk tiles process
var page_width = parseInt(d3.select('#multi_axis').style("width"))
   
var padding = 55;
var width = page_width,
    height = 500,
    radius = Math.min(width, height) / 2;
 // console.log('Width is equal to >>>>>>>>>>>>>',page_width, height);
var today = new Date();

var color = d3.scale.category20();
var color2 = d3.scale.category20c();
var color3 = d3.scale.linear()
                .range(['red', 'blue']);

var zoom = d3.behavior.zoom()
        
//Handle the date format of Moves data
var format = d3.time.format("%Y-%m-%d %H:%M:%S%Z").parse;
var format1 = d3.time.format("%Y-%m-%d").parse;

var ShowTime = d3.select('#time')
                  .attr('width', width)
                  .attr('hight', 20)
                  .append('g')
                  .attr('transform', 'translate(100,0)')

var chartBody = d3.select('#multi_axis')
                  .append('svg')
                  .attr('width', width)
                  .attr('height', height)
                  .attr('class', 'timeline')
                  .append('g')
                  .attr('transform', 'translate(0, 0)')
                  

var clip = chartBody.append("defs").append("clipPath")
                  .attr("id", "clip")
                  .append("rect")
                  .attr("id", "clip-rect")
                  .attr("x", (padding*1.5))
                  .attr("y", padding)
                  .attr("width", width-(padding*3))
                  .attr("height", height-padding*2);


var canvas = chartBody.append("g")
                  .attr("clip-path", "url(#clip)")
                  .call(zoom);

//To force Google Chrome and Safari to zoom canvas SVG
canvas.append("rect")
    .attr("fill", "none")
    .attr("pointer-events", "all")
    .attr("width", "100%")
    .attr("height", "100%");



var yScale = d3.scale.linear()
    .range([height - padding, padding]);


var txScale = d3.time.scale()
    .range([0, width]);


  
var x_axis = d3.svg.axis()
      // .tickSize(-height, 0)
      .scale(txScale);
      // .tickSize(-height, 0, 0)
      

var y_l_axis1 = d3.svg.axis()
      // .scale(yScale)
      // .tickSize(-width)
      .orient('left');
var y_l_axis2 = d3.svg.axis()
      // .scale(yScale)
      // .tickSize(-width)
      .orient('left');
var y_l_axis3 = d3.svg.axis()
      // .scale(yScale)
      // .tickSize(-width)
      .orient('left');

var y_r_axis1 = d3.svg.axis()
      // .scale(yScale)
      // .tickSize(-width)
      .orient('right');
var y_r_axis2 = d3.svg.axis()
      // .scale(yScale)
      // .tickSize(-width)
      .orient('right');
var y_r_axis3 = d3.svg.axis()
      // .scale(yScale)
      // .tickSize(-width)
      .orient('right');

var y_l_axis4 = d3.svg.axis()
      // .scale(yScale)
      // .tickSize(-width)
      .orient('left');

var y_r_axis4 = d3.svg.axis()
      // .scale(yScale)
      // .tickSize(-width)
      .orient('right');

//Creating grid for the graph
var width_scale = d3.scale.linear()
            .domain([0,width])
            .range([0, width]);

var height_scale = d3.scale.linear()
            .domain([0,width])
            .range([0, (height-padding)]);



var x_grid = d3.svg.axis()
          .scale(width_scale)
          .orient('bottom')
          .ticks(Math.round(width/16))
          .tickSize(-height, 0, 0)
          .tickFormat('');

var y_grid = d3.svg.axis()
          .scale(height_scale)
          .orient('left')
          .ticks(Math.round(width/29))
          .tickSize(-width, 0, 0)
          .tickFormat('');



canvas.append('g')
            .attr('class', 'grid')
            .attr('transform', 'translate(0,' + (height-padding) + ')')
            // .call(x_grid);

canvas.append('g')
            .attr('class', 'grid')
            .attr('transform', 'translate(0, 0)')
            // .call(y_grid);


  
//Check the availability of requested data for TOOLTIP
function checkData (d) {
    if (d){
      return d;
    } return "No data";
  };

var tooltip = d3.select('body')
                  .append('div')
                  .attr('class', 'tooltip');

var placeTooltip = d3.select('body')
                  .append('div')
                  .attr('class', 'place_tooltip');

//Handle text color in D3 graph
function handleColor (d, i){
      if(d.activity_group === 'transport'){
        return '#white';} 
        return color(i);
    }

function checkSensor(d){
  if (!d.activity){
    if(d.source){
      return d.source;
    } else {
      return d.type;
    };
  } else {
    return d.activity
  }
};

function duration_check(d){
  if (d.duration && (d.duration > 100)){
    return Math.ceil(d.duration/60);
  } else if(d.duration && (d.duration < 100)){
      return d.duration/60;
  } else if (d.soft_activity_minutes || d.moderate_activity_minutes || d.intense_activity_minutes){
    var sum = (d.soft_activity_minutes)+(d.moderate_activity_minutes)+(d.intense_activity_minutes);
    return sum;
  } else {

    return null;
  }

  };

  function place_duration(d){
  var duration =  moment.utc(moment(d.end_time,"YYYY-MM-DD HH:mm:ss").diff(moment(d.start_time,"YYYY-MM-DD HH:mm:ss"))).format("HH:mm:ss");
    return duration;
  }

function check_elevation(d){
  if (!d.elevation){return "N/A";}
  else { return d.elevation;};
}

function check_place_avctivities(d){
  if (d.type && d.type === 'place' && d.activities){
    return d.activities.join(', ').replace(/_/g,' ');
  } else {
    return 'No recorded activity'
  }
}


function placeTooltipOn(d, i){
  var content = '<div style = "font-size: 15px; font-weight: 600; color:'
      +handleColor(d,i)+';">' + checkSensor(d) + '-'+d.location_type+'</span></div><div><span style="color: #FF3A75;">'
      +(place_duration(d)) + '</span>, <span style="color: #AFFF00;">'+ check_place_avctivities(d)+' </span></br><span style="color: #00FF00;">'
      +handleCalories(d)+'</span> Calories burned</div><div><span style="color: #00FF00;">'+check_elevation(d)+'</span> meter elevation</div><div><span style="color: #FFC900;">'
      +HandleTime(format(d.start_time))+'</span></div>';

      $('.place_tooltip').empty();
      placeTooltip.html(content).style('visibility', 'visible');
      reverseGeo(d, 'place_tooltip');
      weather_history(d, 'place_tooltip');
      d3.select(this).select('.pline')
        .transition()
        .attr('stroke-width', 30);



}

function placeTooltipMove(d){
        placeTooltip.style('top', (d3.event.pageY + 20) + 'px')
               .style('left', (d3.event.pageX - 75) + 'px');
}

function placeTooltipOff(d, i){
    placeTooltip.style('visibility', 'hidden');

    d3.select(this).select('.pline')
        .transition()
        .attr('stroke-width', 15);
}


function tooltipOn(d, i) {
     //  var content = '<div style = "font-size: 16px; font-weight: 600; color:'
     //  +handleColor(d,i)+';">' + checkSensor(d) + '</div><div><span style="color: #FF3A75;">'
     //  +(duration_check(d)) + '</span> Minutes, <span style="color: #AFFF00;">'
     //  + checkData(d.steps)+' </span> Steps </br><span style="color: #00FF00;">'
     //  +handleCalories(d)+'</span> Calories burned</br><span style="color: #00FF00;">'+check_elevation(d)+'</span> meter elevation</div><div><span style="color: #FFC900;">'
     //  + HandleTime(format1(d.date))+'</span></div>';
     //  // <div style = "margin-top: -25px; margin-bottom: -15px;">'+(html)+'</div>'
     // // reverseGeo(d);
     //  tooltip.html(content)
     //    .style('visibility', 'visible');



     //  tooltip.transition().style('opacity', 0.85);

      
      // this.parentNode.appendChild(this);
      
      // var toto = d3.select(this);

      // toto.select('circle')
      //       .transition()
      //       .ease('elastic')
      //       .duration(800)
      //       .attr('r', function(d){ if (d.steps){return Math.sqrt(d.steps)/4;} else if(d.duration && (d.duration > 100)){ if (d.duration < 6000 && d.activity_group && d.activity_group === 'transport'){return Math.sqrt(d.duration)/1.5} return Math.sqrt(d.duration)/4} else { return null} ;})
      //       .style('opacity', 0.9)
      //       .attr('stroke', '#6A6A6A')
      //       .attr('stroke-width', 2)

      // canvas.selectAll('text').data(d).enter().append('text')
      //   .text('r', function(d){ if (d.steps){return Math.sqrt(d.steps)/2;} return Math.sqrt(d.duration)/4;})
      //   .attr('x', '500')
      //   .attr('y', '500');

// // console.log()
var current_class = d3.select(this)[0][0].classList[1];

canvas.selectAll('.graphline:not(.'+current_class+'), .axis:not(.'+current_class+')')
      .transition()
      // .style('stroke-dasharray', '15,5')
      .style('opacity', 0.1)
};


function tooltipMove(d, i) {
       tooltip.style('top', (d3.event.pageY - 45) + 'px')
       .style('left', (d3.event.pageX + 25) + 'px');
     };

function tooltipOff() {
      
       
var current_class = d3.select(this)[0][0].classList[1];

canvas.selectAll('.graphline:not(.'+current_class+'), .axis:not(.'+current_class+')')
      .transition()
      .style('opacity', 1)

     };


//Check the data for calories
function handleCalories(d){

    if (d.calories){
      return d.calories
    } else {
      return 'No'
    }
  };


//Handle Date format
function HandleTime (d){
      var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
      var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
        var absMinDate = d.getDate();
        var absMinMonth = d.getMonth();
        var absMinYear = d.getFullYear();
        var absDay = d.getDay();
        var absMinTime = days[absDay] + ', ' +absMinDate+' '+months[absMinMonth]+' '+absMinYear;
        return absMinTime;
      }


function checkSource (data){
var source = [];
for (var i in data){
  if(data[i].source){
  source.push(data[i].source);    
} else if (data[i].summary){
  source.push(data[i].summary.source);
}

};

source = uniqueArray(source);

for (var i in source){
  $('#list').append('<option>'+(source[i])+'</option>');
}
return source;
};

function uniqueArray (origArr) {
    var newArr = [],
        origLen = origArr.length,
        found, x, y;

    for (x = 0; x < origLen; x++) {
        found = undefined;
        for (y = 0; y < newArr.length; y++) {
            if (origArr[x] === newArr[y]) {
                found = true;
                break;
            }
        }
        if (!found) {
            newArr.push(origArr[x]);
        }
    }
    return newArr;
  };


function setSensorValue(){
    var select = document.getElementById('list').value;
    if (select === ''){ select = 2} else{ select = parseInt(select)};

    return select;
  };

function setDateValue(id){
    var askDate = document.getElementById(id).value;
   today = new Date();

    function date_string(today){
         var month = (1 + today.getMonth()).toString();
         month = month.length > 1 ? month : '0' + month;
         var day = today.getDate().toString();
         day = day.length > 1 ? day : '0' + day;
         today = (today.getFullYear()+'-'+month+'-'+day).toString();
         return today;
    }

    function past_string(today, difference){
      // console.log(today)
         today = new Date(today.setMonth(today.getMonth() - difference));
         var month = (1 + today.getMonth()).toString();
         month = month.length > 1 ? month : '0' + month;
         var day = today.getDate().toString();
         day = day.length > 1 ? day : '0' + day;
         today = (today.getFullYear()+'-'+month+'-'+day).toString();
         return today;
    }
    if (askDate.length == 0 && id =='date'){
      var past = past_string(today, 8);
      // console.log('SET DATE VALUE for months ago is', past);
      return past;
    } else if (askDate.length == 0 && id =='date2'){
      var this_day = date_string(today);
      // console.log('SET DATE VALUE for TODAY is', this_day);
      return this_day;
    } else {
      return askDate;
    }

  };

MovesGo();

function MovesGo(){

      // top.mha.data.moves.done(function(data) {
        $.when(
        $.getJSON('../share/data/API2_daily_sum_youb.json'),
        $.getJSON('../share/data/carre_project.json'),
        $.getJSON('../share/data/PHR_C.json')
      ).done(function(dataFit, data, ehr) {
      // d3.json('carre_project.json' , function(data) {
        data = data[0];
        dataFit = dataFit[0];
        ehr = ehr[0]
      // console.log('THE NEW DATA >>>>>>>>>', data, dataFit, ehr)
      // // console.log('<<<<<<< SELECTED SENSOR >>>>>>>', setSensorValue()); 
      // var sensor = setSensorValue();  
      var sensor = 'fitbit'
      $('input:checkbox').prop('checked', false);
      $('#list').empty();
      checkSource(data);
      // var start = setDateValue('date');
      // var end = setDateValue('date2');
      var start = '2014-10-01'
      var end = '2015-04-02'
      // console.log('pick day is >>>>>', start, end)
      // console.log('WWWWWWWMMMMMMMMMMMMM', sensor);
      // var currentData = handleMovesData(data, sensor, start, end);
      var currentData = handleSummary(dataFit, 'fitbit', start, end);
      // // console.log('FITBIT DATA IS------------------------', currentData)
      // d3Chart(currentData, sensor);
      pathLines(ehr);
      // tileCalculation(currentData);
       // d3.select(window).on('resize', resize())
       // updateData(currentData);
            // // console.log(data);

          });
       console.timeEnd('Main Processing Time');

  }
 

//Getting the Withings data

 function handleSummary(data, sensor, start, end){

  // console.time('Handeling Data');
    var i, j, output = [], item=[], momo = [], dataset = data, fitbit =[], withings = [];

    // if (typeof movesDataset == 'string' || movesDataset instanceof String) {
    //           movesDataset = JSON.parse(movesDataset);
    //       }
        // // console.log(movesDataset);

    if(dataset != null && !start && !end){
      for (i in dataset){
        if (sensor ==='moves' && dataset[i].source === sensor ){
          momo.push(dataset[i]);
        } else if (sensor ==='fitbit' && dataset[i].source === sensor){
          output.push(dataset[i]);
        } else if (sensor ==='withings' && dataset[i].source === sensor){
          output.push(dataset[i]);
        }
      }
    } else if (dataset != null && start && end){
      for (i in dataset){
        if (sensor ==='moves' && dataset[i].source === sensor){
          momo.push(dataset[i]);
        } else if (sensor ==='fitbit' && dataset[i].source === sensor  ){
          output.push(dataset[i]);
        } else if (sensor ==='withings' && dataset[i].source === sensor){
          output.push(dataset[i]);
        }
      }

    } else {
      var emptyValue = {'duration':null, 'steps':null, 'distance':null, 'calories':null, 'activity': null}
      output.push(emptyValue)
    };

    if (momo != null){         
    for (i in momo){
      if (momo[i].activities){
        for(j in momo[i].activities){
              output.push(momo[i].activities[j]);
              item.push(momo[i].date)

              for (var key in output){
              output[key]['date'] = item[key]; 
              }
        }           
      }

    };
    };
    // // console.log('This is data with DUPLICATE', moves.length);
    var pureData = uniqueData(output);
    // console.log('Length of Data with NO DUPLICATE', pureData.length);
    // console.log('Final Data -------->>', pureData);
    return pureData;

      console.timeEnd('Handeling Data');
    // // console.log(emptyMoves);
    // // console.log(moves);
        // return moves;

        }

//Cleaning the RAW data from MOVES
function handleMovesData(data, sensor, start, end){

  // console.time('Handeling Data');
    var i, j, date = [], output = [], places =[], moving = [], item=[], momo = [], dataset = data, fitbit =[], withings = [], segData=[];

    // if (typeof movesDataset == 'string' || movesDataset instanceof String) {
    //           movesDataset = JSON.parse(movesDataset);
    //       }
        // // console.log(movesDataset);
    
    if (dataset != null){
      for (i in dataset){
        if (sensor ==='moves' && dataset[i].summary.source === sensor){
          if (dataset[i].segments && (start <= dataset[i].date) && (dataset[i].date <= end)){
        // if (sensor ==='moves' && dataset[i].source === sensor && dataset[i].segments ){
          date.push(dataset[i].date);
          segData.push(dataset[i].segments);
          for (var t in segData){
            segData[t]['date'] = date[t];
          }
        }
          else {
             momo.push(dataset[i]);
           } 
         
        } else if (sensor ==='fitbit' && dataset[i].summary.source === sensor){
          output.push(dataset[i].summary);
          date.push(dataset[i].date);
          for (var t in output){
            output[t]['date'] = date[t];
          }
        } else if (sensor ==='withings' && dataset[i].summary.source === sensor){
          output.push(dataset[i].summary);
          date.push(dataset[i].date);
          for (var t in output){
            output[t]['date'] = date[t];
          }

        }
      }
    };
    // console.log('This is segData xxxxxxxxxxxx>>>', segData);

        if (momo != null){         
    for (i in momo){
      if (momo[i].activities){
        for(j in momo[i].activities){
              output.push(momo[i].activities[j]);
              item.push(momo[i].date)

              for (var key in output){
              output[key]['date'] = item[key]; 
              }
        }           
      }

    };
    };
    // console.log('This is MOMO----------', momo);


    if (segData != null){         
    for (i in segData){
    for (var k in segData[i]){
    if (segData[i][k].type === 'place'){
      
      if(segData[i][k].activities){
        var item = [];
        var type = segData[i][k].type;
        // var placeID =  segData[i].place.type;
        var start_time = segData[i][k].start_time;
        var end_time = segData[i][k].end_time;
        // var duration =  moment.utc(moment(end_time,"YYYY-MM-DD HH:mm:ssZ").diff(moment.utc(start_time,"YYYY-MM-DD HH:mm:ssZ")));
        // duration = moment.duration(duration).asMinutes();
        if(segData[i][k].place){
            var location = segData[i][k].place.location;
            var location_type = segData[i][k].place.type;
        } else {
            var location = null;
            var location_type = 'unknown';
        }

        var act_duration = 0;
        for(var j in segData[i][k].activities){
          var activities = segData[i][k].activities[j].activity;
          act_duration += segData[i][k].activities[j].duration;
          var calories = segData[i][k].activities[j].calories;

          // if(segData[i][k].activities[j].start_time && segData[i][k].activities[j].end_time){
          //   var start_time = segData[i][k].activities[j].start_time;
          //   var end_time = segData[i][k].activities[j].end_time;
          // }

          item.push(activities);
          // // console.log(item);
        }
        item = uniqueArray(item);
        var tempPlaces = 
        {
        "date": segData[i].date,
        "activities": item,
        "location": location,
        "location_type": location_type,
        "type": type,
        // "duration": duration,
        "activities_duration": act_duration,
        "calories": calories,
        "start_time": start_time,
        "end_time": end_time,
        };
        
        output.push(tempPlaces);
      } else {

        if(segData[i][k].place){
            var location = segData[i][k].place.location;
            var location_type = segData[i][k].place.type;
        } else {
            var location = null;
            var location_type = 'unknown';
        };
        var type = segData[i][k].type;
        // var placeID =  segData[i].place.type;
        var start_time = segData[i][k].start_time;
        var end_time = segData[i][k].end_time;
        // var duration = cal_duration(segData[i].date, segData[i][k])
        var tempPlaces = 
        {
        "date": segData[i].date,
        "type": type,
        "location": location,
        "location_type": location_type,
        // "duration": duration,
        // "placeID": placeID,
        "start_time": start_time,
        "end_time": end_time
        };
        
        output.push(tempPlaces);
      }


     
    } else if (segData[i][k].type === 'move'){
      for(var j in segData[i][k].activities){
        output.push(segData[i][k].activities[j])

      }

    }
  }
}
    };
    // // console.log('This is data with DUPLICATE', moves.length);
    var pureData = uniqueData(output);
    // console.log('Length of Data with NO DUPLICATE', pureData.length);
    // console.log('Final Data -------->>', pureData);
    return pureData;

      console.timeEnd('Handeling Data');
    // // console.log(emptyMoves);
    // // console.log(moves);
        // return moves;

        }
    // return moves;
      
//Remove Duplicate objects in data
function uniqueData(obj){
    var uniques=[];
    var stringify={};
    for(var i=0;i<obj.length;i++){
       var keys=Object.keys(obj[i]);
       keys.sort(function(a,b) {return a-b});
       var str='';
        for(var j=0;j<keys.length;j++){
           str+= JSON.stringify(keys[j]);
           str+= JSON.stringify(obj[i][keys[j]]);
        }
        if(!stringify.hasOwnProperty(str)){
            uniques.push(obj[i]);
            stringify[str]=true;
        }
    }
    return uniques;
} 
  
function cal_duration(day, d){

  if (d.duration){
    return d.duration/60; 
  } else if (d.soft_activity_minutes || d.moderate_activity_minutes || d.intense_activity_minutes){
    var sum = (d.soft_activity_minutes)+(d.moderate_activity_minutes)+(d.intense_activity_minutes);
    return sum;
    } else if (d.start_time && d.end_time){
      // // console.log('KKKKKKKKKKKKKKKKK', format(d.start_time));

    var end = format(d.end_time).getDate();
    var start = format(d.start_time).getDate();
    var date = new Date(day).getDate();
    // console.log('HHHHHHHHHHHHHHHHHHHHHHHHHHHH', end, start, date)
    if(end == start){
    var duration =  moment.utc(moment(d.end_time,"YYYY-MM-DD HH:mm:ss").diff(moment(d.start_time,"YYYY-MM-DD HH:mm:ss"))).format("HH:mm:ss");
    return moment.duration(duration).asSeconds();
    } 
    }
  
};


function duration_calculate(d){
    var duration =  moment.utc(moment(d.end_time,"YYYY-MM-DD HH:mm:ss").diff(moment(d.start_time,"YYYY-MM-DD HH:mm:ss"))).format("HH:mm:ss");
    return duration;
};

//Fix the Date parsing between different browsers
function convert_time(time){
  var converted = format(time) == null ? (new Date(time)) : format(time);
  return converted;
}



function timeExtent(data){

    // var time_max = d3.max(data, function(d){return d.VisitDate});
    var time_max = d3.max(data, function(d){return d.date});
      // console.log('Time max --------->>', time_max);

    // var time_min = d3.min(data, function(d){return d.VisitDate});
    var time_min = d3.min(data, function(d){return d.date});
      // console.log('Time min --------->>', time_min);



      var minDate = format(time_min) == null ? (new Date(time_min)) : format(time_min);
      var maxDate = format(time_max) == null ? (new Date(time_max)) : format(time_max);

     return [minDate, maxDate];
      };


function timeExtent_path(data){

    var time_max = d3.max(data, function(d){return d.date});
    // var time_max = d3.max(data, function(d){return d.date});
      // console.log('Time max --------->>', time_max);

    var time_min = d3.min(data, function(d){return d.date});

      var minDate = format(time_min) == null ? (new Date(time_min)) : format(time_min);
      var maxDate = format(time_max) == null ? (new Date(time_max)) : format(time_max);

     return [minDate, maxDate];
      };


//Clear the existing SVG items
function clear_chart(){
  canvas.selectAll('.lable').transition().style('opacity', 0).remove();
  canvas.selectAll('.x.axis').transition().style('opacity', 0).remove();
  // canvas.selectAll('.circle').transition().attr('r', 0);
  canvas.selectAll('.text').transition().style('opacity', 0).remove();
  canvas.selectAll('.circle').remove();
  canvas.selectAll('.pline').transition().style('opacity', 0).remove();
}


// Drawing D3-based graph
function d3Chart(dataFit, sensor){
  
  // canvas.selectAll('.lable').remove();
  // canvas.selectAll('.x.axis, .y.axis').remove();
  // canvas.selectAll('.circle').remove();
  // canvas.selectAll('.bubbletext').remove();
  // canvas.selectAll('.pline').remove();
  // canvas.selectAll('.circle_act').remove();
  // canvas.selectAll('path').remove();
  // canvas.selectAll('.graphline').remove();
  // canvas.selectAll('.guide, .guidance').remove();
  $('g:empty').remove();
  $('.facets').empty();

  global_place_list = [];
  // $('#map').gmap3({ clear: {}, trafficlayer: {} });

  // canvas.selectAll('circle').remove();
// d3.select("g.parent").selectAll("*").remove();

    console.time('Drawing Chart');
    var text2 = canvas.append('text')
                    .attr('x', width/1.15)
                    .attr('y', height/3.7 - padding)
                    .attr('font-size', 20)
                    .attr('text-anchor', 'middle')
                    .style('opacity', 0.5)
                    .text('Patient ID '+sensor+' Data')
                    .transition()
                    .delay(2400)
                    .style('opacity', 0);
    var textInfo = canvas.append('text')
                    .attr('x', width/2)
                    .attr('y', height/2 - padding/1.7)
                    .attr('font-size', 15)
                    .attr('text-anchor', 'middle')
                    .style('opacity', 0.5)
                    // .text('Fitbit and Withings are now supported too!')
                    .transition()
                    .delay(1600)
                    .style('opacity', 0);
                    

    //Calculating the maximum amount of Y-Axis
// var y_max = d3.max(moves, function(d){
//   if (d.duration){
//     return d.duration/60; 
//   } else if(d.soft_activity_minutes || d.moderate_activity_minutes || d.intense_activity_minutes) {
//     var sum = (d.soft_activity_minutes)+(d.moderate_activity_minutes)+(d.intense_activity_minutes);
//     return sum;
//   } return 0;

//   });
var y_max = 10;
    // console.log('Y-MAX is >>> >>> >> >',y_max);
    
    //Scaling the Y-Axis
    yScale.domain([0, y_max]);
    // zoom.y(yScale);
      
    //Dealing with NO DATA by giving notification text
    if (y_max < 1){
         var text3 = canvas.append('text')
                    .attr('x', width/2)
                    .attr('y', height/2 - padding)
                    .attr('font-size', 20)
                    .attr('text-anchor', 'middle')
                    .style('opacity', 0)
                    .attr('class', 'text')
                    .text('No Data')
                    // .ease('bounce')
                    // .attr('font-size', 50)
                    .transition()
                    .delay(1500)
                    // .ease('linear')
                    // .duration(300)
                    // .attr('font-size', 100)
                    .style('opacity', 0.5);

        var text4 = canvas.append('text')
                    .attr('x', width/2)
                    .attr('y', height/2 - padding/1.7)
                    .attr('font-size', 15)
                    .attr('text-anchor', 'middle')
                    .attr('class', 'text')
                    .style('opacity', 0)
                    .text('Please add your Moves, fitbit, or Withings account to MyHealthAvatar.')
                    // .ease('bounce')
                    // .attr('font-size', 50)
                    .transition()
                    .delay(2000)
                    // .ease('linear')
                    .duration(1000)
                    // .attr('font-size', 100)
                    .style('opacity', 0.6);
                  };
        
                  
    // console.log('DataFit is -------->', dataFit)

   //Time scale on X Axis
   txScale.range([padding, width]).domain(timeExtent(dataFit));
   zoom.x(txScale);

    
    ShowTime.append('text')
        // .attr('fill', 'grey')
        .attr('class', 'time')
        .text(today);
 

function duration_check(d){
  if (d.duration && (d.duration > 100)){
    return Math.ceil(d.duration/60);
  } else if(d.duration && (d.duration < 100)){
      return d.duration/60;
  } else if (d.soft_activity_minutes || d.moderate_activity_minutes || d.intense_activity_minutes){
    var sum = (d.soft_activity_minutes)+(d.moderate_activity_minutes)+(d.intense_activity_minutes);
    return Math.ceil(sum/60);
  } else {

    return null;
  }

  };
  

// Drawing circles     
var circle = canvas.selectAll('circle')
    .data(dataFit)
    // .data(moves.filter(function(d){return d.date > 20140501 && d.date < 20140519;}))
    .enter()
    .append('g');

     circle.append('circle')
      .attr('cx', function(d){return txScale(format1(d.date)); })
      .attr('cy', function(d){ 
       return yScale(duration_check(d)); })
      .attr('r', 0)
      .attr('class', 'circle')
      .style('fill', function(d, i){ if(d.activity_group == 'transport'){return '#0C103F';} return color(i); })
      .style('opacity', 0)
      .transition()
      .delay(1500)
      .ease('elastic')
      .duration(1000)
      .delay(function(d, i){ return i * 10; })
      .attr('r', function(d){ if (d.steps){return Math.sqrt(d.steps)/9;} return Math.sqrt(d.duration)/9;})
      .style('opacity', 0.7);


//Labeling the circles
  circle.append('text')
        .attr('class', 'bubbletext')
        //this is for steps and activity
        // .text(function(d){ if((d.steps != null && d.activity != null)){ return d.steps; } else if (d.activity) return Math.round(d.duration/60); })
        .text(function(d){if(d.steps || d.activity){return duration_check(d)} 
         
        })
        // .text(function(d){return '\uf179'})
        // .attr('font-family', 'FontAwesome')
        .attr('x', function(d){return txScale(format1(d.date)); })
        .attr('y', function(d){ return yScale(duration_check(d));  })
        .attr('text-anchor', 'middle')
        .attr('font-size', 12)
        .attr('transform', 'translate(0,4)')
        // .on('mouseover', tooltipOn, false)
        // .on('mousemove', tooltipMove, false)
        // .on('mouseout', tooltipOff, false)
        .style('fill', function(d, i){if(d.activity == 'transport'){return '#FFFFFF';} return color(i+1); })
        .style('opacity', 0)
        .transition()
        .delay(function(d, i){ return i * 10 })
        .duration(1200)
        .style('opacity', 1);

circle.on('mouseover', tooltipOn)
        .on('mousemove', tooltipMove)
        .on('mouseout', tooltipOff);



  //Draw X-Axis
  var axis = chartBody.append('g');
  axis.append('g')
      .attr('class', 'x axis')
      .attr("transform", "translate(0," + (height - padding) + ")")
      .style('opacity', 1)
      .call(x_axis)
      // .attr("transform", "translate(0," + (height - padding) + ")");
      
      // To turn 90 degree
      // .selectAll('text')
      // .attr('y', 0)
      // .attr('x', 9)
      // .attr('dy', '.35em')
      // .attr('transform', 'rotate(90)')
      // .style('text-anchor', 'start');

      canvas.append('g')
      .attr('class', 'y axis')
      .attr("transform", "translate(" + padding + ",0)")
      .call(y_axis);

  //Label for Y-Axis
  canvas.append('text')
        .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
        .text('mmol/l - Activity Duration/hour')
        .attr('class', 'lable')
        .style('font-size', 25)
        .attr('text-anchor', 'middle')
        .style('opacity', 0)
        .transition()
        .delay(1000)
        .duration(1000)
        .style('font-size', 12)
        .style('opacity', 0.8)


zoom.on("zoom", draw);
// console.log('zoom level is ------->', zoom.scale());
        
      console.timeEnd('Drawing Chart');

      // console.log('zoom level is ------->', zoom.scale());


$('.circle_act_hide:empty').remove();
$('.pline_hide:empty').remove();
$('g:empty').remove();

  };


var y_l_Scale1 = d3.scale.linear()
    .range([height - padding, padding]);

var y_l_Scale2 = d3.scale.linear()
    .range([height - padding, padding]);

var y_l_Scale3 = d3.scale.linear()
    .range([height - padding, padding]);

var y_r_Scale1 = d3.scale.linear()
    .range([height - padding, padding]);

var y_r_Scale2 = d3.scale.linear()
    .range([height - padding, padding]);

var y_r_Scale3 = d3.scale.linear()
    .range([height - padding, padding]);

var y_r_Scale4 = d3.scale.linear()
    .range([height - padding, padding]);

var y_r_Scale5 = d3.scale.linear()
    .range([height - padding, padding]);


function pathLines(data){


// console.log('Path Line data --------', data)

var y_max = timeExtent_path;
   




txScale.range([(padding*1.5), width-(padding*1.5)]).domain(timeExtent_path(data));
zoom.x(txScale);
y_l_Scale1.domain([0, d3.max(data, function(d){return d.glc2h})]);
y_l_Scale2.domain([0, d3.max(data, function(d){return d.tg})]);
y_l_Scale3.domain([0, d3.max(data, function(d){return d.tc})]);
y_r_Scale1.domain([0, d3.max(data, function(d){return d.hdlc})]);
y_r_Scale2.domain([0, d3.max(data, function(d){return d.ldlc})]);
y_r_Scale3.domain([0, d3.max(data, function(d){return d.weight})]);
y_r_Scale4.domain([0, d3.max(data, function(d){return d.sbp})]);
y_r_Scale5.domain([0, d3.max(data, function(d){return d.walk})]);


//Scale the Y-Axis individually
  y_l_axis1.scale(y_l_Scale1);
  y_l_axis2.scale(y_l_Scale2);
  y_l_axis3.scale(y_l_Scale3);
  y_r_axis1.scale(y_r_Scale1);
  y_r_axis2.scale(y_r_Scale2);
  y_r_axis3.scale(y_r_Scale3);
  y_l_axis4.scale(y_r_Scale4);
  y_r_axis4.scale(y_r_Scale5);

  var axis = chartBody.append('g');

//Draw X-Axis
  axis.append('g')
      .attr('class', 'x time_axis')
      .attr("transform", "translate(0," + (height - padding) + ")")
      .style('opacity', 1)
      .call(x_axis)


var glc2h, glc_thr, tgline, tg_thr, tcline, tc_thr, hdl, hdl_thr, ldl, ldl_thr, weight, sbp, dbp, ex, blood_thr;

d3.selectAll('.tg_button').on('click', onClickVariables);

function drawBloodPressure()
{
    if (! $('#sbp').is(':checked')) {
		if (undefined !=  sbp) 
        sbp.transition().attr("d", chart_phr(data, 'sbp', "zero")).remove();
        // Remove line
        sbp = null;
		if (undefined !=  blood_thr) 
        	blood_thr.remove();
        chartBody.selectAll('.sbp.axis, .sbp.lable').transition().style('opacity', 0).remove();

		if (undefined !=  dbp) 
        dbp.transition().attr("d", chart_phr(data, 'dbp', "zero")).remove();
        // Remove line
        dbp = null;
        chartBody.selectAll('.dbp.axis, .dbp.lable').transition().style('opacity', 0).remove();
    } else {
        sbp = canvas.append("path").attr("class", "graphline sbp").style("stroke", "#8D0A0A").style("stroke-width", 2).attr("d", chart_phr(data, "glc2h", "zero"));
        sbp.transition().duration(800).attr("d", chart_phr(data, "sbp"));

        dbp = canvas.append("path").attr("class", "graphline dbp").style("stroke", "#669F04").style("stroke-width", 2).attr("d", chart_phr(data, "glc2h", "zero"));
        dbp.transition().duration(800).attr("d", chart_phr(data, "dbp"));


        blood_thr = canvas.selectAll('svg').data([139, 80]).enter().append('line')
            .attr('x1', (padding*1.5))
            .attr('y1', function(d){return y_r_Scale4(d)})
            .attr('x2', width-(padding*1.5))
            .attr('y2', function(d){return y_r_Scale4(d)})
            .style('stroke', '#000')
            .style('stroke-dasharray', '10 5')

axis.append('g')
      .attr('class', 'sbp axis')
      .attr("transform", "translate(" + padding*1.5 + ",0)")
      .call(y_l_axis4);

axis.append('text')
        // .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
        .attr('transform', 'translate('+55+',50)')
        .text('SBP/DBP')
        .attr('class', 'sbp lable')
        .style('font-size', 25)
        .attr('text-anchor', 'left')
        .style('font-size', 12)
        .style('opacity', 0.8)
    }
} 
 
function drawGlc()
{

    if (! $('#glc').is(':checked')) {
		if (undefined != glc2h)
        	glc2h.transition().attr("d", chart_phr(data, 'glc2h', "zero")).remove();
        // Remove line
        glc2h = null;
		if (undefined != glc_thr)
        	glc_thr.remove();
        chartBody.selectAll('.glc.axis, .glc.lable').transition().style('opacity', 0).remove();
    } else {
        glc2h = canvas.append("path").attr("class", "graphline glc").style("stroke", "#00D173").style("stroke-width", 2).attr("d", chart_phr(data, "glc2h", "zero"));
        glc2h.transition().duration(800).attr("d", chart_phr(data, "glc2h"));

    glc_thr = canvas.selectAll('svg').data([5.5, 3.9]).enter().append('line')
            .attr('x1', (padding*1.5))
            .attr('y1', function(d){return y_r_Scale4(d)})
            .attr('x2', width-(padding*1.5))
            .attr('y2', function(d){return y_r_Scale4(d)})
            .style('stroke', '#000')
            .style('stroke-dasharray', '10 5')


  axis.append('g')
      .attr('class', 'glc axis')
      .attr("transform", "translate(" + padding*1.5 + ",0)")
      .call(y_l_axis1);
  axis.append('text')
        // .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
        .attr('transform', 'translate('+70+',50)')
        .text('GLC')
        .attr('class', 'glc lable')
        .style('font-size', 25)
        .attr('text-anchor', 'left')
        .style('font-size', 12)
        .style('opacity', 0.8)

  glc2h.on('mouseover', tooltipOn)
        // .on('mousemove', tooltipMove)
        .on('mouseout', tooltipOff);
    }



}


function drawTg()
{
    if (! $('#tg').is(':checked')) {
		if (undefined != tgline)
        tgline.transition().attr("d", chart_phr(data, 'tg', "zero")).remove();
        // Remove line
        tgline = null;
		if (undefined != tg_thr)
        tg_thr.remove();
        chartBody.selectAll('.tg.axis, .tg.lable').transition().style('opacity', 0).remove();
    } else {
        tgline = canvas.append("path").attr("class", "graphline tg").style("stroke", "red").style("stroke-width", 2).attr("d", chart_phr(data, "glc2h", "zero"));
        tgline.transition().duration(800).attr("d", chart_phr(data, "tg"));

    tg_thr = canvas.selectAll('svg').data([70]).enter().append('line')
            .attr('x1', (padding*1.5))
            .attr('y1', function(d){return y_r_Scale4(d)})
            .attr('x2', width-(padding*1.5))
            .attr('y2', function(d){return y_r_Scale4(d)})
            .style('stroke', '#000')
            .style('stroke-dasharray', '10 5')

  axis.append('g')
      .attr('class', 'tg axis')
      .attr("transform", "translate(" + padding + ",0)")
      .call(y_l_axis2);
  axis.append('text')
        // .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
        .attr('transform', 'translate('+45+',50)')
        .text('TG')
        .attr('class', 'tg lable')
        .style('font-size', 25)
        .attr('text-anchor', 'left')
        .style('font-size', 12)
        .style('opacity', 0.8)

    tgline.on('mouseover', tooltipOn)
        // .on('mousemove', tooltipMove)
        .on('mouseout', tooltipOff);
    }

}


function drawTc()
{
    if (! $('#tc').is(':checked')) {
		if (undefined != tcline)
        	tcline.transition().attr("d", chart_phr(data, 'tc', "zero")).remove();
        // Remove line
        tcline = null;
		if (undefined != tc_thr)
        	tc_thr.remove();
        chartBody.selectAll('.tc.axis, .tc.lable').transition().style('opacity', 0).remove();
    } else {
        tcline = canvas.append("path").attr("class", "graphline tc").style("stroke", "orange").style("stroke-width", 2).attr("d", chart_phr(data, "glc2h", "zero"));
        tcline.transition().duration(800).attr("d", chart_phr(data, "tc"));

     tc_thr = canvas.selectAll('svg').data([190]).enter().append('line')
            .attr('x1', (padding*1.5))
            .attr('y1', function(d){return y_r_Scale4(d)})
            .attr('x2', width-(padding*1.5))
            .attr('y2', function(d){return y_r_Scale4(d)})
            .style('stroke', '#000')
            .style('stroke-dasharray', '10 5')


axis.append('g')
      .attr('class', 'tc axis')
      .attr("transform", "translate(" + padding/2 + ",0)")
      .call(y_l_axis3);
axis.append('text')
        // .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
        .attr('transform', 'translate('+15+',50)')
        .text('TC')
        .attr('class', 'tc lable')
        .style('font-size', 25)
        .attr('text-anchor', 'left')
        .style('font-size', 12)
        .style('opacity', 0.8)

  tcline.on('mouseover', tooltipOn)
        // .on('mousemove', tooltipMove)
        .on('mouseout', tooltipOff);
    }
}

function drawHdl()
{
    if (! $('#hdl').is(':checked')) {
		if (undefined != hdl)
        	hdl.transition().attr("d", chart_phr(data, 'hdlc', "zero")).remove();
        // Remove line
        hdl = null;
		if (undefined != hdl_thr)
        hdl_thr.remove();
        chartBody.selectAll('.hdl.axis, .hdl.lable').transition().style('opacity', 0).remove();
        if(ldl_b.checked && wgt_b.checked){
          chartBody.selectAll('.weight.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')');
          chartBody.selectAll('.ldl.axis').transition().attr('transform', 'translate(' + (width-padding) + ',' + 0 + ')');
          chartBody.selectAll('.weight.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')');
          chartBody.selectAll('.ldl.lable').transition().attr('transform', 'translate(' + (width-padding) + ',' + 50 + ')')
        }
        else if(ldl_b.checked ){
          chartBody.selectAll('.ldl.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')')
          chartBody.selectAll('.ldl.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')')
        } else {
          chartBody.selectAll('.weight.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')');
          chartBody.selectAll('.weight.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')');
        };
    } else {
        hdl = canvas.append("path").attr("class", "graphline hdlc").style("stroke", "green").style("stroke-width", 2).attr("d", chart_phr(data, "glc2h", "zero"));
        hdl.transition().duration(800).attr("d", chart_phr(data, "hdlc"));


        hdl_thr = canvas.selectAll('svg').data([190]).enter().append('line')
            .attr('x1', (padding*1.5))
            .attr('y1', function(d){return y_r_Scale4(d)})
            .attr('x2', width-(padding*1.5))
            .attr('y2', function(d){return y_r_Scale4(d)})
            .style('stroke', '#000')
            .style('stroke-dasharray', '10 5')


axis.append('g')
      .attr('class', 'hdl right axis')
      .attr("transform", function(d){
        if(ldl_b.checked && wgt_b.checked) {return "translate(" + (width-padding/2) + ",0)";}
        else if(ldl_b.checked || wgt_b.checked) {return "translate(" + (width-padding) + ",0)";}
        else {return "translate(" + (width-padding*1.5) + ",0)";}
      })
      .call(y_r_axis1);

axis.append('text')
        // .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
        .attr("transform", function(d){
        if(ldl_b.checked && wgt_b.checked) {return "translate(" + (width-padding/2) + ",50)";}
        else if(ldl_b.checked || wgt_b.checked) {return "translate(" + (width-padding) + ",50)";}
        else {return "translate(" + (width-padding*1.5) + ",50)";}
          })
        .text('HDL')
        .attr('class', 'hdl lable')
        .style('font-size', 25)
        .attr('text-anchor', 'left')
        .style('font-size', 12)
        .style('opacity', 0.8)

    hdl.on('mouseover', tooltipOn)
        // .on('mousemove', tooltipMove)
        .on('mouseout', tooltipOff);
    }


}

function drawLdl()
{
    if (! $('#ldl').is(':checked')) {
		if (undefined != ldl)
        	ldl.transition().attr("d", chart_phr(data, 'ldlc', "zero")).remove();
        // Remove line
        ldl = null;
		if (undefined != ldl_thr)
        	ldl_thr.remove();
        chartBody.selectAll('.ldl.axis, .ldl.lable').transition().style('opacity', 0).remove();
        if(hdl_b.checked && wgt_b.checked){
          chartBody.selectAll('.hdl.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')');
          chartBody.selectAll('.weight.axis').transition().attr('transform', 'translate(' + (width-padding) + ',' + 0 + ')');
          chartBody.selectAll('.hdl.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')');
          chartBody.selectAll('.weight.lable').transition().attr('transform', 'translate(' + (width-padding) + ',' + 50 + ')')
        }
        else if(hdl_b.checked){
          chartBody.selectAll('.hdl.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')')
          chartBody.selectAll('.hdl.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')')
        } else {
          chartBody.selectAll('.weight.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')');
          chartBody.selectAll('.weight.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')');
        }
    } else {
        ldl = canvas.append("path").attr("class", "graphline ldlc").style("stroke", "blue").style("stroke-width", 2).attr("d", chart_phr(data, "glc2h", "zero"));
        ldl.transition().duration(800).attr("d", chart_phr(data, "ldlc"));

   ldl_thr = canvas.selectAll('svg').data([159, 100]).enter().append('line')
            .attr('x1', (padding*1.5))
            .attr('y1', function(d){return y_r_Scale4(d)})
            .attr('x2', width-(padding*1.5))
            .attr('y2', function(d){return y_r_Scale4(d)})
            .style('stroke', '#000')
            .style('stroke-dasharray', '10 5')

axis.append('g')
      .attr('class', 'ldl right axis')
      .attr("transform", function(d){
        if(hdl_b.checked && wgt_b.checked) { return "translate(" + (width-padding/2) + ",0)";}
        else if(hdl_b.checked || wgt_b.checked) { return "translate(" + (width-padding) + ",0)";}
        else { return "translate(" + (width-padding*1.5) + ",0)";}
      })
      .call(y_r_axis2);
  axis.append('text')
        // .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
        .attr("transform", function(d){
        if(hdl_b.checked && wgt_b.checked) { return "translate(" + (width-padding/2) + ",50)";}
        else if(hdl_b.checked || wgt_b.checked) { return "translate(" + (width-padding) + ",50)";}
        else { return "translate(" + (width-padding*1.5) + ",50)";}
          })
        .text('LDL')
        .attr('class', 'ldl lable')
        .style('font-size', 25)
        .attr('text-anchor', 'left')
        .style('font-size', 12)
        .style('opacity', 0.8)

    ldl.on('mouseover', tooltipOn)
        // .on('mousemove', tooltipMove)
        .on('mouseout', tooltipOff);

    }

}

function drawWeight()
{
    if (! $('#wgt').is(':checked')) {
		if (undefined != weight)
        	weight.transition().attr("d", chart_phr(data, 'weight', "zero")).remove();
        // Remove line
        weight = null;
        chartBody.selectAll('.weight.axis, .weight.lable').transition().style('opacity', 0).remove();
        if(hdl_b.checked && ldl_b.checked){
          chartBody.selectAll('.hdl.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')');
          chartBody.selectAll('.ldl.axis').transition().attr('transform', 'translate(' + (width-padding) + ',' + 0 + ')');
          chartBody.selectAll('.hdl.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')');
          chartBody.selectAll('.ldl.lable').transition().attr('transform', 'translate(' + (width-padding) + ',' + 50 + ')')
        }
        else if(hdl_b.checked){
          chartBody.selectAll('.hdl.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')')
          chartBody.selectAll('.hdl.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')')
        } else {
          chartBody.selectAll('.ldl.axis').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 0 + ')');
          chartBody.selectAll('.ldl.lable').transition().attr('transform', 'translate(' + (width-padding*1.5) + ',' + 50 + ')');
        }
    } else {
        weight = canvas.append("path").attr("class", "graphline weight").style("stroke", "purple").style("stroke-width", 2).attr("d", chart_phr(data, "glc2h", "zero"));
        weight.transition().duration(800).attr("d", chart_phr(data, "weight"));

axis.append('g')
      .attr('class', 'weight right axis')
      .attr("transform", function(d){
        if(hdl_b.checked && ldl_b.checked){return "translate(" + (width-padding/2) + ",0)";} 
        else if(hdl_b.checked || ldl_b.checked){// console.log('yes'); 
		return "translate(" + (width-padding) + ",0)";}
        else {return "translate(" + (width-padding*1.5) + ",0)";} 
      })
      .call(y_r_axis3);

	axis.append('text')
        // .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
        .attr("transform", function(d){
        if(hdl_b.checked && ldl_b.checked){return "translate(" + (width-padding/2) + ",50)";} 
        else if(hdl_b.checked || ldl_b.checked){// console.log('yes'); 
			return "translate(" + (width-padding) + ",50)";}
        else {return "translate(" + (width-padding*1.5) + ",50)";} 
          })
        .text('KG')
        .attr('class', 'weight lable')
        .style('font-size', 25)
        .attr('text-anchor', 'left')
        .style('font-size', 12)
        .style('opacity', 0.8)

    weight.on('mouseover', tooltipOn)
        // .on('mousemove', tooltipMove)
        .on('mouseout', tooltipOff);

    }
}

function drawEx()
{
    if (! $('#ex').is(':checked')) {
		if (undefined != ex)
        	ex.transition().attr("d", chart_phr(data, 'walk', "zero")).remove();
        // Remove line
        ex = null;
       chartBody.selectAll('.ex.axis, .ex.lable').transition().style('opacity', 0).remove();

    } else {
        ex = canvas.append("path").attr("class", "graphline walk").style("stroke", "#5A2903").style("stroke-width", 1.5).attr("d", chart_phr(data, "glc2h", "zero"));
        ex.transition().duration(800).attr("d", chart_phr(data, "walk"));

	axis.append('g')
	      .attr('class', 'ex axis')
	      .attr("transform", "translate(" + (width-padding*1.5) + ",0)")
	      .call(y_r_axis4);
	axis.append('text')
	        // .attr('transform', 'rotate(-90, 0, -20) translate(-210)')
	        .attr('transform', 'translate('+(width-padding*1.5)+',50)')
	        .text('Exercise')
	        .attr('class', 'ex lable')
	        .style('font-size', 25)
	        .attr('text-anchor', 'left')
	        .style('font-size', 12)
	        .style('opacity', 0.8)
	}
}

  var glc_b = document.getElementById('glc'),
      tc_b = document.getElementById('tc'),
      tg_b = document.getElementById('tg'),
      ldl_b = document.getElementById('ldl'),
      hdl_b = document.getElementById('hdl'),
      wgt_b = document.getElementById('wgt');

function drawVariables()
{
drawBloodPressure();
drawGlc();
drawTg();
drawTc();
drawHdl();
drawLdl();
drawWeight();
drawEx();
}


function onClickVariables()
{
  var current_id = d3.select(this).attr("id");

if (current_id == "sbp")
	drawBloodPressure();
else if (current_id == "glc")
	drawGlc();
else if (current_id == "tg")
	drawTg();
else if (current_id == "tc")
	drawTc();
else if (current_id == "hdl")
	drawHdl();
else if (current_id == "ldl")
	drawLdl();
else if (current_id == "wgt")
	drawWeight();
else if (current_id == "ex")
	drawEx();
}

   $( "#ex" ).prop( "checked", true );             
   $( "#sbp" ).prop( "checked", true );             

drawVariables();

zoom.on("zoom", draw);

function draw(){

  chartBody.select(".x.time_axis").call(x_axis);

    $('g:empty').remove();
    canvas.selectAll('.graphline.glc')
          .attr('d', chart_phr(data, "glc2h"));


        canvas.selectAll('.graphline.tg')
          .attr('d', chart_phr(data, "tg"));

        canvas.selectAll('.graphline.tc')
          .attr('d', chart_phr(data, "tc"));

        canvas.selectAll('.graphline.hdlc')
          .attr('d', chart_phr(data, "hdlc"));

        canvas.selectAll('.graphline.ldlc')
          .attr('d', chart_phr(data, "ldlc"));

        canvas.selectAll('.graphline.weight')
          .attr('d', chart_phr(data, "weight"));

        canvas.selectAll('.graphline.sbp')
          .attr('d', chart_phr(data, "sbp"));

        canvas.selectAll('.graphline.dbp')
          .attr('d', chart_phr(data, "dbp"));

        canvas.selectAll('.graphline.walk')
          .attr('d', chart_phr(data, "walk"));
 }
}

function duration_check(d){
  if (d.duration && (d.duration > 100)){
    return Math.ceil(d.duration/60);
  } else if(d.duration && (d.duration < 100)){
      return d.duration/60;
  } else if (d.soft_activity_minutes || d.moderate_activity_minutes || d.intense_activity_minutes){
    var sum = (d.soft_activity_minutes)+(d.moderate_activity_minutes)+(d.intense_activity_minutes);
    return Math.ceil(sum/60);
  } else {

    return null;
  }

  };


function chart_phr(act, name, option){

var chart_calories = d3.svg.line()
    .x(function(d){ return txScale(format1(d.date));})
    .y(function(d){ 
      if (name === 'glc2h') return y_l_Scale1((!option) ? d[name] : 0);
      if (name === 'tg') return y_l_Scale2((!option) ? d[name] : 0);
      if (name === 'tc') return y_l_Scale3((!option) ? d[name] : 0);
      if (name === 'hdlc') return y_r_Scale1((!option) ? d[name] : 0);
      if (name === 'ldlc') return y_r_Scale2((!option) ? d[name] : 0);
      if (name === 'weight') return y_r_Scale3((!option) ? d[name] : 0);
      if (name === 'sbp') return y_r_Scale4((!option) ? d[name] : 0);
      if (name === 'dbp') return y_r_Scale4((!option) ? d[name] : 0);
      if (name === 'walk') return y_r_Scale5((!option) ? d[name] : 0);

    })
    .interpolate('cardinal');

return chart_calories(act);
}

    // Where in the world are you? 
$(document).ready( function() {
   });

console.timeEnd('Data Processing Time');
// console.log('DashboardVis™ by Farzad - v2.0')
*/
