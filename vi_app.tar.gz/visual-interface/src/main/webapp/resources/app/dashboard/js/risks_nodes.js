

function graphTooltipOn(d) {
      // var content = '<div>Risk Factor</br>' + d.name + ' </div>';
      // //console.log("graphTooltipOn: " + d.name);
      // tooltip.html(content).style('visibility', 'visible');
      console.log(d3.select(this))
    };

function graphTooltipMove(d) {
       tooltip.style('top', (d3.event.pageY - 45) + 'px')
       .style('left', (d3.event.pageX - 280) + 'px');
     };

function graphTooltipOff() {
    tooltip.style('visibility', 'hidden');
 };

function linkTooltipOn(d) {
      var content = '<div>Risk Link</br>' + d.source.name + '->' + d.target.name + ' </div>';
      
      tooltip.html(content).style('visibility', 'visible');
    };


var width = document.getElementById('risks_nodes').offsetWidth,
    // height = document.getElementById('risks_nodes').offsetHeight;
    height = 400;

//Set up the colour scale
var color = d3.scale.category20();
//console.log("color array:  " + color);

// var color = ["#000000", "#0000FF", "#FF0000", "#00FFFF", "#AA7700", "#FFFF00"];

//Set up the force layout
var force = d3.layout.force()
    .charge(-200)
    .gravity(0.05)
    .theta(0.8)
    // .friction(0.8)
    // .alpha(0.1)
    // .linkDistance(30)
    // .linkStrength(2)
    .size([width, height]);


//Append a SVG to the body of the html page. Assign this SVG as an object to svg
var svg1 = d3.select("#risks_nodes").append("svg")
    .attr("width", width)
    .attr("height", height);

var guides = d3.select("#guides").append("svg")
    .attr("width", width)
    .attr("height", height);


//Creates the graph data structure out of the json data
d3.json("../share/data/risks.json", function(error, graph) {
  
  force.nodes(graph.nodes)
      .links(graph.links)
      .linkDistance(function(d,i){return (i+11)*4})
      // .linkStrength(2)
      .start();
console.log('NODES', graph.nodes)
console.log('LINKS', graph.links)
//Create all the line svgs but without locations yet

  // // define arrow markers for graph links
  //   var defs = svg1.append('svg:defs');
  //   defs.append('svg:marker')
  //     .attr('id', 'end-arrow')
  //     .attr('viewBox', '0 -5 10 10')
  //     .attr('refX', "32")
  //     .attr('markerWidth', 2)
  //     .attr('markerHeight', 2)
  //     .attr('orient', 'auto')
  //     .append('svg:path')
  //     .attr('d', 'M0,-5L10,0L0,5');

  //   // define arrow markers for leading arrow
  //   defs.append('svg:marker')
  //     .attr('id', 'mark-end-arrow')
  //     .attr('viewBox', '0 -5 10 10')
  //     .attr('refX', 7)
  //     .attr('markerWidth', 1)
  //     .attr('markerHeight', 1)
  //     .attr('orient', 'auto')
  //     .append('svg:path')
  //     .attr('d', 'M0,-5L10,0L0,5');



var link1 = svg1.selectAll(".link")
    .data(graph.links)
    .enter().append("line")
    .attr("class", "link")
    .style("marker-end",  "url(#end-arrow)") //Added 
    .style('stroke-width', function(d){return d.value *3})
    .style('stroke', function(d){return color(d.source.name)})
      // .on('mouseover', linkTooltipOn)
      // .on('mousemove', graphTooltipMove)
      // .on('mouseout', graphTooltipOff);


var gnodes = svg1.selectAll('.node')
  .data(graph.nodes)
  .enter()
  .append('g')
  .classed('gnode', true);

//Do the same with the circles for the nodes - no 
var node1 = svg1.selectAll(".node")
    .data(graph.nodes)
    .enter().append("circle")
    .attr("class", "node")
    .attr("r", function(d){return (d.weight+2) })
    .style("fill", function (d) {
    return color(d.name);
})
    .call(force.drag);
    
      // link1.on('mouseover', graphTooltipOn)
      // .on('mousemove', graphTooltipMove)
      // .on('mouseout', graphTooltipOff);

      

// Append the labels to each group

var labels = gnodes.append("text")
  .text(function(d) { return d.name; });

/*
  node1.append("text")
      .text(function(d) { return d.name; })
      */

//Now we are giving the SVGs co-ordinates - the force layout is generating the co-ordinates which this code is using to update the attributes of the SVG elements
force.on("tick", function () {
    link1.attr("x1", function (d) {
        return d.source.x;
    })
        .attr("y1", function (d) {
        return d.source.y;
    })
        .attr("x2", function (d) {
        return d.target.x;
    })
        .attr("y2", function (d) {
        return d.target.y;
    });

    node1.attr("cx", function (d) {
        return d.x;
    })
        .attr("cy", function (d) {
        return d.y;
    });

      // Translate the groups
  gnodes.attr("transform", function(d) { 
    return 'translate(' + [d.x + 10, d.y + 10] + ')'; 
  });     

});


var guidance = guides.selectAll('svg').data(graph.nodes).enter().append('g');
var guidance_rect = guidance.append('rect')
      .attr('class', function(d,i){return 'guide_'+d.index})
      .attr('x', 10)
      .attr('y', function(d,i){return i*17})
      .attr('width', 20)
      .attr('height', 20)
      .attr('fill', function(d, i){return color(d.name)})
      .attr('transform', 'translate(' + 0 + ',' + 0 + ')')



guidance.append('text')
    .attr('class', 'guidance')
    .attr('x', 30)
    .attr('y', function(d,i){return i*17})
    .attr("dy", "1.20em")
    .attr('fill', 'black')
    .text(function(d){return d.name})
    // .attr("transform", function(d, i) { return "translate(" + ordinalScale(i) + ",3)"; })



});
//---Insert-------
/*
svg1.append("defs").selectAll("marker")
   .data(["end_marker"])
  .enter().append("marker")
    .attr("id", function(d) { return d; })
    .attr("viewBox", "0 -5 10 10")
    .attr("refX", 25)
    .attr("refY", 0)
    .attr("markerWidth", 6)
    .attr("markerHeight", 6)
    .attr("orient", "auto")
  .append("path")
    .attr("d", "M0,-5L10,0L0,5 L10,0 L0, -5")
    .style("stroke", "#4679BD")
    .style("opacity", "0.6");
    */
 
//---End Insert---
  
/*
  var link1 = svg1.selectAll(".link")
      .data(graph.links)
    .enter().append("line")
      .attr("class", "link")
      .style("stroke-width", function(d) { return Math.sqrt(d.value); })
      .on('mouseover', linkTooltipOn)
      .on('mousemove', graphTooltipMove)
      .on('mouseout', graphTooltipOff);

      

  var node1 = svg1.selectAll(".node")
      .data(graph.nodes)
    .enter().append("circle")
      .attr("class", "node")
      .attr("r", 8)
      .style("fill", function(d) { return color(d.group); })
      .call(force.drag)
      .on('mouseover', graphTooltipOn)
      .on('mousemove', graphTooltipMove)
      .on('mouseout', graphTooltipOff);


  node1.append("title")
      .text(function(d) { return d.name; })
      


  });
});
*/
