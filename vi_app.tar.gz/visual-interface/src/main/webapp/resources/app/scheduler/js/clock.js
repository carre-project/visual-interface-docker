/**
 Copyright (c) 2014 BrightPoint Consulting, Inc.

 Permission is hereby granted, free of charge, to any person
 obtaining a copy of this software and associated documentation
 files (the "Software"), to deal in the Software without
 restriction, including without limitation the rights to use,
 copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the
 Software is furnished to do so, subject to the following
 conditions:

 The above copyright notice and this permission notice shall be
 included in all copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 OTHER DEALINGS IN THE SOFTWARE.
 */

function clockVis(parent) {
    var _data=null,
        _duration= 1000,
        _selection,
        _margin = {top:20, right:20, bottom:20, left:20};
		var __width = parent.offsetWidth;
		var __height = parent.offsetHeight;

		if (__width <= 0)
        	__width = 300;
		if (__height <= 0)
        	__height = 300;

        var _diameter = 150,
        _label="",
        _fontSize=10;

		var _radius = _diameter / 2.0 * 0.8;


	var color = { 
			1 : "red",
			2 : "blue"
	};

    var _mouseClick;

    var _value= 0,
        _minValue = 0,
        _maxValue = 100;

    var  _currentArc= 0, _currentArc2= 0, _currentValue=0;

    var _arc = d3.svg.arc()
        .startAngle(0 * (Math.PI/180)); //just radians

    var _arc2 = d3.svg.arc()
        .startAngle(0 * (Math.PI/180))
        .endAngle(0); //just radians


	var _eventList = [];
	var _eventColor = {}; // type color tuples

    _selection=d3.select(parent);

	var _canvas;
	var dayMillis = 24 * 3600 * 1000.0;

	function calTimeAngleSeconds(time , circleSeconds )
	{
		var hour = time.getHours();
		var min = time.getMinutes();
		var sec = time.getSeconds();
	
		var seconds = hour * 3600 + min * 60 + sec;	
	
		// 0 at the bottom of the circle
		var angle = Math.PI + ( seconds )  / circleSeconds * 2 * Math.PI;
		
		return angle;
	}

	function calTimeAngleHour(time )
	{
		return calTimeAngleSeconds(time, 3600);
	}

	function calTimeAngle(time /*, circleMin = 1440 */ )
	{
		var hour = time.getHours();
		var min = time.getMinutes();
		var sec = time.getSeconds();
	
		var seconds = hour * 3600 + min * 60 + sec;	
	
		var angle =  ( seconds )  / (3600 * 24) * 2 * Math.PI;
		
		return angle;

	}

	component.addEvent = function(ev)
	{
		_eventList.push(ev);
	}

	function drawEventList(evList)
	{
		for (var i = 0; i < evList.length; i++)
		{
			drawEvent(evList[i]);
			drawEventHourSpiral(evList[i]);
		}
	}

	function initCanvas()
	{
		// draw arc
        measure();

        _canvas = d3.select(parent).append("svg")
			.attr("class","radial-svg")
   			.attr("width", _width )
       		.attr("height", _width)
	       	.append("g")
		    .attr("transform", "translate(" + _width / 2.0 + "," + _width / 2.0 + ")");
	}

	function clear()
	{

	}

	function drawEventHourSpiral(ev)
	{
		var startTime = ev.startTime;
		var endTime = ev.endTime;
		var type = ev.type;
		var name = ev.name;

		var angleStart = calTimeAngleHour(startTime) ;
		var angleEnd = calTimeAngleHour(endTime);

		var theta = function(r) {
		  //return -2*Math.PI*r;
			return r;
		};
		
		var start=_radius * 0.1;
		var end = _radius * 0.8;

		var radius = d3.scale.linear()
		  .domain([0, Math.PI * 2 * 24])
		  .range([_radius * 0.1 , _radius * 0.8]);
		
		var spiral = d3.svg.line.radial()
		  .interpolate("cardinal")
		  .angle(theta)
		  .radius(radius);
		
		var pieces = d3.range(angleStart, angleEnd+0.001, (angleEnd-angleStart)/1000);
		
			clockRadius = _width / 2.0 * 0.85,
			margin = 15;

		_canvas.selectAll("#" + name)
		    .data([pieces])
		  .enter().append("path")
		    .attr("class", "spiral")
		    .attr("id", name)
		    .attr("d", spiral)
			.style("stroke", color[type])
			.attr("stroke-width", 2)
			.attr("fill", "none")
			//.attr('transform','translate(' + (clockRadius + margin ) + ',' + (clockRadius + margin) + ')')
		    //.attr("transform", function(d) { return "rotate(" + 90 + ")" });
		
	}

	function drawTicks()
	{
		var radians = 0.0174532925, 
			clockRadius = _width / 2.0 * 0.85,
			margin = 20,
			width = (clockRadius+margin)*2,
		    height = (clockRadius+margin)*2,
		    hourHandLength = 2*clockRadius/3,
		    minuteHandLength = clockRadius,
		    secondHandLength = clockRadius-12,
		    secondHandBalance = 30,
		    secondTickStart = clockRadius;
		    secondTickLength = -18,
		    hourTickStart = clockRadius,
		    hourTickLength = -20,
		    secondLabelRadius = clockRadius - 45 ;
		    secondLabelYOffset = 7,
		    hourLabelRadius = clockRadius+ 16; 
		    hourLabelYOffset = 5;
		
		
		var hourScale = d3.scale.linear()
			.range([0,360])
			.domain([0,24]);
		
		var minuteScale = secondScale = d3.scale.linear()
			.range([0,354])
			.domain([0,59]);
		
		var face = _canvas.append('g')
			.attr('id','clock-face')
			//.attr('transform','translate(' + (clockRadius + margin ) + ',' + (clockRadius + margin) + ')');
	
		//add marks for seconds
		face.selectAll('.second-tick')
			.data(d3.range(0,60)).enter()
				.append('line')
				.attr('class', 'second-tick')
				.attr('x1',0)
				.attr('x2',0)
				.attr('y1',secondTickStart)
				.attr('y2',secondTickStart + secondTickLength)
				.attr('transform',function(d){
					return 'rotate(' + secondScale(d) + ')';
				});
		//and labels
	
		face.selectAll('.second-label')
			.data(d3.range(5,61,5))
				.enter()
				.append('text')
				.attr('class', 'second-label')
				.attr('text-anchor','middle')
				.attr('x',function(d){
					return secondLabelRadius*Math.sin(secondScale(d)*radians);
				})
				.attr('y',function(d){
					return -secondLabelRadius*Math.cos(secondScale(d)*radians) + secondLabelYOffset;
				})
				.text(function(d){
					return d;
				});
	
		//... and hours
		face.selectAll('.hour-tick')
			.data(d3.range(0,24,2)).enter()
				.append('line')
				.attr('class', 'hour-tick')
				.attr('x1',0)
				.attr('x2',0)
				.attr('y1',hourTickStart)
				.attr('y2',hourTickStart + hourTickLength)
				.attr('transform',function(d){
					return 'rotate(' + hourScale(d) + ')';
				})
   //.attr('stroke-width', 3)
   //.attr('stroke', "red");
	
		face.selectAll('.hour-label')
			.data(d3.range(2,25,2))
				.enter()
				.append('text')
				.attr('class', 'hour-label')
				.attr('text-anchor','middle')
				.attr('x',function(d){
					return hourLabelRadius*Math.sin(hourScale(d)*radians);
				})
				.attr('y',function(d){
					return -hourLabelRadius*Math.cos(hourScale(d)*radians) + hourLabelYOffset;
				})
				.text(function(d){
					return d;
				});

	}

	// draw event as an arc
	function drawEvent(ev)
	{
		//var angleStart = (startTime.getTime() % dayMillis ) / dayMillis * 2 * Math.PI;
		//var angleEnd = (endTime.getTime() % dayMillis ) / dayMillis * 2 * Math.PI;

		var startTime = ev.startTime;
		var endTime = ev.endTime;
		var type = ev.type;

		var angleStart = calTimeAngle(startTime) ;
		var angleEnd = calTimeAngle(endTime);

		var arc = d3.svg.arc()
		    .innerRadius(_radius * 0.88)
		    .outerRadius(_radius * 0.95)
		    .startAngle(angleStart) //converting from degs to radians
		    .endAngle(angleEnd) //just radians

		var arc1 = d3.svg.arc()
		    .innerRadius(_radius * 0.7)
		    .outerRadius(_radius * 0.8)
		    .startAngle(angleStart) //converting from degs to radians
		    .endAngle(angleEnd * 2) //just radians
	
		console.log("color: " + color[type]);
		_canvas.append("path")
		    .attr("d", arc)
			.attr("class","arc")
            //.attr("transform", "translate(" + _width/2 + "," + _width/2 + ")")
			//.attr("stroke", "red")
			.style("fill", color[type])
            .transition().duration(2000)
            //.attrTween("d", arcTween);

		/*
			vis.append("path")
		    .attr("d", arc1)
			.attr("class","arc2")
            .attr("transform", "translate(" + _width/2 + "," + _width/2 + ")")
			*/
			
	}



	// draw the arcs
    function component() {

        _selection.each(function (data) {

            // Select the svg element, if it exists.
            var svg = d3.select(this).selectAll("svg").data([data]);

            var enter = svg.enter().append("svg").attr("class","radial-svg").append("g");

            measure();

            svg.attr("width", __width)
                .attr("height", __height);


            var background = enter.append("g").attr("class","component")
                .attr("cursor","pointer")
                .on("click",onMouseClick);


            _arc.endAngle(360 * (Math.PI/180))

            background.append("rect")
                .attr("class","background")
                .attr("width", _width)
                .attr("height", _height);

            background.append("path")
                .attr("transform", "translate(" + _width/2 + "," + _width/2 + ")")
                .attr("d", _arc);

            background.append("text")
                .attr("class", "label")
                .attr("transform", "translate(" + _width/2 + "," + (_width + _fontSize) + ")")
                .text(_label);
           var g = svg.select("g")
                .attr("transform", "translate(" + _margin.left + "," + _margin.top + ")");


            _arc.endAngle(_currentArc);
            enter.append("g").attr("class", "arcs");
            var path = svg.select(".arcs").selectAll(".arc").data(data);
            path.enter().append("path")
                .attr("class","arc")
                .attr("transform", "translate(" + _width/2 + "," + _width/2 + ")")
                .attr("d", _arc);

            //Another path in case we exceed 100%
            var path2 = svg.select(".arcs").selectAll(".arc2").data(data);
            path2.enter().append("path")
                .attr("class","arc2")
                .attr("transform", "translate(" + _width/2 + "," + _width/2 + ")")
                .attr("d", _arc2);


            enter.append("g").attr("class", "labels");
            var label = svg.select(".labels").selectAll(".label").data(data);
			/*
            label.enter().append("text")
                .attr("class","label")
                .attr("y",_width/2+_fontSize/3)
                .attr("x",_width/2)
                .attr("cursor","pointer")
                .attr("width",_width)
                // .attr("x",(3*_fontSize/2))
                .text(function (d) { return Math.round((_value-_minValue)/(_maxValue-_minValue)*100) + "%" })
                .style("font-size",_fontSize+"px")
                .on("click",onMouseClick);
				*/

            path.exit().transition().duration(500).attr("x",1000).remove();


            layout(svg);

            function layout(svg) {

                var ratio=(_value-_minValue)/(_maxValue-_minValue);
                var endAngle=Math.min(360*ratio,360);
                endAngle=endAngle * Math.PI/180;

                path.datum(endAngle);
                path.transition().duration(_duration)
                    .attrTween("d", arcTween);

                if (ratio > 1) {
                    path2.datum(Math.min(360*(ratio-1),360) * Math.PI/180);
                    path2.transition().delay(_duration).duration(_duration)
                        .attrTween("d", arcTween2);
                }

                label.datum(Math.round(ratio*100));
                label.transition().duration(_duration)
                    .tween("text",labelTween);

            }

        });

        function onMouseClick(d) {
            if (typeof _mouseClick == "function") {
                _mouseClick.call();
            }
        }
    }

    function labelTween(a) {
        var i = d3.interpolate(_currentValue, a);
        _currentValue = i(0);

        return function(t) {
            _currentValue = i(t);
            this.textContent = Math.round(i(t)) + "%";
        }
    }

    function arcTweenEvent(a) {
        var i = d3.interpolate(_currentArc, a);

        return function(t) {
            _currentArc=i(t);
            return arc.endAngle(i(t))();
        };
    }

    function arcTween(a) {
        var i = d3.interpolate(_currentArc, a);

        return function(t) {
            _currentArc=i(t);
            return _arc.endAngle(i(t))();
        };
    }

    function arcTween2(a) {
        var i = d3.interpolate(_currentArc2, a);

        return function(t) {
            return _arc2.endAngle(i(t))();
        };
    }


    function measure() {
		var w = __width - _margin.left - _margin.right;
		var h = __height - _margin.top - _margin.bottom;
		if (w < h)
				_width = w;
		else 
				_width = h;
        //_width=_diameter - _margin.right - _margin.left - _margin.top - _margin.bottom;
        _height=_width;
		_diameter = _width;
		_radius = _diameter / 2.0 * 0.8;

		_margin.left = _margin.right = (__width - _diameter)/2;
		_margin.top = _margin.bottom = (__height - _diameter)/2;

        _fontSize=_width*.2;
        _arc.outerRadius(_radius);
        _arc.innerRadius(_radius * .85);
        _arc2.outerRadius(_radius * .85);
        _arc2.innerRadius(_radius * .85 - (_radius * .15));
    }


    component.render = function() {
        measure();
		initCanvas();
		drawTicks();
		drawEventList(_eventList);
        //component();
        return component;
    }

    component.value = function (_) {
        if (!arguments.length) return _value;
        _value = [_];
        _selection.datum([_value]);
        return component;
    }


    component.margin = function(_) {
        if (!arguments.length) return _margin;
        _margin = _;
        return component;
    };

    component.diameter = function(_) {
        if (!arguments.length) return _diameter
        _diameter =  _;
        return component;
    };

    component.minValue = function(_) {
        if (!arguments.length) return _minValue;
        _minValue = _;
        return component;
    };

    component.maxValue = function(_) {
        if (!arguments.length) return _maxValue;
        _maxValue = _;
        return component;
    };

    component.label = function(_) {
        if (!arguments.length) return _label;
        _label = _;
        return component;
    };

    component._duration = function(_) {
        if (!arguments.length) return _duration;
        _duration = _;
        return component;
    };

    component.onClick = function (_) {
        if (!arguments.length) return _mouseClick;
        _mouseClick=_;
        return component;
    }

    return component;

}
