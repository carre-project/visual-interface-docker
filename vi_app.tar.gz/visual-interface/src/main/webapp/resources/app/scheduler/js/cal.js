//cal.js by Farzad
//Tidy up the HTML and move the timeline calendar tiles to the different JS

var width = 800,
    height = 700;

//Set up the colour scale
var color = d3.scale.category10();
var monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

//HEIGHT OF THE YEAR, MONTH, AND DAY BOXES
var cellSize = 18;

//Append a SVG to the body
var svg = d3.select("#graphView").append("svg")
    .attr("width", width)
    .attr("height", height)
    .append('g');


var canvas = svg.append('g'); 

canvas.append('rect')
      .attr("class", "timeline")
      .attr("width", width)
      .attr("height", height/2)
      .attr("x", 0)
      .attr("y", height/2.8)

//Get number of days for each month
function numberOfDays(year, month) {

    var d = new Date(year, month, 0);
    console.log(d)
    return d.getDate();
};

var days = new Date();
// var locale = window.navigator.userLanguage || window.navigator.language;
    // monthName = days.toLocaleString(locale, { month: "long" });
var year = days.getFullYear();
// var month = days.getMonth();
// var d3Name = d3.time.format('%B')



var ordinalScale = d3.scale.ordinal()
    // .domain(monthNames)
    // .rangeBands([0, width], .05);
    .rangeBands([0, width]);


//Geting a month number from its string
function getMonthFromString(mon){

   var d = Date.parse(mon + "1, 2012");
   if(!isNaN(d)){
      return new Date(d).getMonth() + 1;
   }
   return -1;
 }

ordinalScale.domain(d3.range(year-10, year+1));



//CREATE A YEAR BOXES
var rectYear = svg.selectAll(".year")
  // .data(function(d) {
  //       return d3.time.years(new Date(year-10, month, 1), new Date(year, month, 1));
  // })
  .data(d3.range(year-10, year+1))
  .enter().append('g');

rectYear.append("rect")
        .attr("class", "year")
        .attr("width", ordinalScale.rangeBand())
        .attr("height", cellSize)
        .attr("x", function(d) { return ordinalScale(d) })
        .attr("y", height-90)

rectYear.append('text')
        .attr('x', ordinalScale.rangeBand()/2)
        .attr('y', height-90)
        .attr("dy", "1.20em")
        .attr('text-anchor', 'middle')
        .attr("transform", function(d) { return "translate(" + ordinalScale(d) + ",0)"; })
        .style('fill', '#fff')
        .text(function(d){return d})





//DRAW DAYS BOXES
function drawDays(year, month){

console.log('APPLIED', year, month)

var current_month = getMonthFromString(month)
var monthDays = numberOfDays(year, current_month);

ordinalScale.domain(d3.range(1, monthDays+1))

var insertion = svg.selectAll("g.days")
  // .data(function(d) {
  //       return d3.time.days(new Date(year, month, 1), new Date(year, month+1, 1));
  // })
  .data(d3.range(1, monthDays+1));
  
//UPDATE EXISTING DATA
insertion.selectAll('.day').transition()
  .attr("width", ordinalScale.rangeBand())
  .attr("x", function(d) { return ordinalScale(d) });

insertion.selectAll('.text_day').transition()
  .attr('x', ordinalScale.rangeBand()/2)
  .attr("transform", function(d) { return "translate(" + ordinalScale(d) + ",0)"; })


//ADD DATA
  var rectDay = insertion.enter().append('g').attr('class', 'days');
  rectDay.append("rect")
  .attr("class", "day")
  .attr("width", ordinalScale.rangeBand())
  .attr("height", cellSize)
  .attr("x", function(d) { return ordinalScale(d) })
  .attr("y", height-70)
  .style('opacity', 0)
  // .attr("transform", function(d) { return "translate(" + ordinalScale(d.getDate()) + ",0)"; });
  // .attr("transform", function(d) { return "translate(" + ordinalScale(d) + ",0)"; });
  // .style('fill', 'none')
  // .style('stroke', 'black')
  // .datum(format);

// rect.append("title")
//   .text(function(d) { return d; });
  .transition()
  .style('opacity', 1)
  .attr("y", height-50);

rectDay.append('text')
  .attr('x', ordinalScale.rangeBand()/2)
  .attr('y', height-70)
  .attr('class', 'text_day')
  .attr("dy", "1.20em")
  .attr('text-anchor', 'middle')
  .attr("transform", function(d) { return "translate(" + ordinalScale(d) + ",0)"; })
  .style('fill', '#fff')
  .text(function(d){return d})
  .transition()
  .attr('y', height-50)



// REMOVE DATA
insertion.exit().transition().attr('y', height-30).style('opacity', 0).remove();


rectDay.on('click', function(d){
        d3.selectAll('.day').attr('class', 'day');
        d3.select(this).select('rect').attr('class', 'day selected');
        d3.selectAll('.d_indicator, g.time.axis').transition().style('opacity', 0).remove();

    canvas.append('text')
          .attr('class', 'd_indicator')
          .attr('x', 10)
          .attr('y', height/2.20)
          .attr('font-size', 20)
          .text(d3.select(this)[0][0].__data__)
       });

rectDay.on('dblclick', function(d){
        d3.selectAll('g.time.axis').remove();
        // d3.selectAll('g:empty').remove();
        drawTimeAxis()
       });

}




//DRAW MONTH BOXES
function drawMonths(year){

ordinalScale.domain(monthNames);

var current_year = year;

var rectMonth = svg.selectAll(".month")
                   .data(monthNames)
                   .enter().append('g')
                   .attr('class', 'months');

rectMonth.append("rect")
         .attr("class", "month")
         .attr("width", ordinalScale.rangeBand())
         .attr("height", cellSize)
         .attr("x", function(d, i) { return ordinalScale(d) })
         .attr("y", height-90)
  // .attr("transform", function(d) { return "translate(" + ordinalScale(d) + ",0)"; });
  // .datum(format);

// rectMonth.append("title")
//   .text(function(d) { return d; });
         .transition()
         .attr("y", height-70)



rectMonth.append('text')
         .attr('x', ordinalScale.rangeBand()/2)
         .attr('y', height-70)
         .attr("dy", "1.20em")
      // .attr('class', 'month text')
         .attr('text-anchor', 'middle')
         .attr("transform", function(d) { return "translate(" + ordinalScale(d) + ",0)"; })
         .style('fill', '#fff')
         .text(function(d){return d});

console.log('Again year is', year)
// dblclick for double
rectMonth.on('click', function(d){
    var month_y = d3.select(this)[0][0].__data__;
    console.log('PASS this value', current_year, month_y, d3.select(this))
    drawDays(year, month_y)
    d3.selectAll('.month').attr('class', 'month');
    d3.selectAll('.day').attr('class', 'day');
    d3.selectAll('.m_indicator, .d_indicator').remove();
    d3.selectAll('g.time.axis').transition().style('opacity', 0).remove();
    d3.select(this).select('rect').attr('class', 'month selected');
  
  canvas.append('text')
    .attr('class', 'm_indicator')
    .attr('x', 10)
    .attr('y', height/2.35)
    .attr('font-size', 20)
    .text(month_y)
})
}

var format = d3.time.format("%I %p");
timeScale = d3.time.scale()
              .range([0, width-2]);




var x_axis = d3.svg.axis()
      // .tickSize(-height, 0)
      .scale(timeScale)
      .tickSize(-10, 0, 0)
      .tickFormat(format);

//DRAW TIME AXIS
function drawTimeAxis(start, end){

timeScale.domain([new Date(2015,08,15), new Date(2015,08,16)])

  var axis = svg.append('g').attr('class', 'time axis');
  axis.append('g')
      .attr('class', 'hours')
      .attr("transform", "translate(0," + (height-15) + ")")
      .call(x_axis)
      .style('opacity', 0)
      .transition()
      .style('opacity', 1)
}








rectYear.on('click', function(d){
  var year = d3.select(this)[0][0].__data__;
  d3.selectAll('.year').attr('class', 'year');
  d3.selectAll('.month').attr('class', 'month');
  d3.selectAll('.day').attr('class', 'day');
  d3.selectAll('.y_indicator, .m_indicator, .d_indicator').remove();
  d3.selectAll('.month, .day, .text_day, g.days, g.months, g.time.axis').transition().attr('y', height-90).style('opacity', 0).remove();
  d3.select(this).select('rect').attr('class', 'year selected');
  drawMonths(year)
  canvas.append('text')
    .attr('class', 'y_indicator')
    .attr('x', 10)
    .attr('y', height/2.5)
    .attr('font-size', 25)
    .attr('font-weight', 'bold')
    .text(year)

});

function mouseOn(d, i) {
      // var content = '<div>Risk Evidence Number : ' + d.z + ' </div>';

      // tooltip.html(content)
      // .style('visibility', 'visible');
      //.attr("x", function(d) {return x(d.x);})
      //.attr("y", function (d) {return y(d.y);});
      d3.select(this).select('rect').style('fill', 'red')
      
    };

function MouseOut() {
    // tooltip.style('visibility', 'hidden');
    d3.select(this).select('rect').style('fill', '#002B6B')
 };

