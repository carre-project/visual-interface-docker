// create a d3.js based  month view calendar
var lang = top.lang;
if (top.lang == "en")
	lang = "en-GB";

moment.locale(lang);

var Calvis = function(dv)
{
	this.div = dv;

	// private members and functions
	this.width = $(this.div).width();
	this.height = $(this.div).height();
	//height = document.getElementById(dv).clientHeight;

	if (this.width == 0)
		this.width = 800;
	if (this.height == 0)
		this.height = 500;

	this.cellWidth = Math.floor(this.width / 7);
	this.cellHeight = Math.floor(this.height / 5);

    //var no_months_in_a_row = Math.floor(width / (cellSize * 7 + 50));
	//this.init();
};

//Calvis.monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
Calvis.monthNames = moment.months();


//Calvis.weekDayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
//Calvis.weekDayNames = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
Calvis.weekDayNames = [];
for (var i = 1; i <= 7; i++)
{
	Calvis.weekDayNames.push(moment.weekdaysShort(i));
}

//console.log(Calvis.weekDayNames);

Calvis.prototype.view = "";
Calvis.prototype.div = null;
Calvis.prototype.svg = null;
Calvis.prototype.tooltip = null;
Calvis.prototype.dates = [];

Calvis.prototype.width = 800;
Calvis.prototype.height = 500;
Calvis.prototype.cellWidth = 80;
Calvis.prototype.cellHeight = 50;
// week name headers
Calvis.prototype.weekHeaderHeight = 20;
Calvis.prototype.heightOffset = 5;

Calvis.prototype.mon = 11;
Calvis.prototype.yr = 2015;

Calvis.prototype.no_months_in_a_row = 1;
//Calvis.prototype.shift_up = cellSize * 3;
Calvis.prototype.day = d3.time.format("%w");
Calvis.prototype.percent = d3.format(".1%");
Calvis.prototype.format = d3.time.format("%d");
Calvis.prototype.day_of_month = d3.time.format("%e"); // day of the month
Calvis.prototype.day_of_year = d3.time.format("%j");
Calvis.prototype.week = d3.time.format("%W"); // week number of the year
Calvis.prototype.month = d3.time.format("%m"); // month number
Calvis.prototype.year = d3.time.format("%Y");
Calvis.prototype.weekNum = 5;
Calvis.prototype.eventList = {};
Calvis.prototype.daySummary = {};

Calvis.prototype.date = d3.time.format("%Y-%m-%d");

Calvis.prototype.clear = function()
{
	svg.selectAll("*").remove();
};

Calvis.prototype.changeYearMonthByDate = function(d)
{
	var y = d.getFullYear();
	var m = d.getMonth();
	this.changeMonth(m, y);
}



Calvis.prototype.changeMonth = function(m, y)
{
	this.mon = m;
	this.yr = y;

	if (this.view == "month")
		$('#currentMonth').text(Calvis.monthNames[m]+  ' ' + y);
	else if (this.view == "year")
		$('#currentMonth').text(y.toString());
	else 
		$('#currentMonth').text("");

	var dateEnd = new Date(y, m + 1, 0);
	var dateNext = new Date(y, m + 1, 1);
	var dateStart = new Date(y, m, 1);

	this.weekNum = this.week(dateEnd) - this.week(dateStart);
	this.weekNum += 1;

	this.cellHeight = Math.floor((this.height - this.weekHeaderHeight) / this.weekNum);

	this.dates =  d3.time.day.range(dateStart, dateNext);
	//this.genDaySummary(this.dates);

};

Calvis.prototype.init = function ()
{
	var today = new Date();
	this.mon = today.getMonth() ;
	this.yr = today.getFullYear();
	
	svg = d3.select(this.div).append("svg")
			.attr("width", this.width)
			.attr("height", this.height)
			.attr("class", "RdYlGn");

    tooltip = d3.select("body")
      .append("div").attr("id", "caltooltip")
      .style("position", "absolute")
      .style("z-index", "10")
      .style("visibility", "hidden")
      .text("a simple tooltip");

	this.setView("month");

	//var dateStart = new Date("2014-01-01");
	//var dateEnd = new Date("2015-12-31");
	//this.genFakeDaySummary(dateStart, dateEnd);
};


Calvis.prototype.getDayRectOffset = function(d)
{
	var pos = {};
	var weekday = ( Number(this.day(d)) + 6) % 7;
	pos.x = weekday * this.cellWidth; 
	var week_diff = Number(this.week(d)) - Number(this.week(new Date(this.year(d), this.month(d)-1, 1) ) );
	//pos.y =  this.weekHeaderHeight + week_diff*cellHeight + 5;
	pos.y = week_diff*this.cellHeight + 5;

	return pos;
}

Calvis.prototype.getDayCellOffset = function(d)
{
	var pos = {};
	pos.x =  ( this.day(d) + 6 ) % 7;
	pos.y = Number(this.week(d)) - Number(this.week(new Date(this.year(d), this.month(d)-1, 1) ) );
	return pos;
}


Calvis.prototype.getMonthViewTranslate = function()
{
	var pos= {};
	pos.x = (this.width - this.cellWidth * 7) / 2;
	pos.y = this.height -  this.cellHeight * this.weekNum - this.heightOffset;
	return pos;
}


Calvis.prototype.renderMonthViewGrid = function()
{
	
	var me = this;
	var pos = $("#mainwrapper").position();

    var trans = this.getMonthViewTranslate();
	var cells =	svg.append("g")
		.attr("transform", "translate(" + trans.x + "," + trans.y + ")");

	// draw week header
	cells.selectAll(".weekday")
		.data(d3.range(0, 7))
        .enter().append("rect")
		.attr("id", function(d) { return Calvis.weekDayNames[d]; } )
		.attr("class", "weekday")
		.attr("width", me.cellWidth)
		.attr("height", this.weekHeaderHeight)
		.attr("x", function(d) { return d * me.cellWidth; } )
		.attr("y", -this.weekHeaderHeight + this.heightOffset)
	    .style("fill", '#ABC')
	    .style("stroke", '#555');

	// day rectangle
	var cells1 = svg.append("g")
		.attr("transform", "translate(" + trans.x + "," + trans.y + ")");
	var rect = cells1.selectAll(".calday")
		.data(me.dates)
		.enter().append("rect")
		.attr("id", function(d){   return "d" + me.date(d);  })
		.attr("class", "calday")
		.attr("width", me.cellWidth)
		.attr("height", me.cellHeight)
		.attr("x", function(d, i) { return me.getDayRectOffset(d).x; })
		.attr("y", function(d, i) { return me.getDayRectOffset(d).y; })
		//.on('mouseover', function(d) { me.rectMouseover(d, me); })
	     //.on('mouseout', me.rectMouseout)
	     .on('click', function(d) {
			for (var i = 0; i < me.dates.length; i++)
			{
					var cat = me.daySummary[me.date(me.dates[i])];
					var color = "#FFF";
					if (cat != undefined )
							color = color_cat(cat);
					else
							color = "#FFF";

					if (color == undefined )
							color = color_cat(cat);

     			svg.select("rect[id='d" + me.date(me.dates[i]) + "']") 
	    			.style('fill', color)
	     			.style("stroke", '#555')
	     			.style("stroke-width", '1');
			}

	    	d3.select(this).style("stroke-width", '5')
	     					.style("stroke", '#0FF');
			 // call Farzad's API to swtich to day view
			var dateStr = formatDate(d, "yyyy-MM-dd");
			//movesGo('clock', dateStr, dateStr, null);

			//Highlight on the timeline
	        var highlight_day = d.getDate();
	        d3.selectAll('.daycal:not(.d_'+highlight_day+')').classed('selected', false);
	        d3.selectAll('.daycal.d_'+highlight_day).classed('selected', true);
	     })
	     .style("fill", function(d) {
				var dateStr = me.date(d);
				var cat = me.daySummary[dateStr];
				var color = "#FFF";
				if (cat != undefined )
					color = color_cat(cat);
				else
					color = "#FFF";
				if (color == undefined )
					color = "#FFF";

				return color;
		 })
	     .style("fill-opacity", '1.0')
	     .style("stroke", '#555')
	     .style("stroke-width", '1');
};

				 /*
				 // draw a test arc
			var indexedPieData = [20, 30, 50];
			var arc = d3.svg.arc()
				.startAngle(0)
				.endAngle(5.0)
				.innerRadius(10)
				.outerRadius(cellHeight / 2.0);

			//d3.select(this) //.data(indexedPieData)
			var pos = d3.mouse(this);
			svg.append("g")
				.attr("class", "arc")
				.attr("transform", "translate(" + (pos[0] + 0) + ", " + ( pos[1] + 0 ) + ")")
				.append("path")
				.attr("fill", "red")
				.attr("stroke", "black")
				.attr("stroke-width", 2)
				.attr("d", function(d){
					return arc();
				});
				*/

Calvis.prototype.renderMonthViewDays = function()
{
    var pos = this.getMonthViewTranslate();
	var dateText = svg.append("g")
		.attr("transform", "translate(" + pos.x + "," + pos.y + ")");
	//.attr("transform", "translate(" + ((this.width - cellWidth * 7) / 2) + "," + (this.height -  cellHeight * weekNum - 5) + ")");
	var me = this;

	// add week header text
	dateText.selectAll(".weekdayname")
		.data(d3.range(0, 7))
        .enter().append("text")
		.attr("class", "weekdayname")
        .attr("x", function (d) { return Math.floor((d + 0.5) * me.cellWidth); })
		.attr("y", -0.5 * this.weekHeaderHeight + this.heightOffset + 3)
        //.attr("dx", d3CalendarGlobals.gridXTranslation + 5) // right padding
        //.attr("dy", 30) // vertical alignment : middle
        .text(function (d) { return Calvis.weekDayNames[d]; })
		.style("text-anchor", "middle");

	dateText.selectAll(".caldate")
	.data(me.dates)
	.enter().append("text")
	.attr("class", "caldate")
	.attr("x", function(d, i) { 
			return me.getDayRectOffset(d).x;
	})
	.attr("y", function(d, i) {
			return me.getDayRectOffset(d).y + 10;
	})
	.datum(me.format)
 	.text(function(d) { return d; });
};

Calvis.prototype.displayPrevious = function() {

	var mon = this.mon;
	var yr = this.yr;
	if (this.view == "month")
	{
		mon -= 1;
		if (mon < 0)
		{
			yr -= 1;
			mon = 11;
		}
	}
	else if (this.view == "year")
	   yr -= 1;

	this.changeMonth(mon, yr);
	//// Change the timeline based on the calendar
	var starting = new Date(yr, mon, 1);
	var  start = moment(starting).format('YYYY-MM-DD');
	var end = moment(starting).endOf('month').format('YYYY-MM-DD');
	 d3.selectAll('.month').classed('selected', false)
	 d3.select('.month.m_'+mon).classed('selected', true)

	this.updateCalendar();
};

Calvis.prototype.displayNext = function(){
	var mon = this.mon;
	var yr = this.yr;

	if (this.view == "month")
	{
		mon += 1;
		if (mon >= 12)
			yr += 1;
		mon  %= 12;
	}
	else if (this.view == "year")
		yr += 1;

	this.changeMonth(mon, yr);
	
	// Change the timeline based on the calendar
	var starting = new Date(yr, mon, 1);
	var  start = moment(starting).format('YYYY-MM-DD');
	var end = moment(starting).endOf('month').format('YYYY-MM-DD');
	 d3.selectAll('.month').classed('selected', false)
	 d3.select('.month.m_'+mon).classed('selected', true)

	this.updateCalendar();
};



Calvis.prototype.rectMouseover = function (d, obj) {

	    //d3.select(this).style('fill', '#0F0');
        //tooltip.style("visibility", "visible");
        //var percent_data = (data[d] !== undefined) ? percent(data[d]) : percent(0);
        var percent_data = "20%";
        var purchase_text = obj.day_of_year(d) + ": " + percent_data;

        tooltip.transition()        
                    .duration(200)      
                    .style("opacity", .9);      
        tooltip.html(purchase_text)  
                    .style("left", (d3.event.pageX)+30 + "px")     
                    .style("top", (d3.event.pageY) + "px"); 

     	svg.select("rect[id='d" + obj.date(d) + "']") 
	    .style('fill', '#0F0');
        //tooltip.style("visibility", "visible");
}

Calvis.prototype.rectMouseout = function (d) {
	    d3.select(this).style('fill', '#FFF');

		/*
        tooltip.transition()        
                .duration(500)      
                .style("opacity", 0); 
        var $tooltip = $("#tooltip");
        $tooltip.empty();
		*/
}

Calvis.prototype.setEventList = function (el) 
{
	this.eventList.length = 0;
	this.addEventList(el);
	this.updateCalendar();

    getDailySummary();
    this.setDaySummary();

}

Calvis.prototype.genFakeDaySummary = function (dateStart, dateEnd) 
{
	var dateList =  d3.time.day.range(dateStart, dateEnd);
	var dateStr;
	for (var i = 0; i < dateList.length; i++)
	{
		dateStr = formatDate(dateList[i], "yyyy-MM-dd");
		this.daySummary[dateStr] = Math.floor((Math.random() * 14));
	}
}

Calvis.prototype.setDaySummary = function () 
{

	if (this.daySummary.length > 0)
		return;
	//this.daySummary.length = 0;
	 var me = this;

  if (!top.t__mha__m) {
    return;
  }

  if (!top.t__mha__m.summary) {
	return;
  }

	var summary = top.t__mha__m.summary;

	$.each(summary, function(i, val) 
	{		
		me.daySummary[val.date] = categories.indexOf(val.category);
	});

	//console.log(top.t__mha__m.summary);

}

Calvis.prototype.addEventList = function (el) 
{
    //console.log("AddEventList");
	for (var i = 0; i < el.length; i++)
	{
		this.addEvent(el[i]);
	}

	console.log("Calendar EventList:");
	console.log(this.eventList);
}

// add a single event
Calvis.prototype.addEvent = function (item) 
{
	if (item.start_time == undefined)
		return;

    var date = item.start_time.substring(0,10);
	var el = [];
	if ( this.eventList[date] == undefined )
	{
		el.push(item);
		this.eventList[date] = el;
	}
	else 
	{
		el = this.eventList[date];
		el.push(item);
	}
}

Calvis.prototype.drawEventOfCurrentMonth = function () 
{

	// clear other icons
	svg.selectAll("#icons").remove();

	var dateEnd = new Date(this.yr, this.mon + 1, 0);
	var dateStart = new Date(this.yr, this.mon, 1);

	for (var d = dateStart; d <= dateEnd; d.setDate(d.getDate() + 1)) 
	{
		var dateStr = formatDate(d, "yyyy-MM-dd");
		var el = this.eventList[dateStr];
		if (el != undefined )
		{
		   for (var i = 0; i < el.length; i++)
		     this.drawEvent(el[i]);
		}
	}
}

Calvis.prototype.drawEventOfCurrentYear = function () 
{

	// clear other icons
	svg.selectAll("#icons").remove();

	var dateEnd = new Date(this.yr, 11, 31);
	var dateStart = new Date(this.yr, 0, 1);

	for (var d = dateStart; d <= dateEnd; d.setDate(d.getDate() + 1)) 
	{
		var dateStr = formatDate(d, "yyyy-MM-dd");
		var el = this.eventList[dateStr];
		if (el != undefined )
		{
		   for (var i = 0; i < el.length; i++)
		     this.drawEvent(el[i]);
		}
	}
}

// Youbing 2016.7.7 to change this for CARRE
Calvis.prototype.drawEvent = function (item) 
{

    var startTime = item.start_time.substring(11,16);
    var endTime = item.end_time.substring(11,16);

	//var date = item.end_time.substring(0, 10);
	var iconUrl = "";

    if (item.type == "place")
    {
      var place = item.place;
      var lat = place.location.lat;
      var lon = place.location.lon;

	  var type = place.type;
	  if (undefined == type)
		console.log("type NA");
      //var type = 'unknown';
      if (place["mha"] != undefined )
      {
        name = place.mha.name;
        type = place.mha.category;
      }

      type = Cat_maping(type);

	if (undefined == type)
	{
		console.log("type undefined");
		type = "unknown";
	}

	  iconUrl = '/icon/' + iconPos[ type.toLowerCase() ];
	
	}
	else if ( (item.activity == "transport")
        || (item.activity == "running")
        || (item.activity == "walking")
        || (item.activity == "running")
        || (item.activity == "cycling") )

	{
		// do nothing
		var type = "transport";
		iconUrl = '/icon/' + iconPos[ type.toLowerCase() ];
	}

	var me = this;
	var wImg = 32;
	var hImg = 32;
	var trans, pos;
	var g;
    var dateStr = item.start_time.substring(0,10);
	var date = new Date(dateStr);	
	this.changeYearMonthByDate(date);

	if (this.view == "month")
	{
		pos = this.getDayRectOffset(date);

        trans = this.getMonthViewTranslate();
    	g = svg.append("g")
    			.attr("transform", "translate(" + trans.x + "," + trans.y + ")")
    			.attr("id", "icons");
    
    	var img = g.append("svg:image")
        .attr("xlink:href", iconUrl)
        .attr("width", wImg) 
        .attr("height", hImg)
        .attr("x", pos.x + me.cellWidth / 2.0 - wImg / 2.0)
        .attr("y", pos.y + me.cellHeight /2.0 - hImg / 2.0)
	    .on('click', function(d) {

			for (var i = 0; i < me.dates.length; i++)
			{
				var cat = me.daySummary[me.date(me.dates[i])];
				var color = "#FFF";
				if (cat != undefined )
					color = color_cat(cat);
				if (color == undefined )
					color = "#FFF";

     			svg.select("rect[id='d" + me.date(me.dates[i]) + "']") 
	    			.style('fill', color)
	     			.style("stroke", '#555')
	     			.style("stroke-width", '1');
			}

     		svg.select("rect[id='d" + me.date(date) + "']") 
	    		.style("stroke-width", '5')
	    		.style('fill', '#0FF');
			 // call Farzad's API to swtich to day view
			var dateStr = formatDate(date, "yyyy-MM-dd");
			//movesGo('clock', dateStr, dateStr, null);
	        //console.log(d3.select(this));
	        //Highlight on the timeline
	        var highlight_day = date.getDate();
	        d3.selectAll('.daycal:not(.d_'+highlight_day+')').classed('selected', false);
	        d3.selectAll('.daycal.d_'+highlight_day).classed('selected', true);
	     });

   }
	else if (this.view == "year")
	{
		this.changeYearMonthByDate(date);
        trans = this.getYearViewTranslate();
    	g = svg.append("g")
    			.attr("transform", "translate(" + trans.x + "," + trans.y + ")")
    			.attr("id", "icons");
    
		var year = date.getFullYear();
		var month = date.getMonth();

		pos = this.getMonthRectOffset(month);

    	var img = g.append("svg:image")
        .attr("xlink:href", iconUrl)
        .attr("width", wImg) 
        .attr("height", hImg)
        .attr("x", pos.x + me.cellWidthYr / 2.0 - wImg / 2.0)
        .attr("y", pos.y + me.cellHeightYr /2.0 - hImg / 2.0);
 
	}
}


// show event icons on the calendar
Calvis.prototype.drawEventList = function (el) 
{
	eventList = el;

	// draw events on the current month

}

// month per row
Calvis.prototype.nYearRow = 3;
// month per col
Calvis.prototype.nYearCol = 4;
Calvis.prototype.cellWidthYr = 40;
Calvis.prototype.cellHeightYr = 40;
Calvis.prototype.marginYr = 5;
Calvis.prototype.spaceYr = 25;

Calvis.prototype.getYearViewTranslate = function()
{
	var pos = {};
	pos.x = 0;
	pos.y = 0;

	return pos;
}

Calvis.prototype.getMonthRectOffset = function(d)
{
	var pos = {};

	var r = Math.floor(d % this.nYearRow);
	pos.x = this.marginYr + r * this.cellWidthYr + r * this.spaceYr; 


	var c = Math.floor( d / this.nYearRow);
	pos.y = this.marginYr + c * this.cellHeightYr + (c + 1) * this.spaceYr; 

	return pos;
}


// year view
Calvis.prototype.renderYearView = function () 
{
	this.clear();
	var me = this;

	this.nYearCol = Math.ceil ( 12 / this.nYearRow );
	this.cellWidthYr = Math.floor((this.width - this.marginYr * 2 - (this.nYearRow -1) * this.spaceYr ) / this.nYearRow );
	this.cellHeightYr = Math.floor( (this.height - this.marginYr * 2 - (this.nYearCol ) * this.spaceYr) / this.nYearCol);

	// draw rectangles
    var trans = this.getYearViewTranslate();
	var cells =	svg.append("g")
		.attr("transform", "translate(" + trans.x + "," + trans.y + ")");

	// draw week header
	cells.selectAll(".yearMonth")
		.data(d3.range(0, 12))
        .enter().append("rect")
		.attr("id", function(d) { return Calvis.monthNames[d]; } )
		.attr("class", "yearMonth")
		.attr("width", this.cellWidthYr)
		.attr("height", this.cellHeightYr)
		.attr("x", function(d) 
			{ return me.getMonthRectOffset(d).x; })
		.attr("y", function(d)
			{ return me.getMonthRectOffset(d).y; })
		.on('mouseout', function(d) {
     		//svg.select("rect[id='" + Calvis.monthNames[d] + "']") 
	    		//.style('fill', '#ABC');
			})
	     .on('mouseover', function(d) {
			for (var i = 0; i < 12; i++)
     			svg.select("rect[id='" + Calvis.monthNames[i] + "']") 
	    			.style('fill', '#ABC');

     		svg.select("rect[id='" + Calvis.monthNames[d] + "']") 
	    			.style('fill', '#0FF');
		  	})
	     .on('click', function(d) {
				me.changeMonth(d, me.yr);
				me.setView("month");

				//var dateEnd = new Date(me.yr, me.mon + 1, 0);
				//var dateStart = new Date(me.yr, me.mon, 1);
				var dateStartStr = formatDate(me.dates[0], "yyyy-MM-dd");
				var dateEndStr = formatDate(me.dates[me.dates.length -1], "yyyy-MM-dd");
				//movesGo('day', dateStartStr, dateEndStr, null);
	        //console.log(d3.select(this));

	     })
	    .style("fill", '#ABC')
	    .style("stroke", '#555');


	// add text
	var dateText = svg.append("g")
		.attr("transform", "translate(" + trans.x + "," + trans.y + ")");

	dateText.selectAll(".monthname")
	.data(d3.range(0, 12))
	.enter().append("text")
	.attr("class", "monthname")
	.attr("x", function(d) { 
		return me.getMonthRectOffset(d).x + me.cellWidthYr / 2.0;
	})
	.attr("y", function(d) {
		return me.getMonthRectOffset(d).y - me.spaceYr / 2.0 + 8.0;
	})
 	.text(function(d) { return Calvis.monthNames[d]; })
	.style("text-anchor", "middle");

	this.drawEventOfCurrentYear();
}

Calvis.prototype.updateCalendar = function ()
{
	if (this.view == "year")
			this.renderYearView();
	else if (this.view == "month")
			this.renderMonthView();

};

Calvis.prototype.setView = function (v)
{
	if ((v != "month" ) && ( v != "year" ))
		return;

	if (v == "month")
	{
		$('#month').attr('class', 'btn btn-default btn-xs active');
		$('#year').attr('class', 'btn btn-default btn-xs');
	}
	else if (v == "year")
	{
		$('#year').attr('class', 'btn btn-default btn-xs active');
		$('#month').attr('class', 'btn btn-default btn-xs');
	}

	if (this.view != v)
	{
		this.view = v;
		this.updateCalendar();
	}

	this.changeMonth(this.mon, this.yr);
}

Calvis.prototype.renderMonthView = function ()
{
	this.clear();
	this.renderMonthViewGrid()
	this.renderMonthViewDays();
	this.drawEventOfCurrentMonth();
};


//var cal;

$(document).ready( function (){
	//document.getElementById("yearBtn").disabled = true;
	//document.getElementById("monthBtn").disabled = true;

	cal = new Calvis("#calendar");
	cal.init();

	//var summary = getDailySummary();
	// load moves data
	/*
	$.ajax({
            url: "f_segments.json",
            type: 'GET',
			async: false,
            dataType: 'json',
            success:  function(data) {
				var seg = data.segments;
				cal.addEventList(seg);
            }
     });
	*/
	$('#back').click(function() { cal.displayPrevious(); });
	$('#forward').click(function() { cal.displayNext(); } );
	cal.updateCalendar();

	}
);

