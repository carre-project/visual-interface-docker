var listRf = []; // risk factor
var listRiskElem = {}; // risk element
var listRiskEv = {}; // risk element

// in user.js
var listRiskObsAll = {}; // risk observables

var prefixMeasurement = "http://carre.kmi.open.ac.uk/ontology/sensors.owl#";
var prefixElem = "http://carre.kmi.open.ac.uk/risk_elements/";
//var prefixRf = "http://carre.kmi.open.ac.uk/CARRE_";
var prefixRf = "http://carre.kmi.open.ac.uk/risk_factors/";
var prefixObs = "http://carre.kmi.open.ac.uk/observables/";
var prefixEv = "http://carre.kmi.open.ac.uk/risk_evidences/";

function IndexOfRiskFactor(nameRf)
{
	var rfId;
	if (nameRf.indexOf(prefixRf) == 0)
		rfId = nameRf.substring(prefixRf.length);
	else
		rfId = nameRf;

	for (var i = 0; i < listRf.length; i++)
	{
		if (listRf[i].id == rfId)
			return i;
	}

	return -1;
}

function AddRiskFactor(nameRf)
{
	if ( -1 != IndexOfRiskFactor(nameRf))
		return;

	var rf = { id: nameRf.replace(prefixRf, ""), source: "", target: "", evidence: [ ] };
	listRf.push(rf);

	return listRf.length - 1;
}

function AddRiskFactorSource(nameRf, nameObj)
{
	var rfId = IndexOfRiskFactor(nameRf);
	if ( -1 == rfId)
		rfId = AddRiskFactor(nameRf);

	listRf[rfId].source = nameObj.replace(prefixElem, "");
}

function AddRiskFactorTarget(nameRf, nameObj)
{
	var rfId = IndexOfRiskFactor(nameRf);
	if ( -1 == rfId)
		rfId = AddRiskFactor(nameRf);

	listRf[rfId].target = nameObj.replace(prefixElem, "");
}

function AddRiskFactorEvidence(nameRf, nameObj)
{
	var rfId = IndexOfRiskFactor(nameRf);
	if ( -1 == rfId)
		rfId = AddRiskFactor(nameRf);

	listRf[rfId].evidence.push(nameObj.replace(prefixEv, "") );
}

// 1
function GetUserRiskEvidenceList()
{

	if (top.carre == undefined)
		top.carre = {};
	//if (top.carre.listRiskFactor != undefined)
	//	return top.carre.listRiskFactor;

	// observable, clinical_observable, personal_observable, risk_element, biomedical_risk_element, behavioural_risk_element, genetic_risk_element, demographic_risk_element, risk_factor, risk_evidence, citation
	console.log("GetUserRiskEvidenceList");

	var filter = "";
	if (top.carre.obsStr == "")
		filter = "";
	else
		filter = " VALUES ?p {  \n "+ top.carre.obsStr +" }  \n ";
	
		filter = "";
	var query = 
    'PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>' +
    'PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>' +
    'PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>' +
    'PREFIX : <http://carre.kmi.open.ac.uk/ontology/sensors.owl#>' +
    'PREFIX risk: <http://carre.kmi.open.ac.uk/ontology/risk.owl#>' +
    'PREFIX carreManufacturer: <http://carre.kmi.open.ac.uk/manufacturers/>' +
    'PREFIX carreUsers: <https://carre.kmi.open.ac.uk/users/>' +

	"SELECT DISTINCT ?risk_evidence ?condition ?confidence_interval_min ?confidence_interval_max ?risk_evidence_ratio_value ?risk_evidence_ratio_type ?risk_factor ?has_risk_factor_source ?has_risk_factor_target ?has_risk_factor_association_type FROM <http://carre.kmi.open.ac.uk/riskdata> WHERE {  \n "+
	"  ?risk_evidence a risk:risk_evidence ;  \n "+
	"  risk:has_risk_factor ?risk_factor;  \n "+
	" risk:has_risk_evidence_ratio_type ?risk_evidence_ratio_type;  \n "+
	"   risk:has_risk_evidence_ratio_value ?risk_evidence_ratio_value;  \n "+
	"   risk:has_confidence_interval_max ?confidence_interval_max;  \n "+
	"   risk:has_confidence_interval_min ?confidence_interval_min;  \n "+
	"   risk:has_risk_evidence_observable ?ob ;  \n "+
	"   risk:has_observable_condition ?condition .  \n "+
	" #details for risk factor  \n "+
	" ?risk_factor risk:has_risk_factor_association_type ?has_risk_factor_association_type;  \n "+
	" risk:has_risk_factor_source ?has_risk_factor_source;  \n "+
	" risk:has_risk_factor_target ?has_risk_factor_target.  \n "+
	" {  \n "+
	"  SELECT ?ob FROM <http://carre.kmi.open.ac.uk/riskdata> WHERE {  \n "+
	"  ?ob a risk:observable ;  \n "+
	"         risk:has_external_predicate ?p.    \n "+
	filter + 
	//" VALUES ?p {  \n "+ top.carre.obsStr +" }  \n "+
	" }  \n " +
	" }  \n " +
	" }";
	

	var results = {};
    var defaultURI = "https://carre.kmi.open.ac.uk/public";
    //var url = "http://carre.kmi.open.ac.uk:8890/sparql?";
    var url = "https://carre.kmi.open.ac.uk/ws/query?";
    //url += "default-graph-uri=" + encodeURIComponent(defaultURI) + "&query=" + encodeURIComponent(query);
    url += "token=" + top.carre.token + "&sparql=" + encodeURIComponent(query);
                
    $.ajax({
        dataType: 'json',
        method: 'POST',
        url: url,
		async : false,
        success: function(data) {
           	//console.log('success: ' + data.results.bindings.length + ' results');
            console.log(data);
            results.risk_evidences=[];
          	results.total_risk_evidences=data.length;
          	data.forEach(function(rv) {   
            	var result=RiskEvidenceConditionParser.evaluate(rv.condition.value,top.carre.obsValues);
				console.log(result + ":" + rv.condition.value);
            	if(result) 
					results.risk_evidences.push(rv);
            
          })
		  top.carre.userRiskEv = results;
     	}
     });


	console.log(top.carre.userRiskEv);

	return top.carre.userRiskEv;
}


function AddRiskElement(nameElem)
{
	nameElem = nameElem.replace(prefixElem, "");
	var item = { name: "", observable: [ ] };
	listRiskElem[nameElem] = item;
}

function SetRiskElementName(nameElem, nameText)
{
	nameElem = nameElem.replace(prefixElem, "");
	if (undefined == listRiskElem[nameElem])
		AddRiskElement(nameElem);

	listRiskElem[nameElem].name = nameText;

}

function AddRiskElementObservable(nameElem, nameObs)
{
	nameElem = nameElem.replace(prefixElem, "");
	if (undefined == listRiskElem[nameElem])
		AddRiskElement(nameElem);

	nameObs = nameObs.replace(prefixObs, "");

	listRiskElem[nameElem].observable.push(nameObs);
}


function printTripleList(data)
{
	for (var i = 0; i < data.length; i++)
	{
		console.log('Subject: ' + data[i].subject);
		console.log('Predicate: ' + data[i].predicate);
		console.log('Object: ' + data[i].object);
	}
}

// 2
function GetRiskElementList()
{
	console.log("GetRiskElementList");

	if (top.carre == undefined)
		top.carre = {};
	if (top.carre.listRiskElem != undefined)
		return top.carre.listRiskElem;
	
	var url;

/*
                //var link = "http://carre.kmi.open.ac.uk/elements/" + id;
                var link = "http://carre.kmi.open.ac.uk/elements/";
                //var query = "select ?y ?z WHERE { <" + link + "> ?y ?z . }";
                var defaultURI = "https://carre.kmi.open.ac.uk/riskdata";
                //var query = "select ?riskElemName ?z FROM <" + defaultURI + "> WHERE { ?x ?y ?z . }";

var query = "PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>" + 
"PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>" + 
"PREFIX carreUsers: <https://carre.kmi.open.ac.uk/users/>" + 
"PREFIX risk: <http://carre.kmi.open.ac.uk/ontology/risk.owl#>" + 
"SELECT * FROM <http://carre.kmi.open.ac.uk/riskdata> WHERE {" + 
"    ?id a risk:risk_element;" +
"risk:has_risk_element_name ?name." +
"        OPTIONAL {?id risk:has_author ?author}" + 
"        OPTIONAL {?id risk:has_risk_evidence_observable ?observable}" + 
"        OPTIONAL {?id risk:has_risk_element_modifiable_status ?modifiable}" +
"        OPTIONAL {?id risk:has_educational_material ?educational}" +
"    FILTER (lang(?name)='el')" + 
"}";
                
                //var url = "http://carre.kmi.open.ac.uk:8890/sparql?";
                url = "https://carre.kmi.open.ac.uk/ws/query?";
                //url += "default-graph-uri=" + encodeURIComponent(defaultURI) + "&query=" + encodeURIComponent(query);
                url += "sparql=" + encodeURIComponent(query);
                
                $.ajax({
                    dataType: 'json',
                    method: "POST",
                    url: url,
                    success: function(data) {
                        //console.log('success: ' + data.results.bindings.length + ' results');
			console.log('GetRiskElement Success');
            console.log(data);

			for (var i = 0; i < data.length; i++)
			{
				var item = data[i];
			    AddRiskElement(item.id.value);
			    SetRiskElementName(item.id.value, item.name.value);
			    //AddRiskElementObservable(item.id.value, item.object);
				//if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_element_observable" )
				//{
					//AddRiskElementObservable(item.subject, item.object);
				//}

            }
		}
     });
				*/

	url = "https://carre.kmi.open.ac.uk/ws/instances?type=risk_element&language=" + top.lang; 
	$.ajax({
		dataType: 'json',
		url: url,
		async: false,
		success: function(data) {
			console.log('GetRiskElement Success');
			for (var i = 0; i < data.length; i++)
			{
				var item = data[i];
				if (item.predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")
				{
					if (item.object == "http://carre.kmi.open.ac.uk/ontology/risk.owl#risk_element")
						AddRiskElement(item.subject);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_element_name")
				{
					console.log(item);
					SetRiskElementName(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_element_observable" )
				{
					AddRiskElementObservable(item.subject, item.object);
				}

			}

			top.carre.listRiskElem = listRiskElem;
			console.log("Number of risk elements: " + Object.keys(listRiskElem).length)
			console.log( Object.keys(listRiskElem) );
		}
	});

	return top.carre.listRiskElem;
}


function AddRiskEvidence(id)
{
	id = id.replace(prefixEv, "");
	var item = {
		number: "",
		//name: "", 
		obs: "",
		obsExp: "",
		adjusted: [],
		ratioVal: "",
		confiInterval: ""

	};

	listRiskEv[id] = item;
}

function GetRiskEvidenceId(id)
{
	id = id.replace(prefixEv, "");
	if (undefined == listRiskEv[id])
		AddRiskEvidence(id);

	return id;
}

function SetRiskEvidenceObsExp(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].obsExp = str;
}

function SetRiskEvidenceNumber(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].number = str;
}

function SetRiskEvidenceObs(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].obs = str.replace(prefixObs, "");
}

function SetRiskEvidenceRatioVal(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].ratioVal = str;
}


function SetRiskEvidenceConfiInterval(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].confiInterval = str.replace(prefixRf, "");
}

var prefixTax = "http://carre.kmi.open.ac.uk/taxonomy_term/";

function AddRiskEvidenceAdjusted(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].adjusted.push(str.replace(prefixTax, "") );
}

// 3
function GetRiskEvidenceList()
{
	// use caching
	if (undefined != top.carre.listRiskEv) 
		return;

	console.log("GetEvidenceList");
	var url = "https://carre.kmi.open.ac.uk/ws/instances?type=risk_evidence"; 

	$.ajax({
		dataType: 'json',
		url: url,
		async: false,
		success: function(data) {
			//console.log('GetRiskElement Success: ' + data);
			console.log('GetRiskEvidence Success');
			//printTripleList(data);

			for (var i = 0; i < data.length; i++)
			{
				var item = data[i];
				if (item.predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")
				{
					if (item.object == "http://carre.kmi.open.ac.uk/ontology/risk.owl#risk_evidence")
						AddRiskEvidence(item.subject);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_id")
				{
					// not useful
					SetRiskEvidenceNumber(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_observable_expression" )
				{
					SetRiskEvidenceObsExp(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_observable")
				{
					SetRiskEvidenceObs(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_ratio_value")
				{
					SetRiskEvidenceRatioVal(item.subject, item.object);	
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_confidence_interval")
				{
					SetRiskEvidenceConfiInterval(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#is_adjusted_for" ) 
				{
					AddRiskEvidenceAdjusted(item.subject, item.object);
				}

				//
				//"http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_ratio_type"
				//"http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_source_type"

			}

			console.log("Number of risk evidence: " + Object.keys(listRiskEv).length)
			console.log( Object.keys(listRiskEv) );
			top.carre.listRiskEv = listRiskEv;
		}
	});
}


function AddRiskObservable(id)
{
	id = id.replace(prefixObs, "");
	var item = { name: "", measurement: "" };
	listRiskObsAll[id] = item;
}

function SetRiskObservableName(id, name)
{
	id = id.replace(prefixObs, "");
	if (undefined == listRiskObsAll[id])
		AddRiskObservable(id);

	listRiskObsAll[id].name = name;
}

var prefixMeasurement = "http://carre.kmi.open.ac.uk/ontology/sensors.owl#";

function SetRiskObservableMeasurement(id, nameMeasure)
{
	id = id.replace(prefixObs, "");
	if (undefined == listRiskObsAll[id])
		AddRiskObs(id);

	nameMeasure = nameMeasure.replace(prefixMeasurement, "");

	listRiskObsAll[id].measurement = nameMeasure;
}

// 4
function getRiskObservableList()
{
	console.log("GetObservableList");

	if (top.carre == undefined)
		top.carre = {};
	if (top.carre.listRiskObsAll != undefined)
		return top.carre.listRiskObsAll;


	var url = "https://carre.kmi.open.ac.uk/ws/instances?type=observable&language=" + top.lang;; 

	$.ajax({
		dataType: 'json',
		url: url,
		async: false,
		success: function(data) {
			//console.log('GetRiskElement Success: ' + data);
			console.log('GetRiskObservable Success');
			//printTripleList(data);

			for (var i = 0; i < data.length; i++)
			{
				var item = data[i];
				if (item.predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")
				{
					if (item.object == "http://carre.kmi.open.ac.uk/ontology/risk.owl#observable")
						AddRiskObservable(item.subject);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_observable_name")
				{
					SetRiskObservableName(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_observable_measurement" )
				{
					SetRiskObservableMeasurement(item.subject, item.object);
				}

			}

			top.carre.listRiskObsAll = listRiskObsAll;
			console.log("Number of risk observables: " + Object.keys(listRiskObsAll).length)
			console.log( Object.keys(listRiskObsAll) );
		}
	});

	return top.carre.listRiskObsAll;
}

function GetRiskFactorList()
{

    if (top.carre == undefined)
        top.carre = {}; 
    if (top.carre.listRiskFactor != undefined)
        return top.carre.listRiskFactor;

    // observable, clinical_observable, personal_observable, risk_element, biomedical_risk_element, behavioural_risk_element, genetic_risk_element, demographic_risk_element, risk_factor, risk_evidence, citation
    console.log("GetRiskFactorList");

    //var userToken = "9ec3cc7a5546fa47f14d4867282971c1dc756f7a";       
    var url = "https://carre.kmi.open.ac.uk/ws/instances?type=risk_factor"; 

    $.ajax({
        dataType: 'json',
        url: url,
        async: false,
        success: function(data) {
            //console.log('Get RiskFactorList Success: ' + data);
            //printTripleList(data);

            for (var i = 0; i < data.length; i++)
            {

                var item = data[i];
                if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_factor_source")
                {
                    AddRiskFactorSource(item.subject, item.object);
                }
                else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_factor_target")
                {
                    AddRiskFactorTarget(item.subject, item.object);
                } else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence")
               {
                    AddRiskFactorEvidence(item.subject, item.object);
                } else if (item.predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")
                {
                    if (item.object == "http://carre.kmi.open.ac.uk/ontology/risk.owl#risk_factor")
                        AddRiskFactor(item.subject);

                }
            }

            top.carre.listRiskFactor = listRf;
            //console.log(listRf);
        }
    });

    return top.carre.listRiskFactor;
}

function genRiskGraphGlobal(listRiskElem, listRf)
{
	if (top.carre == undefined)
		top.carre = {};
	if ((top.carre.riskGraphGlobal != undefined) && (listRiskElem == undefined))
		return top.carre.riskGraphGlobal;

	if (undefined == listRiskElem)
		listRiskElem = GetRiskElementList();
	if (undefined == listRf)
		listRf = GetRiskFactorList();

	var graph = {
		nodes: [],
		links: []
	};

	var arrElem = [];

	for (var key in listRiskElem)
	{
		var node = { name: "", observable: [], group: 0};
		node.name = listRiskElem[key].name;
		node.eid = key;
		node.observable = listRiskElem[key].observable.slice(0);
		graph.nodes.push(node);
		arrElem.push(key);
	}

	for (var i = 0; i < listRf.length; i++)
	{
		var rf = listRf[i];
		var link =  {source : 0,target:0, evidence: [], value : 1, group: 0};
		link.source = arrElem.indexOf(rf.source);
		link.target = arrElem.indexOf(rf.target);
		//link.value = rf.evidence.length;
		link.value = 1;
		link.evidence = rf.evidence.slice(0);

		// todo
		if ( (-1 != link.source ) && ( -1 != link.target) )
			graph.links.push(link);
	}

	top.carre.riskGraphGlobal = graph;
	return graph;
}

function genRiskGraph(listRiskElem, listRf)
{
	if (top.carre == undefined)
		top.carre = {};
	if ((top.carre.riskGraph != undefined) && (listRiskElem == undefined))
		return top.carre.riskGraph;

	/*
	if (undefined == listRiskElem)
		listRiskElem = GetRiskElementList();
	if (undefined == listRf)
		listRf = GetRiskFactorList();
		*/

	var graph = {
		nodes: [],
		links: []
	};

	var arrElem = [];

	for (var key in listRiskElem)
	{
		var node = { name: "", observable: [], group: 0};
		node.name = listRiskElem[key].name;
		node.observable = listRiskElem[key].observable.slice(0);
		graph.nodes.push(node);
		arrElem.push(key);
	}

	for (var i = 0; i < listRf.length; i++)
	{
		var rf = listRf[i];
		var link =  {source : 0,target:0, evidence: [], value : 1, group: 0};
		link.source = arrElem.indexOf(rf.source);
		link.target = arrElem.indexOf(rf.target);
		//link.value = rf.evidence.length;
		link.value = 1;
		link.evidence = rf.evidence.slice(0);

		// todo
		if ( (-1 != link.source ) && ( -1 != link.target) )
			graph.links.push(link);
	}

	top.carre.riskGraph = graph;
	return graph;

}


function getRiskMatrix()
{
	var riskGraph = genRiskGraph();
	var numNodes = riskGraph.nodes.length;

	var matrix = [];

	for (var i = 0; i < numNodes; i++)
	{
		var row = [];
		for (var j = 0; j < numNodes; j++)
		{
			row.push(0);
		}
		matrix.push(row);
	}

	for (var i = 0; i < riskGraph.links.length; i++)
	{
		var s = riskGraph.links[i].source;
		var t = riskGraph.links[i].target;
		//matrix[s][t] = riskGraph.links[i].value;
		matrix[s][t] = 1;
	}

	return matrix;
}

function getGraphMatrix(graph)
{
	var numNodes = graph.nodes.length;

	var matrix = [];

	for (var i = 0; i < numNodes; i++)
	{
		var row = [];
		for (var j = 0; j < numNodes; j++)
		{
			row.push(0);
		}
		matrix.push(row);
	}

	for (var i = 0; i < graph.links.length; i++)
	{
		var s = graph.links[i].source;
		var t = graph.links[i].target;
		//matrix[s][t] = riskGraph.links[i].value;
		matrix[s][t] = 1;
	}

	return matrix;
}


function loadVirtualPatientData()
{
    var url = "../share/data/patient.json";
        $.ajax({
            dataType: 'json',
            url: url,
            async: false,
            success: function(dt) {
                data = dt;
            },
		    error: function(XMLHttpRequest, textStatus, errorThrown) { 
       			console.log("Status: " + textStatus); 
				console.log("Error: " + errorThrown); 
    		} 

        }) ; 

        top.carre.patients = data;
}


function getPatientData(name)
{
    var data = [];
    
    if (undefined == top.carre)
        top.carre = {};
    
    if (undefined == top.carre.patients)
    {   
		loadVirtualPatientData();
    }   

    //if (top.carre.patient != null)
	var patients = top.carre.patients;
	for (var i = 0; i < patients.length; i++)
	{
		if (patients[i].name == name)
			return patients[i];
	}

    return {};
}

function getUserData()
{
	var ret = {};
	if (undefined == top.carre)
			return ret;

	if (undefined == top.carre.username)
			return ret;

	var username = top.carre.username;

	if (username != "Login")	
		ret =  getPatientData(username);

	return ret;

}


// not the right way to show progression graph
/*
function genUserRiskGraph()
{
	var username = top.carre.username;
	var patient;
	if (undefined != username && username != "")	
		patient = getPatientData(username);
	else 
		return genRiskGraph();

	var listElem = GetRiskElementList();
	var listRf = GetRiskFactorList();

	// filter listElem
	var patientElem = {};	
	var patientElemNames = Object.keys(patient.disease);
	for (var key in listElem)
	{
		var nameElem = listElem[key].name;
		if (patientElemNames.indexOf(nameElem) != -1)
		{
			if (patient.disease[nameElem])
				patientElem[key] = listElem[key];
		}
	}

	var arrElem = Object.keys(patientElem);
	for (var i = 0; i < listRf.length; i++)
	{
		var rf = listRf[i];
		var source = arrElem.indexOf(rf.source);
		//link.target = patientElem.indexOf(rf.target);
		if (-1 != source )
		{
			patientElem[rf.target] = listElem[rf.target];
		}
	}

	var graph = genRiskGraph(patientElem, listRf);
	return graph;
}
*/

// Generate user risk graph based on user risk evaluation data
function genUserRiskGraph()
{
	var username = top.carre.username;
	var patient;
	if (undefined != username && username != "")	
	{
		console.log("patient presents");
		//patient = getPatientData(username);
	}
	else 
		return genRiskGraph();

	// not listRiskElem
	var listElem = GetRiskElementList();
	var userRvList = GetUserRiskEvidenceList();
	listRiskEv = userRvList.risk_evidences;

	var patientElem = {};	
	// add user specific risks
	for (var i = 0; i < listRiskEv.length; i++)
	{
		var rv = listRiskEv[i];
		var nameRf = rv.risk_factor.value;
		AddRiskFactor(nameRf);
		//AddRiskElement(rv.has_risk_factor_source.value);
		//AddRiskElement(rv.has_risk_factor_target.value);
		var nameReSource = rv.has_risk_factor_source.value;
		var nameReTarget = rv.has_risk_factor_target.value;
		//AddRiskElement(rv.has_risk_factor_target.value);
		AddRiskFactorSource(nameRf, rv.has_risk_factor_source.value);
		AddRiskFactorTarget(nameRf, rv.has_risk_factor_target.value);
		AddRiskFactorEvidence(nameRf, rv.risk_evidence.value);
		
		var idReSource = nameReSource.replace(prefixElem, "");
		var idReTarget = nameReTarget.replace(prefixElem, "");
		patientElem[idReSource] = listElem[idReSource];
		patientElem[idReTarget] = listElem[idReTarget];
	}
	// filter listElem
	/*
	var patientElemNames = Object.keys(patient.disease);
	for (var key in listElem)
	{
		var nameElem = listElem[key].name;
		if (patientElemNames.indexOf(nameElem) != -1)
		{
			if (patient.disease[nameElem])
				patientElem[key] = listElem[key];
		}
	}

	var arrElem = Object.keys(patientElem);
	for (var i = 0; i < listRf.length; i++)
	{
		var rf = listRf[i];
		var source = arrElem.indexOf(rf.source);
		//link.target = patientElem.indexOf(rf.target);
		if (-1 != source )
		{
			patientElem[rf.target] = listElem[rf.target];
		}
	}
	*/

	var graph = genRiskGraph(patientElem, listRf);
	return graph;
}

function getObsName(id)
{
    var listObs = getRiskObservableList();
    if (undefined != listObs[id])
            return listObs[id].name;
    else 
            return id; 
}

/*
var getMeasureListWithLatestValue = function(token)
{
    console.log("Get Measurement of List ");
    //var url = "https://carre.kmi.open.ac.uk:443/ws/measurementsList?" +  "token=" + token;
    var ret = []; 


    var query = 
		'PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>' +
		'PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>' +
		'PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>' +
		'PREFIX : <http://carre.kmi.open.ac.uk/ontology/sensors.owl#>' +
		'PREFIX risk: <http://carre.kmi.open.ac.uk/ontology/risk.owl#>' +
		'PREFIX carreManufacturer: <http://carre.kmi.open.ac.uk/manufacturers/>' +
		'PREFIX carreUsers: <https://carre.kmi.open.ac.uk/users/>' +
		'' +
		'SELECT ?date ?p ?value FROM <https://carre.kmi.open.ac.uk/users/' + top.carre.username + '> WHERE {' +
		'{' +
		'    ?m1 :has_date / :has_value ?date ;' +
		'            ?p ?o .' +
		'    ?o :has_value ?value . ' +
		'{' +
		'SELECT max(?d) as ?date ?p FROM <https://carre.kmi.open.ac.uk/users/' + top.carre.username + '> WHERE {' +
		'  ?m :has_date / :has_value ?d ; ' +
		'        ?p ?o .' +
		'  ?o :has_value ?v1 .' +
		'{' +
		'   SELECT DISTINCT ?p  FROM <https://carre.kmi.open.ac.uk/users/' + top.carre.username + '> WHERE {' +
		'          ?measurement ?p ?object .' +
		'          FILTER(!(?p = :has_date))' +
		'          ?object :has_value ?v . ' +
		'          ' +
		'  }' +
		'}' +
		'}' +
		'}' +
		'}' +
		'}';

    var url = "https://carre.kmi.open.ac.uk/ws/query?";
    //url += "default-graph-uri=" + encodeURIComponent(defaultURI) + "&query=" + encodeURIComponent(query);
    url += "token=" + user.token + "&sparql=" + encodeURIComponent(query);
    $.ajax({
        dataType: 'json',
        method: "POST",
        url: url,
        async:false,
        success: function(data) {
            ret = data;
        },
        error : function(err) {
                console.log("Error in query measurementList");
                console.log(err);
        }
    });

    var measureList = [];
    for (var i = 0; i < ret.length; i++)
    {
        var entry = ret[i];
        var item = {};
        item.measurement = entry.measurementtype.value;
        var link = item.measurement;
        item.varName = link.replace(prefix, "");
        item.displayName = entry.ob_name.value;

        measureList.push(item);
    }

    return measureList;
}

*/
