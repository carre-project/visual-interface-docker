if (!top.mha) {
  top.mha = {};
}

(function ($, undefined) {
  'use strict';

  var global = this || (1, eval)('this');

  // var headers = {'X-CSRF-TOKEN': top.$("meta[name='_csrf']").attr("content")};
    $.ajaxSetup({
        headers: {'X-CSRF-TOKEN': top.$("meta[name='_csrf']").attr("content")}
    });

    // keep session alive
	/*
    function keepMeAlive() {
        var url = '/mha/alive?t=' + +new Date() + '&r=' + Math.random();
        $.get(url, function(data) {
            console.log();
        });
    }

    setInterval(keepMeAlive, 18 * 60000);
	*/

  // webgl is not supported 1. browser version too old 2. not able to initialize webgl
  // var canvas = document.getElementById('avatar3dCanvas');
  // TODO: make sure canvas does exist, maybe dynamic create
  // if (canvas && (!window.WebGLRenderingContext || !canvas.getContext("webgl"))) {
  //   console.log("webgl is not supported");
  // }

    function showTargetPanel(that) {
        var $this = $(that);

        if (document.location.hash === '#' + $this.attr('id')) {
            // if already showing the target panel, do nothing
            return false;
        }

        // hide all other toggle content
        $('.ccgv-toggle-content').hide();
        $this.parents('ul').find('li').removeClass('active')
        $this.parents('li').addClass('active');

        if ($this.hasClass('lazy-load')) {
            // show the target content / div
            $($this.data('target')).show().find(':hidden.iframe').each(function () {
                // lazy load iframe content
                var $this = $(this), target = $this.data('target'), val = $this.val();
                $(target).attr('src', val);
            });
        } else {
            $($this.data('target')).show();
        }
    }

  // by default, hide every demo div other than the first one
  $('.ccgv-toggle-content:gt(0)').hide();
  if (document.location.hash) {
    $('.ccgv-toggle').each(function() {
      var target = $(this).data('target');
      if (target === document.location.hash) {
//        $('.ccgv-toggle-content:eq(0)').hide();
//        $(target).show();
          showTargetPanel(this);
      }
    });
  }

    var modal, type, len, queries, query
        , modalStr='modal=', typeStr = 'type=';
    // location.search contains ? if not empty
    if (location.search.indexOf(modalStr) > 0) {
        queries = location.search.slice(1).split('&');
        // '--' must behind len to loop through properly
        for (len = queries.length; len--;) {
            query = queries[len];
            if (query.indexOf(modalStr) >= 0) {
                modal = query.substring(modalStr.length);
                $('#' + modal).modal('show');
            }

            if (query.indexOf(typeStr) >= 0) {
                type = query.substring(typeStr.length);
            }
        }
    }

    $('.ccgv-toggle').click(function () {
        // if already on the hash, no need to do anything
//        if (document.location.hash === '#' + this.id) {
//          return false;
//        }
//
//        var $this = $(this);
//        // hide all other toggle content
//        $('.ccgv-toggle-content').hide();
//        $this.parents('ul').find('li').removeClass('active')
//        $this.parents('li').addClass('active');
//
//        $($this.data('target')).show();
        showTargetPanel(this);
    });

    $('.lazy-load').click(function () {
//        var $this = $(this);
//
//        // show the target content / div
//        $($this.data('target')).show().find(':hidden.iframe').each(function() {
//            // lazy load iframe content
//            var $this = $(this), target = $this.data('target'), val=$this.val();
//            $(target).attr('src', val);
//        });
        showTargetPanel(this);
    });

    // FIXME: logic need to be updated
    $('form.ajax-form').submit(function(evnt) {
        evnt.preventDefault();
        var $this = $(this);
        $.ajax({
            url: $this.attr('action'),
            type: $this.attr('method'),
            dataType:'text',
            data: $this.serialize(),
            success: function(disconnected) {
                if (disconnected && disconnected.indexOf('disconnected:') === 0) {
                    disconnected = disconnected.substring('disconnected:'.length);

                    $('#' + disconnected + "Connected").addClass('hidden');
                    $('#' + disconnected + "Connect").removeClass('hidden');
                }

//            success: function(url) {
//                // Load denied by X-Frame-Options (Moves: iframe is not allowed)
//                // $('<iframe />', {'src': url}).appendTo('body');
//                // popup blocks...
//                // window.open(url);
//                // http://stackoverflow.com/questions/5660263/how-to-display-an-iframe-inside-a-modal-dialog-using-jquery-ui-dialog
//
//                // looks like Fitbit is the only one support iframe at the moment
//                $this.parents('.modal.in:eq(0)').modal('hide');
//
//                var iframe = $('<iframe frameborder="0" marginwidth="0" marginheight="0" width="640" height="480" src="'
//                    + url + '"></iframe>');
//
//                var dialog = $("<div></div>").append(iframe).appendTo("body").dialog({
//                    autoOpen: true,
//                    modal: true,
//                    resizable: false,
//                    width: "auto",
//                    height: "auto",
//                    close: function () {
//                        iframe.attr("src", "");
//
//                        // TODO: need to confirm with server that it is actually connected, not just window closed!!!
//                        // update the fitbit thing
//                        $this.parents('.form-group:eq(0)').addClass('hidden');
//                        $($this.data('toggleTarget')).removeClass('hidden');
//                        // show the original modal window again
//                        $this.parents('.modal:eq(0)').modal('show');
//                    }
//                });
            }
        });
    });

    $('.ajax-disconnect-link').click(function(evnt) {
        evnt.preventDefault();
        var $this = $(this), href = $this.attr('formaction');
        $this.button('loading');

        $.post(href, function(disconnected) {
            if (disconnected && disconnected.indexOf('disconnected:') === 0) {
                disconnected = disconnected.substring('disconnected:'.length);

                $('#' + disconnected + "Connected").addClass('hidden');
                $('#' + disconnected + "Connect").removeClass('hidden');
            }

            $this.button('reset');
        });
    });

    $('.ajax-synchronisation-link').click(function(evnt) {
        evnt.preventDefault();
        var $this = $(this), href = $this.attr('formaction');
        $this.button('loading');
        $.post(href, function (data) {
            console.log(data);
            $this.button('reset');
        });
    });
    // get yesterday's date format as "yyyyMMdd"
    var yesterday = new Date();
    yesterday = yesterday.getFullYear() +
        ("0" + (yesterday.getMonth() + 1)).slice(-2) +
        ("0" + (yesterday.getDate() - 1)).slice(-2);

    // for activities to display the content
    function showActivities($this, type, data) {
        var $modalBody = $this.parents('.modal-body');
        var $orig = $modalBody.find('>div').hide();

        if (! $modalBody.find('>.activities').length) {
            $modalBody.append('<div class="activities"><div class="summary"></div><a class="back btn btn-default" href="#">Back</a></div>');
            $modalBody.find('a').click(function() {
                $(this).parents('.activities').hide();
                $orig.show();
            });
        }

        var $activities = $modalBody.find('>.activities').show();
        // var type = /\/?\w+\/(\w+)\//.exec(href).pop();

        // by default, yesterday's JSON is retrieved
        if (top.mha && top.mha[type]) {
            top.mha[type][yesterday] = data;
        }

        $activities.find('>.summary').html( convertJsonToHtml(data, type) );
    }

    $('.ajax-activities-link').click(function(evnt) {
        evnt.preventDefault();
        var $this = $(this), href = $this.attr('formaction'), type=$this.data('type');
        // try get the activities from cached result in the first place
        if (top.mha && top.mha[type]) {
            var date, data = top.mha[type], i = data.length;

            while (i--) {
                date = data[i].date || "";

                if (yesterday === date ||
                    yesterday === date.replace(/-/g, "")) {
                    showActivities($this, type, data[i]);
                    return false;
                }
            }
        }

        $this.button('loading');

        $.get(href, function(data) {
            // console.dir(data);
            showActivities($this, type, data);
            $this.button('reset');
        }, 'json');
    });

    window.popupCallback = function(connected) {
        if (connected) {
            // console.log(connected);
            $('#' + connected + "Connect").addClass('hidden');
            $('#' + connected + "Connected").removeClass('hidden');
        }
    }

    // http://stackoverflow.com/questions/4068373/center-a-popup-window-on-screen
    function popupCenter(url, title, w, h) {
        // Fixes dual-screen position                         Most browsers      Firefox
        var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left,
            dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top,
            width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width,
            height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height,
            w = w || width * 3 / 4, h = h || height * 4 / 5,
            left = ((width / 2) - (w / 2)) + dualScreenLeft,
            top = ((height / 2) - (h / 2)) + dualScreenTop;

        // 'scrollbars=yes, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left
        var newWindow = window.open(url, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, '
            + 'scrollbars=yes, resizable=no, copyhistory=no, width='
            + w + ', height=' + h + ', top=' + top + ', left=' + left);

        // Puts focus on the newWindow
        if (window.focus) {
            newWindow.focus();
        }
    }

    $('.btn-window').click(function(evnt) {
        evnt.preventDefault();
        evnt.stopPropagation();

        var $this = $(this), $form = $this.parent('form');
        $.ajax({
            async: false,   // to preserve trust event context, use synchronized request
            url: $form.attr('action'),
            type: $form.attr('method'),
            dataType:'text',
            data: $form.serialize(),
            success: function(url) {
                popupCenter(url, "popup");
            }
        });
    });

    function convertJsonToHtml(data, type) {
        // TODO: make the json => HTML rendering happen in template
        var $dl = $('<dl />');

        if (type === 'moves') {
            if (data.length) {  // Moves data is an array, use the first one
                data = data[0];
            }

            $dl.append('<dt>Date</dt><dd>' + data.date + '</dd>')
            for (var i = data.summary.length; i--;) {
                var summary = data.summary[i];
                $dl.append('<dt>Activity</dt><dd>' + summary.activity + '</dd>')
                    .append('<dt>Distance</dt><dd>' + summary.distance + '</dd>')
                    .append('<dt>Steps</dt><dd>' + (summary.steps ? summary.steps : 'N/A') + '</dd>')
                    .append('<dt>Duration</dt><dd>' + summary.duration + '</dd>');
            }
        } else if (type === 'fitbit') {// fitbit
            if (data.date) {
                $dl.append('<dt>Date</dt><dd>' + data.date + '</dd>');
            }

            $dl.append('<dt>Calories BMR</dt><dd>' + data.summary.caloriesBMR + '</dd>')
                .append('<dt>Calories Out</dt><dd>' + data.summary.caloriesOut + '</dd>')
                .append('<dt>Sedentary Minutes</dt><dd>' + data.summary.sedentaryMinutes + '</dd>')
                .append('<dt>Steps</dt><dd>' + data.summary.steps + '</dd>');
        } else if (type === 'withings') {
            $dl.append('<dt>Date</dt><dd>' + data.body.date + '</dd>')
                .append('<dt>Steps</dt><dd>' + data.body.steps + '</dd>')
                .append('<dt>Distance</dt><dd>' + data.body.distance + '</dd>')
                .append('<dt>Calories</dt><dd>' + data.body.calories + '</dd>')
                .append('<dt>Elevation</dt><dd>' + data.body.elevation + '</dd>')
                .append('<dt>Soft</dt><dd>' + data.body.soft + '</dd>')
                .append('<dt>Moderate</dt><dd>' + data.body.moderate + '</dd>')
                .append('<dt>Intense</dt><dd>' + data.body.intense + '</dd>');
        }

        return $dl;
    }

    // FIXME: 007 decide the best way to handle this (one page application)
    $('#viewActivities').click(function () {
        document.location = "/mha/fitbit/activities/" + $('#activitiesDate').val();
        return false;
    });

    // FIXME: 007 duplicate request to display the content
    var $pageModal = $('#loadPageModal');
    // if the request contains parameter ?path=xxx, show the xxx content in a popup
    window.location.search.replace(/[?&]path=([^&]*)/i, function(match, path, index, str) {
        if (path.indexOf('activities') >= 0) {
            // deal with activities JSON response
            var types = /(\/?(\w+)\/activities)\/?(\d{4}-\d{2}-\d{2})?/i.exec(path);
            if (types.length >= 3) {
                if (types.length === 4) {
                    // ["fitbit/activities/2014-04-01", "fitbit/activities", "fitbit", "2014-04-01"]
                    path = types[1] + '?date=' + types[3];
                }
                var type = types[2];

                $.get(path, function(data) {
                    // console.log(html);no such method 'loading' for button widget instance
                    // console.log($(html).find('#general').html());
                    $pageModal.find('.modal-body').html(convertJsonToHtml(data, type));
                    $pageModal.modal({show: true, backdrop: 'static'});
                }, 'json');
            }
        } else {
            // deal with normal html response
            $.get(path, function(html) {
                $pageModal.find('.modal-body').html($(html).find('#general').html());
                $pageModal.modal({show: true, backdrop: 'static'});
            }, 'html');
        }
    });

	/*
  var doughnutData = [
    {
      value: 30,
      color:"#F7464A"
    },
    {
      value : 50,
      color : "#46BFBD"
    },
    {
      value : 200,
      color : "#FDB45C"
    },
    {
      value : 40,
      color : "#949FB1"
    },
    {
      value : 120,
      color : "#4D5360"
    }
  
  ];
   if (document.getElementById("canvas")) {
      var myDoughnut = new Chart(document.getElementById("canvas").getContext("2d")).Doughnut(doughnutData);

            var barChartData = {chartjs/Chart.js
          labels : ["January","February","March","April","May","June","July"],
          datasets : [
            {
              fillColor : "rgba(220,220,220,0.5)",
              strokeColor : "rgba(220,220,220,1)",
              data : [65,59,90,81,56,55,40]
            },
            {
              fillColor : "rgba(151,187,205,0.5)",
              strokeColor : "rgba(151,187,205,1)",
              data : [28,48,40,19,96,27,100]
            }
          ]

        };

      var myCarChart = new Chart(document.getElementById("canvas2").getContext("2d")).Bar(barChartData);

            var lineChartData = {
          labels : ["January","February","March","April","May","June","July"],
          datasets : [
            {
              fillColor : "rgba(220,220,220,0.5)",
              strokeColor : "rgba(220,220,220,1)",chartjs/Chart.js
              pointColor : "rgba(220,220,220,1)",moves
              pointStrokeColor : "#fff",
              data : [65,59,90,81,56,55,40]
            },
            {
              fillColor : "rgba(151,187,205,0.5)",
              strokeColor : "rgba(151,187,205,1)",
              pointColor : "rgba(151,187,205,1)",
              pointStrokeColor : "#fff",
              data : [28,48,40,19,96,27,100]
            }
          ]

        };

      var myLine = new Chart(document.getElementById("canvas3").getContext("2d")).Line(lineChartData);
   }
	  */

    // allow download data as JSON
    $('.download-data').click(function () {
      var type = $(this).data('downloadType');
      var fileName = type + '.' + +new Date + '.json';top.mha[type]
      var data = JSON.stringify(top.mha[type]);

      var blob = new Blob([data], {type: "text/plain;charset=utf-8"});
      saveAs(blob, fileName);
      return false;
    });
})(jQuery);


/* FileSaver.js
 * A saveAs() FileSaver implementation.
 * 2014-07-25
 *
 * By Eli Grey, http://eligrey.com
 * License: X11/MIT
 *   See https://github.com/eligrey/FileSaver.js/blob/master/LICENSE.md
 */

/*global self */
/*jslint bitwise: true, indent: 4, laxbreak: true, laxcomma: true, smarttabs: true, plusplus: true */

/*! @source http://purl.eligrey.com/github/FileSaver.js/blob/master/FileSaver.js */

var saveAs = saveAs
  // IE 10+ (native saveAs)
  || (typeof navigator !== "undefined" &&
      navigator.msSaveOrOpenBlob && navigator.msSaveOrOpenBlob.bind(navigator))
  // Everyone else
  || (function(view) {
  "use strict";
  // IE <10 is explicitly unsupported
  if (typeof navigator !== "undefined" &&
      /MSIE [1-9]\./.test(navigator.userAgent)) {
    return;
  }
  var
      doc = view.document
      // only get URL when necessary in case Blob.js hasn't overridden it yet
    , get_URL = function() {
      return view.URL || view.webkitURL || view;
    }
    , save_link = doc.createElementNS("http://www.w3.org/1999/xhtml", "a")
    , can_use_save_link = !view.externalHost && "download" in save_link
    , click = function(node) {
      var event = doc.createEvent("MouseEvents");
      event.initMouseEvent(
        "click", true, false, view, 0, 0, 0, 0, 0
        , false, false, false, false, 0, null
      );
      node.dispatchEvent(event);
    }
    , webkit_req_fs = view.webkitRequestFileSystem
    , req_fs = view.requestFileSystem || webkit_req_fs || view.mozRequestFileSystem
    , throw_outside = function(ex) {
      (view.setImmediate || view.setTimeout)(function() {
        throw ex;
      }, 0);
    }
    , force_saveable_type = "application/octet-stream"
    , fs_min_size = 0
    // See https://code.google.com/p/chromium/issues/detail?id=375297#c7 for
    // the reasoning behind the timeout and revocation flow
    , arbitrary_revoke_timeout = 10
    , revoke = function(file) {
      var revoker = function() {
        if (typeof file === "string") { // file is an object URL
          get_URL().revokeObjectURL(file);
        } else { // file is a File
          file.remove();
        }
      };
      if (view.chrome) {
        revoker();
      } else {
        setTimeout(revoker, arbitrary_revoke_timeout);
      }
    }
    , dispatch = function(filesaver, event_types, event) {
      event_types = [].concat(event_types);
      var i = event_types.length;
      while (i--) {
        var listener = filesaver["on" + event_types[i]];
        if (typeof listener === "function") {
          try {
            listener.call(filesaver, event || filesaver);
          } catch (ex) {
            throw_outside(ex);
          }
        }
      }
    }
    , FileSaver = function(blob, name) {
      // First try a.download, then web filesystem, then object URLs
      var
          filesaver = this
        , type = blob.type
        , blob_changed = false
        , object_url
        , target_view
        , dispatch_all = function() {
          dispatch(filesaver, "writestart progress write writeend".split(" "));
        }
        // on any filesys errors revert to saving with object URLs
        , fs_error = function() {
          // don't create more object URLs than needed
          if (blob_changed || !object_url) {
            object_url = get_URL().createObjectURL(blob);
          }
          if (target_view) {
            target_view.location.href = object_url;
          } else {
            var new_tab = view.open(object_url, "_blank");
            if (new_tab == undefined && typeof safari !== "undefined") {
              //Apple do not allow window.open, see http://bit.ly/1kZffRI
              view.location.href = object_url
            }
          }
          filesaver.readyState = filesaver.DONE;
          dispatch_all();
          revoke(object_url);
        }
        , abortable = function(func) {
          return function() {
            if (filesaver.readyState !== filesaver.DONE) {
              return func.apply(this, arguments);
            }
          };
        }
        , create_if_not_found = {create: true, exclusive: false}
        , slice
      ;
      filesaver.readyState = filesaver.INIT;
      if (!name) {
        name = "download";
      }
      if (can_use_save_link) {
        object_url = get_URL().createObjectURL(blob);
        save_link.href = object_url;
        save_link.download = name;
        click(save_link);
        filesaver.readyState = filesaver.DONE;
        dispatch_all();
        revoke(object_url);
        return;
      }
      // Object and web filesystem URLs have a problem saving in Google Chrome when
      // viewed in a tab, so I force save with application/octet-stream
      // http://code.google.com/p/chromium/issues/detail?id=91158
      // Update: Google errantly closed 91158, I submitted it again:
      // https://code.google.com/p/chromium/issues/detail?id=389642
      if (view.chrome && type && type !== force_saveable_type) {
        slice = blob.slice || blob.webkitSlice;
        blob = slice.call(blob, 0, blob.size, force_saveable_type);
        blob_changed = true;
      }
      // Since I can't be sure that the guessed media type will trigger a download
      // in WebKit, I append .download to the filename.
      // https://bugs.webkit.org/show_bug.cgi?id=65440
      if (webkit_req_fs && name !== "download") {
        name += ".download";
      }
      if (type === force_saveable_type || webkit_req_fs) {
        target_view = view;
      }
      if (!req_fs) {
        fs_error();
        return;
      }
      fs_min_size += blob.size;
      req_fs(view.TEMPORARY, fs_min_size, abortable(function(fs) {
        fs.root.getDirectory("saved", create_if_not_found, abortable(function(dir) {
          var save = function() {
            dir.getFile(name, create_if_not_found, abortable(function(file) {
              file.createWriter(abortable(function(writer) {
                writer.onwriteend = function(event) {
                  target_view.location.href = file.toURL();
                  filesaver.readyState = filesaver.DONE;
                  dispatch(filesaver, "writeend", event);
                  revoke(file);
                };
                writer.onerror = function() {
                  var error = writer.error;
                  if (error.code !== error.ABORT_ERR) {
                    fs_error();
                  }
                };
                "writestart progress write abort".split(" ").forEach(function(event) {
                  writer["on" + event] = filesaver["on" + event];
                });
                writer.write(blob);
                filesaver.abort = function() {
                  writer.abort();
                  filesaver.readyState = filesaver.DONE;
                };
                filesaver.readyState = filesaver.WRITING;
              }), fs_error);
            }), fs_error);
          };
          dir.getFile(name, {create: false}, abortable(function(file) {
            // delete file if it already exists
            file.remove();
            save();
          }), abortable(function(ex) {
            if (ex.code === ex.NOT_FOUND_ERR) {
              save();
            } else {
              fs_error();
            }
          }));
        }), fs_error);
      }), fs_error);
    }
    , FS_proto = FileSaver.prototype
    , saveAs = function(blob, name) {
      return new FileSaver(blob, name);
    }
  ;
  FS_proto.abort = function() {
    var filesaver = this;
    filesaver.readyState = filesaver.DONE;
    dispatch(filesaver, "abort");
  };
  FS_proto.readyState = FS_proto.INIT = 0;
  FS_proto.WRITING = 1;
  FS_proto.DONE = 2;

  FS_proto.error =
  FS_proto.onwritestart =
  FS_proto.onprogress =
  FS_proto.onwrite =
  FS_proto.onabort =
  FS_proto.onerror =
  FS_proto.onwriteend =
    null;

  return saveAs;
}(
     typeof self !== "undefined" && self
  || typeof window !== "undefined" && window
  || this.content
));
// `self` is undefined in Firefox for Android content script context
// while `this` is nsIContentFrameMessageManager
// with an attribute `content` that corresponds to the window

if (typeof module !== "undefined" && module !== null) {
  module.exports = saveAs;
} else if ((typeof define !== "undefined" && define !== null) && (define.amd != null)) {
  define([], function() {
    return saveAs;
  });
}
