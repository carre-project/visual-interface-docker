var listRf = []; // risk factor
var listRiskElem = {}; // risk element
var listRiskEv = {}; // risk element
var listRiskObs = {};
var prefixMeasurement = "http://carre.kmi.open.ac.uk/ontology/sensors.owl#";
var prefixElem = "http://carre.kmi.open.ac.uk/risk_elements/";
//var prefixRf = "http://carre.kmi.open.ac.uk/CARRE_";
var prefixRf = "http://carre.kmi.open.ac.uk/risk_factors/";
var prefixObs = "http://carre.kmi.open.ac.uk/observables/";
var prefixEv = "http://carre.kmi.open.ac.uk/risk_evidences/";


function IndexOfRiskFactor(nameRf)
{
	var rfId;
	if (nameRf.indexOf(prefixRf) == 0)
		rfId = nameRf.substring(prefixRf.length);
	else
		rfId = nameRf;

	for (var i = 0; i < listRf.length; i++)
	{
		if (listRf[i].id == rfId)
			return i;
	}

	return -1;
}

function AddRiskFactor(nameRf)
{
	if ( -1 != IndexOfRiskFactor(nameRf))
		return;

	var rf = { id: nameRf.replace(prefixRf, ""), source: "", target: "", evidence: [ ] };
	listRf.push(rf);

	return listRf.length - 1;
}

function AddRiskFactorSource(nameRf, nameObj)
{
	var rfId = IndexOfRiskFactor(nameRf);
	if ( -1 == rfId)
		rfId = AddRiskFactor(nameRf);

	listRf[rfId].source = nameObj.replace(prefixElem, "");
}

function AddRiskFactorTarget(nameRf, nameObj)
{
	var rfId = IndexOfRiskFactor(nameRf);
	if ( -1 == rfId)
		rfId = AddRiskFactor(nameRf);

	listRf[rfId].target = nameObj.replace(prefixElem, "");
}

function AddRiskFactorEvidence(nameRf, nameObj)
{
	var rfId = IndexOfRiskFactor(nameRf);
	if ( -1 == rfId)
		rfId = AddRiskFactor(nameRf);

	listRf[rfId].evidence.push(nameObj.replace(prefixRf, "") );
}

function GetRiskFactorList()
{

	if (top.carre == undefined)
		top.carre = {};
	if (top.carre.listRiskFactor != undefined)
		return top.carre.listRiskFactor;

	// observable, clinical_observable, personal_observable, risk_element, biomedical_risk_element, behavioural_risk_element, genetic_risk_element, demographic_risk_element, risk_factor, risk_evidence, citation
	console.log("GetRiskFactorList");

	//var userToken = "9ec3cc7a5546fa47f14d4867282971c1dc756f7a";		
	var url = "https://carre.kmi.open.ac.uk/ws/instances?type=risk_factor"; 

	$.ajax({
		dataType: 'json',
		url: url,
		async: false,
		success: function(data) {
			//console.log('Get RiskFactorList Success: ' + data);
			//printTripleList(data);

			for (var i = 0; i < data.length; i++)
			{

				var item = data[i];
				if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_factor_source")
				{
					AddRiskFactorSource(item.subject, item.object);
				}
				else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_factor_target")
				{
					AddRiskFactorTarget(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence")
				{
					AddRiskFactorEvidence(item.subject, item.object);
				} else if (item.predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")
				{
					if (item.object == "http://carre.kmi.open.ac.uk/ontology/risk.owl#risk_factor")
						AddRiskFactor(item.subject);

				}
			}

			top.carre.listRiskFactor = listRf;
			//console.log(listRf);
		}
	});

	return top.carre.listRiskFactor;
}


function AddRiskElement(nameElem)
{
	nameElem = nameElem.replace(prefixElem, "");
	var item = { name: "", observable: [ ] };
	listRiskElem[nameElem] = item;
}

function SetRiskElementName(nameElem, nameText)
{
	nameElem = nameElem.replace(prefixElem, "");
	if (undefined == listRiskElem[nameElem])
		AddRiskElement(nameElem);

	listRiskElem[nameElem].name = nameText;

}

function AddRiskElementObservable(nameElem, nameObs)
{
	nameElem = nameElem.replace(prefixElem, "");
	if (undefined == listRiskElem[nameElem])
		AddRiskElement(nameElem);

	nameObs = nameObs.replace(prefixObs, "");

	listRiskElem[nameElem].observable.push(nameObs);
}


function printTripleList(data)
{
	for (var i = 0; i < data.length; i++)
	{
		console.log('Subject: ' + data[i].subject);
		console.log('Predicate: ' + data[i].predicate);
		console.log('Object: ' + data[i].object);
	}
}

function GetRiskElementList()
{
	console.log("GetRiskElementList");

	if (top.carre == undefined)
		top.carre = {};
	if (top.carre.listRiskElem != undefined)
		return top.carre.listRiskElem;


	var url = "https://carre.kmi.open.ac.uk/ws/instances?type=risk_element"; 

	$.ajax({
		dataType: 'json',
		url: url,
		async: false,
		success: function(data) {
			console.log('GetRiskElement Success');
			for (var i = 0; i < data.length; i++)
			{
				var item = data[i];
				if (item.predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")
				{
					if (item.object == "http://carre.kmi.open.ac.uk/ontology/risk.owl#risk_element")
						AddRiskElement(item.subject);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_element_name")
				{
					SetRiskElementName(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_element_observable" )
				{
					AddRiskElementObservable(item.subject, item.object);
				}

			}

			top.carre.listRiskElem = listRiskElem;
			console.log("Number of risk elements: " + Object.keys(listRiskElem).length)
			console.log( Object.keys(listRiskElem) );
		}
	});

	return top.carre.listRiskElem;
}


function AddRiskEvidence(id)
{
	id = id.replace(prefixEv, "");
	var item = {
		number: "",
		//name: "", 
		obs: "",
		obsExp: "",
		adjusted: [],
		ratioVal: "",
		confiInterval: ""

	};

	listRiskEv[id] = item;
}

function GetRiskEvidenceId(id)
{
	id = id.replace(prefixEv, "");
	if (undefined == listRiskEv[id])
		AddRiskEvidence(id);

	return id;
}

function SetRiskEvidenceObsExp(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].obsExp = str;
}

function SetRiskEvidenceNumber(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].number = str;
}

function SetRiskEvidenceObs(id, str)
{
	id = GetRiskEvidenceId(id);
	if (listRiskEv[id] == undefined)
			console.log("listRiskEv[" + id + "] is undefined");

	listRiskEv[id].obs = str.replace(prefixObs, "");
}

function SetRiskEvidenceRatioVal(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].ratioVal = str;
}


function SetRiskEvidenceConfiInterval(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].confiInterval = str.replace(prefixRf, "");
}

var prefixTax = "http://carre.kmi.open.ac.uk/taxonomy_term/";

function AddRiskEvidenceAdjusted(id, str)
{
	id = GetRiskEvidenceId(id);
	listRiskEv[id].adjusted.push(str.replace(prefixTax, "") );
}

function GetRiskEvidenceList()
{
	// use caching
	if (undefined != top.carre.listRiskEv) 
		return;

	console.log("GetEvidenceList");
	var url = "https://carre.kmi.open.ac.uk/ws/instances?type=risk_evidence"; 

	$.ajax({
		dataType: 'json',
		url: url,
		async: false,
		success: function(data) {
			//console.log('GetRiskElement Success: ' + data);
			console.log('GetRiskEvidence Success');
			//printTripleList(data);

			for (var i = 0; i < data.length; i++)
			{
				var item = data[i];
				if (item.predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")
				{
					if (item.object == "http://carre.kmi.open.ac.uk/ontology/risk.owl#risk_evidence")
						AddRiskEvidence(item.subject);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_id")
				{
					// not useful
					SetRiskEvidenceNumber(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_observable_expression" )
				{
					SetRiskEvidenceObsExp(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_observable")
				{
					SetRiskEvidenceObs(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_ratio_value")
				{
					SetRiskEvidenceRatioVal(item.subject, item.object);	
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_confidence_interval")
				{
					SetRiskEvidenceConfiInterval(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#is_adjusted_for" ) 
				{
					AddRiskEvidenceAdjusted(item.subject, item.object);
				}

				//
				//"http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_ratio_type"
				//"http://carre.kmi.open.ac.uk/ontology/risk.owl#has_risk_evidence_source_type"

			}

			console.log("Number of risk evidence: " + Object.keys(listRiskEv).length)
			console.log( Object.keys(listRiskEv) );
			top.carre.listRiskEv = listRiskEv;
		}
	});
}


function AddRiskObservable(id)
{
	id = id.replace(prefixObs, "");
	var item = { name: "", measurement: "" };
	listRiskObs[id] = item;
}

function SetRiskObservableName(id, name)
{
	id = id.replace(prefixObs, "");
	if (undefined == listRiskObs[id])
		AddRiskObservable(id);

	listRiskObs[id].name = name;
}

var prefixMeasurement = "http://carre.kmi.open.ac.uk/ontology/sensors.owl#";

function SetRiskObservableMeasurement(id, nameMeasure)
{
	id = id.replace(prefixObs, "");
	if (undefined == listRiskObs[id])
		AddRiskObs(id);

	nameMeasure = nameMeasure.replace(prefixMeasurement, "");

	listRiskObs[id].measurement = nameMeasure;
}

function getRiskObservableList()
{
	console.log("GetObservableList");

	if (top.carre == undefined)
		top.carre = {};
	if (top.carre.listRiskObs != undefined)
		return top.carre.listRiskObs;


	var url = "https://carre.kmi.open.ac.uk/ws/instances?type=observable"; 

	$.ajax({
		dataType: 'json',
		url: url,
		async: false,
		success: function(data) {
			//console.log('GetRiskElement Success: ' + data);
			console.log('GetRiskObservable Success');
			//printTripleList(data);

			for (var i = 0; i < data.length; i++)
			{
				var item = data[i];
				if (item.predicate == "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")
				{
					if (item.object == "http://carre.kmi.open.ac.uk/ontology/risk.owl#observable")
						AddRiskObservable(item.subject);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_observable_name")
				{
					SetRiskObservableName(item.subject, item.object);
				} else if (item.predicate == "http://carre.kmi.open.ac.uk/ontology/risk.owl#has_observable_measurement" )
				{
					SetRiskObservableMeasurement(item.subject, item.object);
				}

			}

			top.carre.listRiskObs = listRiskObs;
			console.log("Number of risk observables: " + Object.keys(listRiskObs).length)
			console.log( Object.keys(listRiskObs) );
		}
	});

	return top.carre.listRiskObs;
}


function genRiskGraph(listRiskElem, listRf)
{
	if (top.carre == undefined)
		top.carre = {};
	if ((top.carre.riskGraph != undefined) && (listRiskElem == undefined))
		return top.carre.riskGraph;

	if (undefined == listRiskElem)
		listRiskElem = GetRiskElementList();
	if (undefined == listRf)
		listRf = GetRiskFactorList();

	var graph = {
		nodes: [],
		links: []
	};

	var arrElem = [];

	for (var key in listRiskElem)
	{
		var node = { name: "", observable: [], group: 0};
		node.name = listRiskElem[key].name;
		node.observable = listRiskElem[key].observable.slice(0);
		graph.nodes.push(node);
		arrElem.push(key);
	}

	for (var i = 0; i < listRf.length; i++)
	{
		var rf = listRf[i];
		var link =  {source : 0,target:0, evidence: [], value : 1, group: 0};
		link.source = arrElem.indexOf(rf.source);
		link.target = arrElem.indexOf(rf.target);
		//link.value = rf.evidence.length;
		link.value = 1;
		link.evidence = rf.evidence.slice(0);

		// todo
		if ( (-1 != link.source ) && ( -1 != link.target) )
			graph.links.push(link);
	}

	top.carre.riskGraph = graph;
	return graph;

}


function getRiskMatrix()
{
	var riskGraph = genRiskGraph();
	var numNodes = riskGraph.nodes.length;

	var matrix = [];

	for (var i = 0; i < numNodes; i++)
	{
		var row = [];
		for (var j = 0; j < numNodes; j++)
		{
			row.push(0);
		}
		matrix.push(row);
	}

	for (var i = 0; i < riskGraph.links.length; i++)
	{
		var s = riskGraph.links[i].source;
		var t = riskGraph.links[i].target;
		//matrix[s][t] = riskGraph.links[i].value;
		matrix[s][t] = 1;
	}

	return matrix;
}

function getGraphMatrix(graph)
{
	var numNodes = graph.nodes.length;

	var matrix = [];

	for (var i = 0; i < numNodes; i++)
	{
		var row = [];
		for (var j = 0; j < numNodes; j++)
		{
			row.push(0);
		}
		matrix.push(row);
	}

	for (var i = 0; i < graph.links.length; i++)
	{
		var s = graph.links[i].source;
		var t = graph.links[i].target;
		//matrix[s][t] = riskGraph.links[i].value;
		matrix[s][t] = 1;
	}

	return matrix;
}


function loadVirtualPatientData()
{
    var url = "../share/data/patient.json";
        $.ajax({
            dataType: 'json',
            url: url,
            async: false,
            success: function(dt) {
                data = dt;
            },
		    error: function(XMLHttpRequest, textStatus, errorThrown) { 
       			console.log("Status: " + textStatus); 
				console.log("Error: " + errorThrown); 
    		} 

        }) ; 

        top.carre.patients = data;
}


function getPatientData(name)
{
    var data = [];
    
    if (undefined == top.carre)
        top.carre = {};
    
    if (undefined == top.carre.patients)
    {   
		loadVirtualPatientData();
    }   

    //if (top.carre.patient != null)
	var patients = top.carre.patients;
	for (var i = 0; i < patients.length; i++)
	{
		if (patients[i].name == name)
			return patients[i];
	}

    return {};
}

function getUserData()
{
	var ret = {};
	if (undefined == top.carre)
			return ret;

	if (undefined == top.carre.username)
			return ret;

	var username = top.carre.username;

	if (username != "Login")	
		ret =  getPatientData(username);

	return ret;

}


// not the right way to show progression graph
function genUserRiskGraph()
{
	var username = top.carre.username;
	var patient;
	if (undefined != username && username != "")	
		patient = getPatientData(username);
	else 
		return genRiskGraph();

	var listElem = GetRiskElementList();
	var listRf = GetRiskFactorList();

	// filter listElem
	var patientElem = {};	
	var patientElemNames = Object.keys(patient.disease);
	for (var key in listElem)
	{
		var nameElem = listElem[key].name;
		if (patientElemNames.indexOf(nameElem) != -1)
		{
			if (patient.disease[nameElem])
				patientElem[key] = listElem[key];
		}
	}

	var arrElem = Object.keys(patientElem);
	for (var i = 0; i < listRf.length; i++)
	{
		var rf = listRf[i];
		var source = arrElem.indexOf(rf.source);
		//link.target = patientElem.indexOf(rf.target);
		if (-1 != source )
		{
			patientElem[rf.target] = listElem[rf.target];
		}
	}

	var graph = genRiskGraph(patientElem, listRf);
	return graph;
}


function getObsName(id)
{
    var listObs = getRiskObservableList();
    if (undefined != listObs[id])
            return listObs[id].name;
    else 
            return id; 
}

