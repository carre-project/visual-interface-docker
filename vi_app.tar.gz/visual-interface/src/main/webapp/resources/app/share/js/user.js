//<![CDATA[
top.carre = top.carre || {}; 
top.carre.username = top.carre.username || ""; 
top.carre.token = top.carre.token || ""; 
top.carre.role = top.carre.role || ""; 

var obsValues = {};
var listRiskObs = [];
var riskObs = {};
// get query value pairs
function getQueryPair() {
  // This function is anonymous, is executed immediately and 
  // the return value is assigned to QueryString!
  var query_string = {};
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  for (var i=0;i<vars.length;i++) {
    var pair = vars[i].split("=");
        // If first entry with this name
    if (typeof query_string[pair[0]] === "undefined") {
      query_string[pair[0]] = decodeURIComponent(pair[1]);
        // If second entry with this name
    } else if (typeof query_string[pair[0]] === "string") {
      var arr = [ query_string[pair[0]],decodeURIComponent(pair[1]) ];
      query_string[pair[0]] = arr;
        // If third or later entry with this name
    } else {
      query_string[pair[0]].push(decodeURIComponent(pair[1]));
    }
  } 
    return query_string;
};


function checkUserFromUrl()
{
		// read cookie
		var userInfo;
		top.carre.token = getCookie("CARRE_USER");
		if ( (top.carre.token != undefined) && (top.carre.token != ""))
		{
			userInfo = getUserInfoFromToken(top.carre.token);
			top.carre.username = userInfo.username;
			top.carre.role = userInfo.role;
    		setUserName(top.carre.username);
		}
		else
    		setUserName("");

		console.log(top.carre);

		//top.carre.token = "9ec3cc7a5546fa47f14d4867282971c1dc756f7a";
		//top.carre.username = "youbing";
		//setUser("youbing", "9ec3cc7a5546fa47f14d4867282971c1dc756f7a");
		getMeasureListWithLatestValue(top.carre.token);
}


function onLogout()
{
    setUserName("");

	// clear virtual patients
	top.carre.patients = undefined;
    top.carre.riskGraph = undefined;

    document.location.href = '//devices.carre-project.eu/devices/accounts/logout?next=http://visual.carre-project.eu/';
}


function onLogin()
{
		/*
    if (document.querySelector('.ccgv-navbar-right button').innerHTML != "Login")
    {
            //console.log("User logged in, no actions on click");
            return;
    }
	*/

    document.body.style.display = 'none';

/*
    var search = document.location.search;
    var username = 'username=';
    if (search.indexOf(username) >= 0) {
        search = search.substring(search.indexOf(username) + username.length);
    
        if (search.indexOf('&') >= 0) {
            search = search.substring(0, search.indexOf('&'));
        }
    
        if (search) {
            localStorage.setItem('username', search);
        }
    }
	*/
    
    //if (!localStorage.getItem('username')) {

	// for debugging
    //document.location.href = 'https://carre.kmi.open.ac.uk/devices/accounts/login?next=http://visual.carre-project.eu:8080/Carre/';
    document.location.href = '//devices.carre-project.eu/devices/accounts/login?next=http://visual.carre-project.eu/';
	/*
    } else {
        if (undefined == top.carre)
            top.carre = {}; 
        var name  = localStorage.getItem('username');
        top.carre.username = name;
        document.getElementById("userButton").value  = name;
        //document.querySelector('.ccgv-navbar-right button').innerHTML = localStorage.getItem('username');
        document.body.style.display = '';
    }
	*/
}

function setUser(name, token, role)
{
	if (role == undefined)
			role = "patient";
	
	if (token == undefined)
			token = "";

	setUserName(name);
	top.carre.token = token;
	top.carre.role = role;

}

function setUserName(name)
{
    top.carre.username = name;

	var buttonName = name;
	if ("" == name)
	{
		buttonName = "Login";
		if ($.i18n != undefined)
		{
			buttonName = $.i18n("MENU_login");
		}
	}


    document.getElementById("userButton").value = buttonName;

    var dashboardd = window.frames['idashboard'];
    if (undefined != dashboardd)
    {
        if (undefined != dashboardd.contentWindow.showUserInfo)
            dashboardd.contentWindow.showUserInfo();
    }
}

var testUserToken = 
{
		"__TestUserY": { name: "youbing", token: "9ec3cc7a5546fa47f14d4867282971c1dc756f7a" },
		"__TestUserA": { name: "athird", token: "4f9dffec707e6f13024b263eeacd289a7dec4bd4" },
		"__TestUserV" : { name: "vaimaro",token: "ac21db1aaeb1406b7cf37f9c4c87c244dc464a4d"},
		"__TestUserJ" : { name : "jdomingue", token: "3e0315e9423ea5c0f5984b0f3ff8d31e91e633ca" },
		"__fakepatient1" : {name: "fakepatient1", token: "3e194f4d53f2d72a7c5289aaaa99f6a33349e4fa"}
}
// user defined in local json files
function setLocalUserName(button)
{
	var name = button.value;

	// only username, no token
    document.getElementById("userButton").value = name;

	if (testUserToken[name] != undefined )
	{
    	top.carre.username = testUserToken[name].name;
    	top.carre.token = testUserToken[name].token;
	}
	else
	{
		top.carre.username = name;
		top.carre.token = "";
	}

    var dashboardd = window.frames['idashboard'];
    if (undefined != dashboardd)
    {
        if (undefined != dashboardd.contentWindow.showUserInfo)
            dashboardd.contentWindow.showUserInfo();
    }

}

function checkUser()
{
    var name  = localStorage.getItem('username');
    if (name != undefined)
    {
        if (undefined == top.carre)
            top.carre = {}; 
        top.carre.username = name;
        top.carre.token = localStorage.getItem('token');
        top.carre.email = localStorage.getItem('email');
        document.getElementById("userButton").value  = name;
        document.body.style.display = '';
    }
    else 
        setUserName("");
}

function onClickUser()
{
    //if (document.getElementById("userButton").value == "Login")
    //if ($("#userButton").val() == "Login")
	if (top.carre.username == "")
        onLogin();
}

var getMeasureListWithLatestValue = function(token)
{
    console.log("Get Measurement of List ");
    //var url = "https://carre.kmi.open.ac.uk:443/ws/measurementsList?" +  "token=" + token;
    var ret = []; 


    var query = 
        'PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>' +
        'PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>' +
        'PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>' +
        'PREFIX : <http://carre.kmi.open.ac.uk/ontology/sensors.owl#>' +
        'PREFIX risk: <http://carre.kmi.open.ac.uk/ontology/risk.owl#>' +
        'PREFIX carreManufacturer: <http://carre.kmi.open.ac.uk/manufacturers/>' +
        'PREFIX carreUsers: <https://carre.kmi.open.ac.uk/users/>' +
        '' +
		"SELECT ?date ?p ?ob ?value ?ob_name FROM <https://carre.kmi.open.ac.uk/users/" + top.carre.username + "> FROM <http://carre.kmi.open.ac.uk/riskdata> WHERE { " +
		"{" +
		"SELECT max(?d) as ?date ?p FROM <https://carre.kmi.open.ac.uk/users/" + top.carre.username + "> WHERE { " +
		"        ?m :has_date / :has_value ?d ; ?p ?o . " +
		"        ?o :has_value ?v1 . " +
		"        " +
		"            FILTER(!(?p = :has_date) && !(?p = :has_start_date)&& !(?p = :has_end_date) && !(?p = :has_sleep_status))" +
		"       " +
		"        } " +
		"}" +
		"?measurement :has_date / :has_value ?date ; ?p ?o . " +
		"?o :has_value ?value . " + 
		"?ob a risk:observable ; risk:has_external_predicate ?p ; risk:has_observable_name ?ob_name . " +
		"FILTER (lang(?ob_name)='" + top.lang + "' )" + 
		"}";
	
    var url = "https://carre.kmi.open.ac.uk/ws/query?";
    //url += "default-graph-uri=" + encodeURIComponent(defaultURI) + "&query=" + encodeURIComponent(query);
    url += "token=" + token + "&sparql=" + encodeURIComponent(query);
    $.ajax({
        dataType: 'json',
        method: "POST",
        url: url,
        async:false,
        success: function(data) {
            ret = data;
			console.log(data);
			processObsValueData(data);
        },
        error : function(err) {
                console.log("Error in query measurementList");
                console.log(err);
        }
    });

	// try allan's query here
	obsStr = "";
	for (var i = 0; i < listRiskObs.length; i++)
		obsStr += ":" + listRiskObs[i] + " ";
	top.carre.obsStr = obsStr;

	query = 
"	PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>" +
"	PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>" +
"	PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>" +
"	PREFIX : <http://carre.kmi.open.ac.uk/ontology/sensors.owl#>" +
"	PREFIX risk: <http://carre.kmi.open.ac.uk/ontology/risk.owl#>" +
"	PREFIX carreManufacturer: <http://carre.kmi.open.ac.uk/manufacturers/>" +
"	PREFIX carreUsers: <https://carre.kmi.open.ac.uk/users/>" +
"" +
"	SELECT DISTINCT ?re ?condition FROM <http://carre.kmi.open.ac.uk/riskdata> WHERE" +
"	{" +
"			 ?re a risk:risk_evidence ;" +
"			   risk:has_risk_evidence_observable ?ob ; " +
"			     risk:has_observable_condition ?condition . " +
"				 {" +
"						  SELECT ?ob FROM <http://carre.kmi.open.ac.uk/riskdata> WHERE {" +
"								   ?ob a risk:observable ; " +
"								           risk:has_external_predicate ?p.   " +
"										   VALUES ?p {" + obsStr + "}" +
"						  }" +
"				 }" +
"	}" ;

    url = "https://carre.kmi.open.ac.uk/ws/query?";
    //url += "default-graph-uri=" + encodeURIComponent(defaultURI) + "&query=" + encodeURIComponent(query);
    url += "token=" + token + "&sparql=" + encodeURIComponent(query);
    $.ajax({
        dataType: 'json',
        method: "POST",
        url: url,
        async:false,
        success: function(data) {
            ret = data;
			console.log(data);
			for (var i = 0; i < data.length; i++)
			{
				var exp = data[i].condition.value;
				var result = RiskEvidenceConditionParser.evaluate(exp, obsValues);
				console.log(result + ": " + exp);							            

			}
				
        },
        error : function(err) {
                console.log("Error in query listRiskObs");
                console.log(err);
        }
    });

}

function processObsValueData(data)
{
	var prefixMeasurement = "http://carre.kmi.open.ac.uk/ontology/sensors.owl#";
	var prefixElem = "http://carre.kmi.open.ac.uk/risk_elements/";
	var prefixRf = "http://carre.kmi.open.ac.uk/CARRE_";
	var prefixObs = "http://carre.kmi.open.ac.uk/observables/";
	
	for (var i = 0; i < data.length; i++)
	{
		var item = data[i];
		var obsId = item.ob.value;
		var obsVal = item.value.value;
		obsId = obsId.replace(prefixObs, "")
		obsValues[obsId] = obsVal;

		var obsId = item.p.value;
		obsId = obsId.replace(prefixMeasurement, "");
		listRiskObs.push(obsId);
		
		riskObs[obsId] = {
			name :  item.ob_name.value,
			value: item.value.value
		};
		
	}

	top.carre.obsValues = obsValues;
	top.carre.listRiskObs = listRiskObs;
	top.carre.riskObs = riskObs;

}
//]]>

