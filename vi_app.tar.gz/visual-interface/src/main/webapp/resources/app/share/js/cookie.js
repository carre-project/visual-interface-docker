var ccgv = ccgv || {};
ccgv.cookie = ccgv.cookie || {};

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}

function clearCookie(cname) {
    var today = new Date();
	// beginning of the epoch
	var start = new Date(0);
	var nDays = Math.round( (today - start) / 86400000 );
	setCookie(cname, "", - nDays);
}


function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

function checkCookie() {
    var username=getCookie("username");
    if (username!="") {
        alert("Welcome again " + username);
    }else{
        username = prompt("Please enter your name:", "");
        if (username != "" && username != null) {
            setCookie("username", username, 365);
        }
    }
}

function getUserInfoFromToken(tk)
{
	var userInfo;
    $.ajax({
        type: "GET",
        url: "//devices.carre-project.eu/ws/userProfile?token=" + tk,
        async: false,
        success : function(data) {
            userInfo = data; 
			console.log(data)
        }
    });
	return userInfo;
}
