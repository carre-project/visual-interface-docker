function GetRangeStep(dateStart, dateEnd, token)
{
    //var token = "9ec3cc7a5546fa47f14d4867282971c1dc756f7a";
	var token = top.carre.token;
    console.log("GetRiskElement");
    var link = "http://carre.kmi.open.ac.uk/elements/" + id;
    var query = "select ?y ?z WHERE { <" + link + "> ?y ?z . }";

    var defaultURI = "https://carre.kmi.open.ac.uk/public";
    
    //var url = "http://carre.kmi.open.ac.uk:8890/sparql?";
    var url = "https://carre.kmi.open.ac.uk/ws/query?";
    //url += "default-graph-uri=" + encodeURIComponent(defaultURI) + "&query=" + encodeURIComponent(query);
    url += "token=" + token + "&sparql=" + encodeURIComponent(query);
    
    $.ajax({
        dataType: 'json',
        method: "POST",
        url: url,
        success: function(data) {
            //console.log('success: ' + data.results.bindings.length + ' results');
            console.log(data);
        }
    });
}

