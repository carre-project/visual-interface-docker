// component progressiveGraph
var progGraph = {};

//based on d3.slider.js
function addSliders(parentDivName)
{

	var userData = getUserData();
	if (undefined == userData.PHR)
			return;

	var phr = userData.PHR;
	var namesPhr = Object.keys(phr);

	$.each(namesPhr, function(i, d) {
		var div = document.createElement('div');
		div.id = "slider" + i;
		div.style.width = "100%";
		div.style.height = "40px";
		div.style.marginTop = "5px";
		div.style.marginBottom = "5px";
		div.style.marginLeft = "5px";
		div.style.marginRight = "5px";
		div.innerHTML = d;
		//div.style.padding = "5px 5px 5px 5px";
		var parentDiv = document.getElementById(parentDivName);
		parentDiv.appendChild(div);
		//document.getElementById(parentDivName).appendChild(div);
		var val = phr[d];
		if (typeof val == "boolean")
		{
			// add raido button
			var label = document.createElement('label');
			label.innerHTML = d;
			div.appendChild(label);
			var checkbox = document.createElement('input');
			checkbox.type = "checkbox";
			checkbox.name = d;
			checkbox.value = phr[d];
			checkbox.checked = phr[d];
			checkbox.id = "checkbox" + i;
			label.appendChild(checkbox);
		}
		else if (typeof val == "Array")
		{
			d3.select('#slider'+i).call(d3.slider().value(val[0]));
		}
		else if ( typeof val == "number" )
		{
			d3.select('#slider'+i).call(d3.slider().value(val));
		}

		/*
		d3.slider("#" + d).on("slide", function(evt, value) {
			  //d3.select('#slider3text').text(value);
		});
		*/

	});
}

function initSlider(varName, val, minval, maxval, stepval, callback)
{
	$("#slider" + varName).slider(
	{
	      value:val,
	      min: minval,
	      max: maxval,
	      step: stepval,
	      slide: function( event, ui ) {
	          $( "#value" + varName ).html( ui.value );
			  if (undefined != callback)
					  callback(ui.value);
	      }
	}
	);
	
	$( "#valueName"+ varName ).html(  varName + ":" );
	$( "#value" + varName ).html(  $('#slider' + varName).slider('value') );
}

function initSliders()
{
	d3.select("#sliderTime").on('input', function(d) {
          //var current = years[parseInt(this.value)],
          var year = Math.floor(this.value / 12 + 2006);
          var month = Math.floor(this.value % 12 + 1);
          d3.select("#month").text(""+month);
          d3.select("#year").text(""+year);
	});

	d3.select("#sliderTime").on('change', function(d) {
		// get the disease list of at the given time and 
        var year = Math.floor(this.value / 12 + 2006);
        var month = Math.floor(this.value % 12 + 1);
		var date = new Date(year, month, 1);
		// updateGraph
		// TODO
	});

	initSlider("Steps", 5000, 0, 50000, 100, function(val)
	{
		var userData = getUserData();
		if (undefined == userData.disease)
			return;

		var nameRiskElem = "obesity";

		if (val > 10000)
		{
			if (undefined == userData.disease[nameRiskElem])
			{
				userData.disease[nameRiskElem] = false;
				return;
			}

			if (userData.disease[nameRiskElem] != false)
			{
				userData.disease[nameRiskElem] = false;
				updateGraph();
			}

		}
		else if (val < 2000)
		{
			if (undefined == userData.disease[nameRiskElem])
			{
				userData.disease[nameRiskElem] = true;
				updateGraph();
				return;
			}

			if (userData.disease[nameRiskElem] == false)
			{
				userData.disease[nameRiskElem] = true;
				updateGraph();
			}

		}
		
	});

	initSlider("BloodPressure", 120, 0, 200, 1, function(val) {
		var userData = getUserData();
		if (undefined == userData.disease)
			return;

		var nameRiskElem = "hypertension";

		if (val < 120)
		{
			if (undefined == userData.disease[nameRiskElem])
			{
				userData.disease[nameRiskElem] = false;
				//updateGraph();
				return;
			}

			if (userData.disease[nameRiskElem] != false)
			{
				userData.disease[nameRiskElem] = false;
				updateGraph();
			}

		}
		else if (val > 130)
		{
			if (undefined == userData.disease[nameRiskElem])
			{
				userData.disease[nameRiskElem] = true;
				updateGraph();
				return;
			}

			if (userData.disease[nameRiskElem] == false)
			{
				userData.disease[nameRiskElem] = true;
				updateGraph();
			}

		}
	});

}
//addSliders("rightpanel");
initSliders();

var width = $("#graphView").width();
var height = $("#graphView").height();
if (width == 0) width = 1000;
if (height == 0) height = 800;

// get the full risk graph data
var riskGraph = genRiskGraph();
var graph = $.extend(true, {}, riskGraph);
var nodes = [];
var links = []; 
 
var nodesObs = [];


var idObsNode = graph.nodes.length;

// for testing purpose
GetRiskEvidenceList();

/*
function getObsName(id)
{
	var listObs = getRiskObservableList();
	if (undefined != listObs[id])
			return listObs[id].name;
	else 
			return id;
}
*/

$.each(graph.nodes, function(i, d)
{
	d.hidden = false;
	d.ref = 0;
	d.in = 0;
	d.id = i;

	// add observables
	if (d.observable != undefined)
	{
		var nodeObs;
		for (var j = 0; j < d.observable.length; j++)
		{
			node = { id: idObsNode, name: getObsName(d.observable[j]), group: 1, ref: 0, in : 0, hidden : true};
			nodesObs.push(node);
			var link =  { source : i, target: idObsNode, evidence: [], value : 1, group: 1, hidden:true };
			graph.links.push(link);
			idObsNode ++;
		}
	}
});

graph.nodes = graph.nodes.concat(nodesObs);

$.each(graph.links, function(i, d)
{
	if (d.group == 0)
	{
		d.hidden = false;
		d.showObs = false;
	}
	else
		d.hidden = true;

	d.source = graph.nodes[d.source];
	d.target = graph.nodes[d.target];
	d.id = i;

});

// Set the range
var  v = d3.scale.linear().range([0, 100]);
// Scale the range of the data
v.domain([0, d3.max(links, function(d) { return d.value; })]);

// asign a type per value to encode opacity
/*
graph.links.forEach(function(link) {
	if (v(link.value) <= 1) {
		link.type = "twofive";
	} else if (v(link.value) <= 2 && v(link.value) > 1) {
		link.type = "fivezero";
	} else if (v(link.value) <= 3 && v(link.value) > 2) {
		link.type = "sevenfive";
	} else if (v(link.value) <= 4 && v(link.value) > 3) {
		link.type = "onezerozero";
	}
});
*/

var force = d3.layout.force()
	    .size([width, height])
	    .charge(-1000)
	    .on("tick", tick)
		.linkDistance(function(d) { 
			if (d.group == 0)
				return 100;
			else 
				return 30;
        })
	    .start();
	
color = d3.scale.category20c();

nodes = force.nodes();
links = force.links();

var svg = d3.select("#graphView").append("svg")
	    .attr("width", width)
	    .attr("height", height);

	 	// build the arrow.
	svg.append("svg:defs").selectAll("marker")
	    .data(["end"])      // Different link/path types can be defined here
	  .enter().append("svg:marker")    // This section adds in the arrows
	    .attr("id", "end")
	    .attr("viewBox", "0 0 10 10")
	    .attr("refX", 20)
	    .attr("refY", 2.5)
	    .attr("markerWidth", 8)
	    .attr("markerHeight", 6)
	    .attr("orient", "auto")
	  .append("svg:path")
	  .attr("d", "M 0 0 L 10 5 L 0 10 z");

 
var pathg = svg.append("svg:g");
var node = svg.selectAll(".node"),
    path = pathg.selectAll("path");

initGraphToHide();
updateGraph();
force.start();
//setTimeout(function() { force.stop(); }, 5000 );

function updateGraph()
{
	reduceGraphByUser();
	drawGraph();
}

function updateGraphDataStructure()
{	
	graph.nodes.forEach(function(d) {
			d.ref = 0;
			d.in = 0;
	});

	links.length = 0;
	graph.links.forEach(function(d) {
		if (d.hidden == false )
		{
			links.push(d);
			d.source.ref += 1;
			d.target.ref += 1;
			d.target.in += 1;
		}
	});

	nodes.length = 0;
	graph.nodes.forEach(function(d) {
		if (d.ref > 0)
			nodes.push(d);
	});

}

function drawGraph()
{
	updateGraphDataStructure();

	// now links changed with direct objects
	path = pathg.selectAll("path.link").data(force.links(), function(d) { return d.source.id + "-" + d.target.id; });
	//path = pathg.selectAll("path").data(links);

	path.exit()
	  .transition()
		.duration(2000)
		.style("opacity", 0)
	    //.call(animateCellRemove)
	  .remove();
	
	/*
	function animateCellRemove(selection) {
	  selection
	    .attr('transform', function(d) {
	      return "scale(" + d.dx/2 + "," + d.dy/2 +")";
	    });
	}
	*/
	
	// add the links and the arrows
	path.enter().append("svg:path")
	    .attr("class", function (d) {
				if (d.group == 0)
						return "link";
				else return "link observable";})
       .attr("id", function (d) {
       		return d.source.id + "-" + d.target.id;
        })
	    //.attr("class", function(d) { return "link " + d.type; })
	    .attr("marker-end", "url(#end)")
	  .transition()
		.duration(2000)
		.style("opacity", function(d) {
				if (d.group == 0) return 1.0; else return 0.5; });

	//.style("stroke-dasharray", "4,4")	

	// Update nodes.
	// define the nodes
	node = svg.selectAll(".node").data(force.nodes(), function(d) { return d.id;});

	node.exit()
	  .transition()
		.duration(2000)
		.style("opacity", 0)
	    //.call(animateCellRemove)
	  .remove();

	var nodeEnter = node.enter().append("g")
	    .attr("class", "node")
        .attr("id", function (d) {
         	return d.id;
         })
	    .on("click", click)
	    .on("mouseover", mouseover)
	    .on("mouseout", mouseout)
	    .on("dblclick", dblclick)
		    .call(force.drag)
	.on("drag.force", function() {
        //force.stop();
        d3.select(this).attr("transform", "translate(" + d3.event.x + "," + d3.event.y + ")");
    });
	 
	// add the nodes
	nodeEnter.append("path")
	    .attr("class", "nodeShape")
		//.attr("transform", function(d) { return "translate(" + d.x + "," + d.y + ")"; })
		.attr("d", d3.svg.symbol()
		    .size(function(d) { 
				var h = 10;
				if (d.isBase) h = 25; 
				else if (d.group == 0) 
					h = 13; 
				return h * h * 2;
			})
			.type(function(d) { 
				if (d.group == 0) 
						return "circle"; 
				else return "square"; 
				})
						  
							  
							  )
	    .style("fill", function(d) { return color(d.name); })
		.transition()
		.duration(2000)
		.style("opacity", 1);

	// add the text 
	nodeEnter.append("text")
	    .attr("x", 12)
	    .attr("dy", ".35em")
	    .text(function(d) { return d.name; })
        .style("font-size", function(d) { if (d.isBase) return 20; else return 14; });

	//setTimeout(function(){ force.start(); }, 4000);;
	force.start();
	 
}

// add the curvy lines
function tick() {
    path.attr("d", function(d) {
        var dx = d.target.x - d.source.x,
            dy = d.target.y - d.source.y;
		var dr = 0;
		if (d.group == 0)
            dr = Math.sqrt(dx * dx + dy * dy);

        return "M" + 
            d.source.x + "," + 
            d.source.y + "A" + 
            dr + "," + dr + " 0 0,1 " + 
            d.target.x + "," + 
            d.target.y;
    });
 
    node.attr("transform", function(d) { 
		    return "translate(" + d.x + "," + d.y + ")"; });
}
 
function mouseout(d)
{
		/*
    d3.select(this).select("text").transition()
        .duration(500)
        .attr("x", 12)
        .style("stroke", "lightsteelblue")
        .style("stroke-width", ".5px")
        .style("font", "10px sans-serif");

    d3.select(this).select("circle").transition()
        .duration(500)
        .attr("r", 8);
		*/
}

function mouseover(d)
{
		/*
    d3.select(this).select("text").transition()
        .duration(500)
        .attr("x", 22)
        .style("stroke", "lightsteelblue")
        .style("stroke-width", ".5px")
        .style("font", "20px sans-serif");

    d3.select(this).select("circle").transition()
        .duration(500)
        .attr("r", 16);
		*/
}


// action to take on mouse click
// show risk element observables
function click(d) {
  if (d3.event.defaultPrevented) return; // ignore drag

	//force.stop();
	d3.select(this).classed("fixed", d.fixed = !d.fixed);

	showObservable(d);
	//if (d.hidden == true)
	//expand(d);
	//	else
	//reduce(d);

	//drawGraph();
	//force.start();
}
 
// action to take on mouse double click
function dblclick() {
    d3.select(this).select("circle").transition()
        .duration(750)
        .attr("r", 6);
    d3.select(this).select("text").transition()
        .duration(750)
        .attr("x", 12)
        .style("stroke", "none")
        .style("fill", "black")
        .style("stroke", "none")
        .style("font", "10px sans-serif");

}
 
 
function color(d) {
  return d._children ? "#3182bd" // collapsed package
      : d.children ? "#c6dbef" // expanded package
      : "#fd8d3c"; // leaf node
}

// Toggle children on click.
/*
function click(d) {
  if (d3.event.defaultPrevented) return; // ignore drag
  if (d.children) {
    d._children = d.children;
    d.children = null;
  } else {
    d.children = d._children;
    d._children = null;
  }
  update();
}
*/

function initGraphToHide()
{
	$.each(graph.nodes, function(i, d)
	{
		if (d.group == 0)
			d.hidden = false;
		else 
			d.hidden = true;
	});

	$.each(graph.links, function(i, d)
	{
		if (d.group == 0)
			d.hidden = false;
		else 
			d.hidden = true;
	});
}


// hide the nodes and links unrelated to the current user
function reduceGraphByNodeList(nodeList)
{
	var showNodeList = nodeList.slice(0);	
	$.each(graph.nodes, function(i, d)
	{
		if (d.group == 1)
			return;

		if ((nodeList.indexOf(d) != -1 ))
		{
			d.hidden = false;
			showNodeList.push(d);
		}
		else 
			d.hidden = true;
	});

	$.each(graph.links, function(i, d)
	{
        var source = nodeList.indexOf(d.source);

		if (d.group == 1)
			return;

		// hide evidence
        if (-1 != source ) 
        {
			d.hidden = false;
			d.target.hidden  = false;
			showNodeList.push(d.target);
        }
		else 
			d.hidden = true;
	});

	$.each(graph.links, function(i, d)
	{
        var source = showNodeList.indexOf(d.source);
		if ( (d.group == 1) && (d.hidden == false) && ( source == -1))
		{
			d.hidden = true;
			d.target.hidden  = true;
		}

	});
}

function reduceGraphByUser()
{
	if (undefined == top.carre)
			return;
	var username = top.carre.username;

	if (undefined == username )
		return;

	if (username == "")
		return;

	var userElem = [];
	if (username != "Login")        
	{
		var patient = getPatientData(username);
		if ((undefined != patient) && ( undefined != patient.disease))
			userElem = Object.keys(patient.disease);
	}
	else 
	{
		//reduceGraphToHide();
		return;
	}

	var nodeList = [];
	$.each(graph.nodes, function(i, d)
	{
		if ((userElem.indexOf(d.name) != -1 ) && (patient.disease[d.name] == true ))
		{
			d.isBase = true;
			nodeList.push(d);
		}
	});

	reduceGraphByNodeList(nodeList);
}

function reduce(node)
{
	node.hidden = true;
	graph.links.forEach(function(link) {
    	if (link.source == node)
		{
			link.hidden = true;
			reduce(link.target);
		}
	});

}

function expand(node)
{
	//node.hidden = false;
	graph.links.forEach(function(link) {
    	if (link.source == node)
		{
			link.hidden = false;
			link.target.hidden = false;
			//expand(link.target);
		}
	});
}

// propagate risks
function expandRiskGraph()
{
	var currNodes = [];
	$.each(graph.nodes, function(i, d)
	{
		if (! d.hidden)
			currNodes.push(d);
	});

	reduceGraphByNodeList(currNodes);
	drawGraph();
}

function showObservable(node)
{
	if (node.observable == undefined)
		return;

	if (node.observable.length == 0)
		return;

	if (node.group == 1)
		return;

	if (undefined == node.showObs)
	{
		node.showObs = true;
	}
	else 
		node.showObs = !node.showObs;

	$.each(graph.nodes, function(i, d)
	{
		if (d.group == 0)
			return;

		// add observables
		for (var j = 0; j < node.observable.length; j++)
		{
			if (d.name == getObsName(node.observable[j]))
			{
				d.hidden = ! node.showObs;
				break;
			}
		}
	});

	$.each(graph.links, function(i, d)
	{
		if (d.group == 0)
			return;

		for (var j = 0; j < node.observable.length; j++)
		{
			if ( (d.source == node) && (d.target.name == getObsName(node.observable[j])) )
			{
				d.hidden = ! node.showObs;
				break;
			}
		}
	});

	drawGraph();
}
