var width = $("#graphView").width();
var height = $("#graphView").height();
if (width == 0) width = 1000;
if (height == 0) height = 800;


// get the data
var riskGraph = genUserRiskGraph();
var graph = $.extend(true, {}, riskGraph);
var nodes = [];
var links = []; 
 
$.each(graph.nodes, function(i, d)
{
	d.reduced = false;
	d.ref = 0;
	d.id = i;

});

$.each(graph.links, function(i, d)
{
	d.reduced = false;
	d.source = graph.nodes[d.source];
	d.target = graph.nodes[d.target];
	d.id = i;

});

	// Set the range
	var  v = d3.scale.linear().range([0, 100]);
	// Scale the range of the data
	v.domain([0, d3.max(links, function(d) { return d.value; })]);
	
	// asign a type per value to encode opacity
	graph.links.forEach(function(link) {
		if (v(link.value) <= 1) {
			link.type = "twofive";
		} else if (v(link.value) <= 2 && v(link.value) > 1) {
			link.type = "fivezero";
		} else if (v(link.value) <= 3 && v(link.value) > 2) {
			link.type = "sevenfive";
		} else if (v(link.value) <= 4 && v(link.value) > 3) {
			link.type = "onezerozero";
		}
	});

var force = d3.layout.force()
	    .size([width, height])
	    .linkDistance(100)
	    .charge(-1000)
	    .on("tick", tick)
	    .start();
	
color = d3.scale.category20c();

nodes = force.nodes();
links = force.links();

//path = pathg.selectAll("path").data(links);
//node = svg.selectAll(".node") .data(nodes);

var svg = d3.select("#graphView").append("svg")
	    .attr("width", width)
	    .attr("height", height);

	 	// build the arrow.
	svg.append("svg:defs").selectAll("marker")
	    .data(["end"])      // Different link/path types can be defined here
	  .enter().append("svg:marker")    // This section adds in the arrows
	    .attr("id", "end")
	    .attr("viewBox", "0 0 10 10")
	    .attr("refX", 20)
	    .attr("refY", 2.5)
	    .attr("markerWidth", 8)
	    .attr("markerHeight", 6)
	    .attr("orient", "auto")
	  .append("svg:path")
	  .attr("d", "M 0 0 L 10 5 L 0 10 z");

 
var pathg = svg.append("svg:g");
var node = svg.selectAll(".node"),
    path = pathg.selectAll("path");


drawGraph();
force.start();
setTimeout(function() { force.stop(); }, 3000 );

function updateGraph()
{	
	graph.nodes.forEach(function(d) {
			d.ref = 0;
	});

	links.length = 0;
	graph.links.forEach(function(d) {
		if (d.reduced != true )
		{
			links.push(d);
			d.source.ref += 1;
			d.target.ref += 1;
		}
	});

	nodes.length = 0;
	graph.nodes.forEach(function(d) {
		if (d.ref > 0)
			nodes.push(d);
	});

}


function drawGraph()
{
	updateGraph();

	// now links changed with direct objects
	path = pathg.selectAll("path").data(force.links(), function(d) { return d.source.id + "-" + d.target.id; });
	//path = pathg.selectAll("path").data(links);

path.exit()
  .transition()
	.duration(2000)
	.style("opacity", 0)
    //.call(animateCellRemove)
  .remove();

/*
function animateCellRemove(selection) {
  selection
    .attr('transform', function(d) {
      return "scale(" + d.dx/2 + "," + d.dy/2 +")";
    });
}
*/

	// add the links and the arrows
	path.enter().append("svg:path")
       .attr("id", function (d) {
       		return d.source.id + "-" + d.target.id;
        })
	    .attr("class", function(d) { return "link " + d.type; })
	    .attr("marker-end", "url(#end)");

	// Update nodes.
	// define the nodes
	node = svg.selectAll(".node").data(force.nodes(), function(d) { return d.id;});
	//node = svg.selectAll(".node") .data(nodes);

  	//node.exit().remove();
node.exit()
  .transition()
	.duration(2000)
	.style("opacity", 0)
    //.call(animateCellRemove)
  .remove();


	var nodeEnter = node.enter().append("g")
	    .attr("class", "node")
        .attr("id", function (d) {
         	return d.id;
         })
	    .on("click", click)
	    .on("mouseover", mouseover)
	    .on("mouseout", mouseout)
	    .on("dblclick", dblclick)
	    .call(force.drag)
	.on("drag.force", function() {
        force.stop();
        d3.select(this).attr("transform", "translate(" + d3.event.x + "," + d3.event.y + ")");
    });
	 
	// add the nodes
	nodeEnter.append("circle")
	    .attr("r", 8)
	    .style("fill", function(d) { return color(d.name); });
	
	// add the text 
	nodeEnter.append("text")
	    .attr("x", 12)
	    .attr("dy", ".35em")
	    .text(function(d) { return d.name; });

	setTimeout(function(){ force.start(); }, 4000);;
	//force.start();
	 
}

// add the curvy lines
function tick() {
    path.attr("d", function(d) {
        var dx = d.target.x - d.source.x,
            dy = d.target.y - d.source.y,
            dr = Math.sqrt(dx * dx + dy * dy);
        return "M" + 
            d.source.x + "," + 
            d.source.y + "A" + 
            dr + "," + dr + " 0 0,1 " + 
            d.target.x + "," + 
            d.target.y;
    });
 
    node.attr("transform", function(d) { 
		    return "translate(" + d.x + "," + d.y + ")"; });
}
 
function mouseout(d)
{
    d3.select(this).select("text").transition()
        .duration(500)
        .attr("x", 12)
        .style("stroke", "lightsteelblue")
        .style("stroke-width", ".5px")
        .style("font", "10px sans-serif");

    d3.select(this).select("circle").transition()
        .duration(500)
        .attr("r", 8);
}

function mouseover(d)
{
    d3.select(this).select("text").transition()
        .duration(500)
        .attr("x", 22)
        .style("stroke", "lightsteelblue")
        .style("stroke-width", ".5px")
        .style("font", "20px sans-serif");

    d3.select(this).select("circle").transition()
        .duration(500)
        .attr("r", 16);
}


// action to take on mouse click
function click(d) {
  if (d3.event.defaultPrevented) return; // ignore drag

	force.stop();

	d3.select(this).classed("fixed", d.fixed = !d.fixed);

		if (d.reduced == true)
			expand(d);
		else
			reduce(d);

		drawGraph();
}
 
// action to take on mouse double click
function dblclick() {
    d3.select(this).select("circle").transition()
        .duration(750)
        .attr("r", 6);
    d3.select(this).select("text").transition()
        .duration(750)
        .attr("x", 12)
        .style("stroke", "none")
        .style("fill", "black")
        .style("stroke", "none")
        .style("font", "10px sans-serif");

}
 
 
function color(d) {
  return d._children ? "#3182bd" // collapsed package
      : d.children ? "#c6dbef" // expanded package
      : "#fd8d3c"; // leaf node
}

// Toggle children on click.
/*
function click(d) {
  if (d3.event.defaultPrevented) return; // ignore drag
  if (d.children) {
    d._children = d.children;
    d.children = null;
  } else {
    d.children = d._children;
    d._children = null;
  }
  update();
}
*/

function reduce(node)
{
	node.reduced = true;
	graph.links.forEach(function(link) {
    	if (link.source == node)
		{
			link.reduced = true;
			reduce(link.target);
		}
	});

}

function expand(node)
{
	node.reduced = false;
	graph.links.forEach(function(link) {
    	if (link.source == node)
		{
			link.reduced = false;
			expand(link.target);
		}
	});
}
