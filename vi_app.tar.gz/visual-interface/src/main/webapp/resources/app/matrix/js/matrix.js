var margin = {top: 100, right: 0, bottom: 10, left: 200},
    width = $("#matrixView").width();
    height = $("#matrixView").height();
	if (width == 0) width = 1000;
	if (height == 0) height = 800;

var x = d3.scale.ordinal().rangeBands([0, width]),
    z = d3.scale.linear().domain([0, 5]).clamp(true);

var c = ["#000000", "#0000FF", "#FF0000", "#00FFFF", "#AA7700", "#FFFF00"];
    //c = d3.scale.category10().domain(d3.range(10));

var tooltip = d3.select('body')
                  .append('div')
                  .attr('class', 'tooltip');

var svg = d3.select("#matrixView").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .style("margin-left", -margin.left + "px")
  .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

//d3.json("risks.json", function(miserables) {

  var riskGraph = genUserRiskGraph();

  var matrix = [],
      nodes = riskGraph.nodes,
      n = nodes.length;

  // Compute index per node.
  nodes.forEach(function(node, i) {
    node.index = i;
    node.count = 0;
    matrix[i] = d3.range(n).map(function(j) { return {x: j, y: i, z: 0}; });
  });

  // Convert links to matrix; count character occurrences.
  riskGraph.links.forEach(function(link) {
    //console.log("source: " + link.source + ", target: " + link.target);

    matrix[link.source][link.target].z += 1;
    nodes[link.target].count += 1;
  });

  // Precompute the orders.
  var orders = {
    name: d3.range(n).sort(function(a, b) { return d3.ascending(nodes[a].name, nodes[b].name); }),
    count: d3.range(n).sort(function(a, b) { return nodes[b].count - nodes[a].count; }),
    //count: d3.range(n).sort(function(a, b) { return -nodes[a].count; }),
    group: d3.range(n).sort(function(a, b) { return nodes[b].group - nodes[a].group; })
  };

  // The default sort order.
  x.domain(orders.name);

  svg.append("rect")
      .attr("class", "background")
      .attr("width", width)
      .attr("height", height)
      // .on("click", function(d,i){
      //     // show hint box
      //     alert("clicked");
      //     console.log("clicked");


        // });

  var row = svg.selectAll(".row")
      .data(matrix)
    .enter().append("g")
      .attr("class", "row")
      .attr("transform", function(d, i) { return "translate(0," + x(i) + ")"; })
      .each(row);

  row.append("line")
      .attr("x2", width);

  row.append("text")
      .attr("x", -6)
      .attr("y", x.rangeBand() / 2)
      .attr("dy", ".32em")
      .attr("text-anchor", "end")
      .text(function(d, i) { return nodes[i].name; })
	  .call(wrap, 100);

  var column = svg.selectAll(".column")
      .data(matrix)
    .enter().append("g")
      .attr("class", "column")
      .attr("transform", function(d, i) { return "translate(" + x(i) + ")rotate(-90)"; });

  column.append("line")
      .attr("x1", -width);

  column.append("text")
      .attr("x", 6)
      .attr("y", x.rangeBand() / 2)
      .attr("dy", ".32em")
      .attr("text-anchor", "start")
      .text(function(d, i) { return nodes[i].name; })
	  .call(wrap, 100);

  function row(row) {
    var cell = d3.select(this).selectAll(".cell")
        .data(row.filter(function(d) { return d.z; }))
      .enter().append("rect")
        .attr("class", "cell")
        .attr("x", function(d) { return x(d.x); })
        .attr("width", x.rangeBand())
        .attr("height", x.rangeBand())
        .style("fill-opacity", function(d) { return z(d.z); })
        .style("fill", function(d) { 

          return c[nodes[d.x].group];
          
          return nodes[d.x].group == nodes[d.y].group ? 
          c[nodes[d.x].group] : null;
           
        })
        // .on("mouseover", mouseover)
        // .on("mouseout", mouseout)
        .on('mouseover', tooltipOn)
        .on('mousemove', tooltipMove)
        .on('mouseout', tooltipOff);
  };

  function mouseover(p) {
    d3.selectAll(".row text").classed("active", function(d, i) { return i == p.y; });
    d3.selectAll(".column text").classed("active", function(d, i) { return i == p.x; });

  }

  function mouseout() {
    d3.selectAll("text").classed("active", false);
  }

function tooltipOn(d, i) {
      var content = '<div>Risk Evidence Number : ' + d.z + ' </div>';

      tooltip.html(content)
      .style('visibility', 'visible');
      //.attr("x", function(d) {return x(d.x);})
      //.attr("y", function (d) {return y(d.y);});
    };

function tooltipMove(d, i) {
       tooltip.style('top', (d3.event.pageY - 45) + 'px')
       .style('left', (d3.event.pageX - 280) + 'px');
     };

function tooltipOff() {
    tooltip.style('visibility', 'hidden');
 };


  d3.select("#order").on("change", function() {
    clearTimeout(timeout);
    order(this.value);
  });

  function order(value) {
    x.domain(orders[value]);

    var t = svg.transition().duration(2500);

    t.selectAll(".row")
        .delay(function(d, i) { return x(i) * 4; })
        .attr("transform", function(d, i) { return "translate(0," + x(i) + ")"; })
      .selectAll(".cell")
        .delay(function(d) { return x(d.x) * 4; })
        .attr("x", function(d) { return x(d.x); });

    t.selectAll(".column")
        .delay(function(d, i) { return x(i) * 4; })
        .attr("transform", function(d, i) { return "translate(" + x(i) + ")rotate(-90)"; });
  }

  var timeout = setTimeout(function() {
    //order("group");
    //d3.select("#order").property("selectedIndex", 2).node().focus();
  }, 5000);

