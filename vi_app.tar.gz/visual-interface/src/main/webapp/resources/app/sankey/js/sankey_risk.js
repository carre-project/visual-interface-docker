var arcs = [],
    chords = [];

var data, matrices, neighs, years;

var last_chord = {};

var fill = d3.scale.category20()
    .domain(d3.range(42));

var w = $("#chart").width();
var h = $("#chart").height() - 200;
if (w == 0 ) w = 1000;
if (h == 0 ) h = 800;

var formatPercent = d3.format(".1%");

   var  padding = 80,
    r0 = (Math.min(w, h)-padding*2) * .41,
    r1 = r0 * 1.1;

  var svg = d3.select("#chart")
    .append("svg:svg")
    .attr("width", w)
    .attr("height", h)
    .append("svg:g")
    // .attr("transform", "translate(" + w / 2 + "," + h / 2 + ")")
     .attr("transform", "translate(" + 0 + "," + 20 + ")")
    

var graph = genUserRiskGraph();

var riskGraph = $.extend(true, {}, graph);
neighs = riskGraph.nodes;

var nodesObs = [];
var nodesObsKey = {};
var idObsNode = graph.nodes.length;

// add unique observable nodes
$.each(graph.nodes, function(i, d)
{
    // add observables
    if (d.observable != undefined)
    {
        var nodeObs;
        for (var j = 0; j < d.observable.length; j++)
        {
			var obsId = d.observable[j];
			if (nodesObsKey[obsId] == undefined)	
			{
            	node = { id: idObsNode, name: getObsName(d.observable[j]), group: 1};
            	nodesObs.push(node);
				nodesObsKey[obsId] = node;
            	idObsNode ++;
			}
			else
			{
				node = nodesObsKey[obsId];
			}
            var link =  { target : i, source: node.id, evidence: [], value : 1, group: 1};
            riskGraph.links.push(link);
        }
    }
});

riskGraph.nodes = riskGraph.nodes.concat(nodesObs);
data = getGraphMatrix(riskGraph);

var units = "Risk Evidence/s";
var formatNumber = d3.format(",.0f"),    // decimal places
    format = function(d) { return formatNumber(d) + " " + units; },
    color = d3.scale.category20();


// Set the sankey diagram properties
var sankey = d3.sankey()
    .nodeWidth(20)
    .nodePadding(15)
    .size([w-padding/2, h-padding/2]);

var path = sankey.link();

  sankey.nodes(riskGraph.nodes)
      .links(riskGraph.links)
      .layout(32);
// add in the links
  var link = svg.append("g").selectAll(".link")
      .data(riskGraph.links)
    .enter().append("path")
      .attr("class", "link")
      .attr("d", path)
      .style("stroke", function(d) {
          //return fill(Math.floor(Math.random()* 42) ); 
		  return "#6495ED"; //CornflowerBlue 
		  })
      .style("stroke-width", function(d) { 
			  return Math.max(1, d.dy); })
      .sort(function(a, b) { return b.dy - a.dy; });

// add the link titles
  link.append("title")
        .text(function(d) {
            return d.source.name + " → " + 
                //d.target.name + "\n" + format(d.value); });
                d.target.name + "\n"; });


// add in the nodes
  var node = svg.append("g").selectAll(".node")
      .data(riskGraph.nodes)
    .enter().append("g")
      .attr("class", "node")
      .attr("transform", function(d) { 
          return "translate(" + d.x + "," + d.y + ")"; })
    .call(d3.behavior.drag()
      .origin(function(d) { return d; })
      .on("dragstart", function() { 
          this.parentNode.appendChild(this); })
      .on("drag", dragmove));

// add the rectangles for the nodes
  node.append("rect")
      .attr("height", function(d) { return d.dy; })
      .attr("width", sankey.nodeWidth())
      .style("fill", function(d) { 
          return d.color = color(d.name); })
      .style("stroke", function(d) { 
			  return "#CCC";
          //return d3.rgb(d.color).darker(2);
		  })
      .style("stroke-width",  2)
    .append("title")
      .text(function(d) { 
          //return d.name + "\n" + format(d.value); });
          return d.name; });

// add in the title for the nodes
  node.append("text")
      .attr("x", -6)
      .attr("y", function(d) { return d.dy / 2; })
      .attr("dy", ".35em")
      .attr("text-anchor", "end")
      .attr("transform", null)
      .text(function(d) { return d.name; })
    .filter(function(d) { return d.x < w / 2; })
      .attr("x", 6 + sankey.nodeWidth())
      .attr("text-anchor", "start");



// the function for moving the nodes
  function dragmove(d) {
    d3.select(this).attr("transform", 
        "translate(" + (
            d.x = Math.max(0, Math.min((w-padding/2) - d.dx, d3.event.x))
        )
        + "," + (
            d.y = Math.max(0, Math.min((h-padding/2) - d.dy, d3.event.y))
        ) + ")");
    sankey.relayout();
    link.attr("d", path);
  }
