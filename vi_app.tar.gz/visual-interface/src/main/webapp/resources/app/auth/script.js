
angular.module('CarreExample', ['ngCookies'])
.config(function($locationProvider) {
  $locationProvider.html5Mode(true).hashPrefix('#');
})
.controller('ExampleController', function($cookieStore,$scope,$http,$location) {
  
  // Retrieving a cookie
  var cookie = $cookieStore.get('CARRE_USER');
  
  // Retrieving url params
  var params = $location.search();
  
  
  //check for cookie or url get parameters
  if(cookie) {
      $scope.user=cookie;
  } else if (params.username) {
      $scope.user=params;
      cookie=params;
    $cookieStore.put('CARRE_USER',cookie);
  }
  //callback url
  //var callback_url="http://beta.carre-project.eu/auth/";
  //var callback_url="http://visual.carre-project.eu/Carre/static/auth/index.html";
  //@todo linode2 
  var callback_url="http://visual.carre-project.eu/Carre/static/mainFrame/index.html";
  //var callback_url="http://localhost:8080/Carre/static/mainFrame/index.html";
  
  //login/logour functions
  $scope.login=function(){
    //redirect to login and back with the parameters
    window.location.href = 'https://carre.kmi.open.ac.uk/devices/accounts/login?next='+callback_url;
  };
  $scope.logout=function(){
    
    $scope.user=null; //remove user object
    $cookieStore.remove('CARRE_USER'); //remove user cookie
    
    //logout from the carre devices site
    window.location.href = 'https://carre.kmi.open.ac.uk/devices/accounts/logout?next='+callback_url;

  };
  
  //view the cookie in the template
  $scope.cookie=cookie;
  //clean up the browser url
  $location.url('/').replace();
  
});
