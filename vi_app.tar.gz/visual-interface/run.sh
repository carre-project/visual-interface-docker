#!/bin/bash
mvn clean tomcat7:run -DENV_SYSTEM=.dev
