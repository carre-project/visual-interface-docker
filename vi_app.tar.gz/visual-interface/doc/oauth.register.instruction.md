To register application with difference oauth provider, we need to know the URLs of the application, let us say:
http://myhealthavatar.ccgv.org.uk/mha/

Login the following URL and follow the brief instructions to register.
--- google:
    https://code.google.com/apis/console

    APIs & auth => Credentials => CREATE NEW CLIENT ID
    fill in:
        Web application
        http://myhealthavatar.ccgv.org.uk/mha/connect/google  (Authorized redirect URI)


--- facebook:
    https://developers.facebook.com/

    Apps => Create a new app


--- twitter
    https://dev.twitter.com/

    click on top right icon => My applications => Create New App


--- fitbit
    https://www.fitbit.com/dev

    Register an app


--- moves:
    https://dev.moves-app.com/apps

    Create a New App

