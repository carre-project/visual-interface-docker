Spring Social is an extension of the Spring Framework that allows you to connect your applications with Software-as-a-Service (SaaS) providers such as Facebook and Twitter.

Features:
An extensible service provider framework that greatly simplifies the process of connecting local user accounts to hosted provider accounts.
A connect controller that handles the authorization flow between your Java/Spring web application, a service provider, and your users.
Java bindings to popular service provider APIs such as Facebook, Twitter, LinkedIn, TripIt, and GitHub.
A sign-in controller that enables users to authenticate with your application by signing in through a service provider.

Source: http://www.springsource.org/spring-social