The # means to resolve the attribute from the messages bundle
The $ means to resolve the attribute from the model
The # and $ can be combined together so that messages can be dynamically
    generated from the model and internationalized from the message bundle.
th:href attribute
    <link rel="stylesheet" href="../../../resources/css/style.css"
        th:href="@{/resources/css/style.css}" />
    Declare a resource relative to the context of the app. When testing the html
    mockup, the th:href attribute is ignored by the browser. When running the
    app, Thymeleaf's preprocessor will ignore the value of the href attribute
    and use the value in the hr:href attribute.
th:text attribute
    <title th:text="#{'prefile.title.' + ${source}}">Title</title>
    Declares the usual title element. When testing the html mockup, the th:text
    attribute is ignored by the browser. When running the app, Thymeleaf's
    preprocessor will ignore the value of the title and use the value of the
    th:text attribute.
th:include attribute
    <div th:include="include :: menu"></div>
    Includes an html fragment. The fragment is declared in the include.html
th:src attribute
    <img src="#" th:src="@{'http://graph.facebook.com/' + ${profileInfo.id}}
        + '/picture'" alt="profile image" />
    Declares an image element.
th:if attribute
    <dd th:if="${#string.isEmpty(profileInfo.email)}" th:text="'no email listed'">
        john@email.com</dd>
    A conditional expression. This states "if the profileInfo.email attribute is
    empty, print out 'no email listed', but it's not empty, then print out the value.



master page possible solution
http://blog.codeleak.pl/2013/11/is-it-worth-upgrading-to-thymeleaf-21.html?showComment=1383817035384#c5722173744814267184
Hello

I actually don't use tiles/tiles-extensions - I've always thought that there's something wrong that controller returns tiles-definition name which is configured externally (tiles definition file) instead of returning what it should return - a view name which might be a "tile" put inside externally configured definition.

I just do the following:

1. Controllers, as always return view names (which translate to single Thymeleaf template file)
2. I declare one global interceptor in RequestMappingHandlerMapping
3. This interceptor changes the viewName in ModelAndView into a Thymeleaf view template file and the original viewName becomes "view" attribute in ModelAndView
4. The layout file (there are two, three of them, e.g. "main", "security", "admin", ...) contains several th:substituteby's (in Thymeleaf 2.1: th:replace):
- <div th:substituteby="${view} :: content">x</div>
- <title th:substituteby="${view} :: title">
- ...
5. the actual view file (not layout file) contains fragments, "pulled" by the template which embeds the actual view:
- <head><title th:fragment="title">xxx
- <div th:fragment="content">...

My application contains ~30 views - every one of them is "natural" template with working CSS and JS!

regards
Grzegorz Grzybek
