#!/bin/bash
cd /home/zdeng/mha/ccgv-social-java
git pull
mvn clean package
# sudo
rm /var/lib/tomcat7/webapps/mha.war
rm -rf /var/lib/tomcat7/webapps/mha

# update the path
cp /home/zdeng/mha/ccgv-social-java/target/mha.war /var/lib/tomcat7/webapps/
# be careful, following is optional
# service tomcat7 restart
