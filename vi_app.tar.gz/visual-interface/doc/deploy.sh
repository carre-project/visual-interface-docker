#!/bin/bash
cd /home/ccgv/sources/ccgv-social-java
git pull
mvn clean package
# sudo
rm /var/lib/tomcat7/webapps/ccgv-social.war
rm -rf /var/lib/tomcat7/webapps/ccgv-social

rm /var/lib/tomcat7/webapps/mha.war
rm -rf /var/lib/tomcat7/webapps/mha

# update the path
cp /home/ccgv/sources/ccgv-social-java/target/mha.war /var/lib/tomcat7/webapps/
service tomcat7 restart
