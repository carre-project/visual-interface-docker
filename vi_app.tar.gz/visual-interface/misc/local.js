// To run this test application, you will need to have node/npm installed on your system
//
// https://www.npmjs.com/package/simple-oauth2
// https://github.com/andreareginato/simple-oauth2
// http://andreareginato.github.io/simple-oauth2/#getting-started/express-and-github-example
// 
//
// sudo npm install -g express
// sudo npm install -g simple-oauth2
//
// npm link express
// npm link simple-oauth2
//
// node local.js
//

var express = require('express'),
	app = express(),
	http = require('http');

// var oauth2 = require('simple-oauth2')({
// 	clientID: '81782bd731eac5fdc3bd',
// 	clientSecret: '37bd3f151f7bd665c5efb98a9e81d1111d8ea8b8',
// 	site: 'https://github.com/login',
// 	tokenPath: '/oauth/access_token'
// });

// var clientId = '0f927c40-fdf5-11e3-a3ac-0800200c9a66';
// var clientSecret = '1b3cc870-fdf5-11e3-a3ac-0800200c9a66';

var clientId = 'tonr';
var clientSecret = 'secret';

var oauth2 = require('simple-oauth2')({
	clientID: clientId,
	clientSecret: clientSecret,
	site: 'http://127.0.0.1:8080/mha',
	authorizationPath: '/oauth/authorize',
	tokenPath: '/oauth/token'
});



// Authorization uri definition
var authorization_uri = oauth2.authCode.authorizeURL({
	redirect_uri: 'http://127.0.0.1:3000/callback',
	scope: 'read',
	state: '7(#0/!~'
});

// Initial page redirecting to github
app.get('/auth', function (req, res) {
	res.redirect(authorization_uri);
});

// Call back service parsing the authorization token and asking for the access token
app.get('/callback', function (req, res) {
	var code = req.query.code;
	console.log('/callback with code:\t' + code);
	oauth2.authCode.getToken({
		code: code,
		redirect_uri: 'http://127.0.0.1:3000/callback'
	}, saveToken);

	function saveToken(error, result) {
		if (error) {
			console.log('Access Token Error: \n', error);
		}

		console.log(result);
		token = oauth2.accessToken.create(result);
		console.log("+++++++++++++++++++++++++++++++");
		console.log('token: ', token)

		var options = {
			host: '127.0.0.1',
			port: '8080',
			path: '/mha/api/v2/user/activities/summary',
			headers: {'Authorization': 'Bearer ' + token.token.access_token}
		}

		console.log('make request to api/moves');
		req = http.request(options, oauth2ApiCallback);
		req.end();
	}

	function oauth2ApiCallback (response) {
		console.log('--> within call back of oauth2 protected resource');
		var str = '';
		response.on('data', function (chunk) {
			str += chunk;
		});

		response.on('end', function () {
			// console.log(str);
			res.send('result of calling /api/moves: <br /> <pre>' + str + '</pre>');
		});
	}
});

app.get('/', function (req, res) {
  	res.send('<h2>Welcome to MHA</h2><br /><a href="/auth">Access MHA API through OAuth2 flow</a>'
  			 + '<br /><br /><p>NodeJS based client.</p>');
});

app.listen(3000);

console.log('Please visit: http://127.0.0.1:3000/');
